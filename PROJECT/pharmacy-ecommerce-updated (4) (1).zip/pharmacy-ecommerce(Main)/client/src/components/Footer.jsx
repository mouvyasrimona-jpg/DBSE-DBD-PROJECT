import React from "react";
import { Link } from "react-router-dom";
import "./Footer.css";

function Footer() {
    return (
        <footer className="site-footer">
            <div className="footer-inner">

                <div className="footer-col footer-brand">
                    <div className="footer-logo">
                        <span className="footer-logo-icon">💊</span>
                        <span>PharmaCare</span>
                    </div>
                    <p>Your trusted digital pharmacy platform — verified medicines, pharmacist-reviewed prescriptions, and real-time delivery tracking.</p>
                </div>

                <div className="footer-col">
                    <h4>Company</h4>
                    <Link to="/about">About PharmaCare</Link>
                    <Link to="/faq">FAQs</Link>
                </div>

                <div className="footer-col">
                    <h4>Services</h4>
                    <Link to="/medicines">Browse Medicines</Link>
                    <Link to="/prescription">Upload Prescription</Link>
                    <Link to="/orders">Track Order</Link>
                    <Link to="/refill-reminders">Refill Reminders</Link>
                </div>

                <div className="footer-col">
                    <h4>Policies</h4>
                    <Link to="/privacy-policy">Privacy Policy</Link>
                    <Link to="/terms">Terms &amp; Conditions</Link>
                </div>

            </div>

            <div className="footer-bottom">
                <span>© {new Date().getFullYear()} PharmaCare. All Rights Reserved.</span>
                <span className="footer-disclaimer">PharmaCare does not provide medical advice — consult a licensed professional for medical decisions.</span>
            </div>
        </footer>
    );
}

export default Footer;
