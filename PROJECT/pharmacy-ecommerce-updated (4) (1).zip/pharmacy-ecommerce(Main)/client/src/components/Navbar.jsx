import React, { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import NotificationBell from "./NotificationBell";
import LocationSelector from "./LocationSelector";
import "./Navbar.css";

const Navbar = () => {
    const { user, isAuthenticated, logout } = useAuth();
    const navigate = useNavigate();
    const [cartCount, setCartCount] = useState(0);
    const [mobileOpen, setMobileOpen] = useState(false);

    const updateCartCount = () => {
        const storedCart = localStorage.getItem("cart");
        if (storedCart) {
            try {
                const parsed = JSON.parse(storedCart);
                const count = parsed.reduce((sum, item) => sum + (item.cartQuantity || 1), 0);
                setCartCount(count);
            } catch (e) {
                setCartCount(0);
            }
        } else {
            setCartCount(0);
        }
    };

    useEffect(() => {
        updateCartCount();
        const handleCartUpdate = () => updateCartCount();
        window.addEventListener("cartUpdated", handleCartUpdate);
        window.addEventListener("storage", handleCartUpdate);

        return () => {
            window.removeEventListener("cartUpdated", handleCartUpdate);
            window.removeEventListener("storage", handleCartUpdate);
        };
    }, []);

    const handleLogout = () => {
        logout();
        navigate("/login");
    };

    return (
        <header className="site-header">

            {/* ===== TOP UTILITY ROW ===== */}
            <div className="header-top-row">
                <div className="header-top-inner">

                    <Link to="/" className="pharma-logo">
                        <span className="logo-icon">💊</span>
                        <span className="logo-text">
                            PharmaCare
                            <small className="logo-sub">Verified. Safe. Delivered.</small>
                        </span>
                    </Link>

                    <LocationSelector />

                    <div className="header-top-spacer" />

                    <div className="header-top-actions">
                        <NotificationBell />

                        <Link to="/cart" className="cart-nav-link">
                            🛒 Cart {cartCount > 0 && <span className="cart-count-badge">{cartCount}</span>}
                        </Link>

                        {isAuthenticated ? (
                            <>
                                <Link to="/dashboard" className="user-badge">
                                    👤 {user?.name || "Account"}
                                </Link>
                                <button className="logout-btn" onClick={handleLogout}>Logout</button>
                            </>
                        ) : (
                            <>
                                <Link to="/login" className="login-btn">Login</Link>
                                <Link to="/register" className="register-btn">Register</Link>
                            </>
                        )}

                        <button
                            className="mobile-menu-toggle"
                            onClick={() => setMobileOpen(!mobileOpen)}
                            aria-label="Toggle menu"
                        >
                            ☰
                        </button>
                    </div>

                </div>
            </div>

            {/* ===== SECONDARY NAV ROW ===== */}
            <nav className={`header-nav-row ${mobileOpen ? "mobile-open" : ""}`}>
                <div className="header-nav-inner">

                    <Link to="/" onClick={() => setMobileOpen(false)}>Home</Link>
                    <Link to="/medicines" onClick={() => setMobileOpen(false)}>Medicines</Link>
                    <Link to="/lab-tests" onClick={() => setMobileOpen(false)}>Lab Tests</Link>
                    <Link to="/prescription" onClick={() => setMobileOpen(false)}>Prescription</Link>

                    {isAuthenticated && (
                        <Link to="/orders" onClick={() => setMobileOpen(false)}>Track Order</Link>
                    )}

                    {isAuthenticated && (
                        <Link to="/lab-bookings" onClick={() => setMobileOpen(false)}>My Lab Bookings</Link>
                    )}

                    {isAuthenticated && (
                        <Link to="/refill-reminders" onClick={() => setMobileOpen(false)}>🔔 Refill Reminders</Link>
                    )}

                    {isAuthenticated && (
                        <Link to="/dashboard" onClick={() => setMobileOpen(false)}>Dashboard</Link>
                    )}

                    <Link to="/about" onClick={() => setMobileOpen(false)}>About</Link>

                    {isAuthenticated && user?.role === "admin" && (
                        <Link to="/admin" className="admin-nav-link" onClick={() => setMobileOpen(false)}>
                            🛡️ Admin Dashboard
                        </Link>
                    )}

                    {isAuthenticated && user?.role === "pharmacist" && (
                        <Link to="/pharmacist" className="admin-nav-link" onClick={() => setMobileOpen(false)}>
                            💊 Pharmacist Dashboard
                        </Link>
                    )}

                    {isAuthenticated && user?.role === "delivery" && (
                        <Link to="/delivery" className="admin-nav-link" onClick={() => setMobileOpen(false)}>
                            🚚 Delivery Dashboard
                        </Link>
                    )}

                </div>
            </nav>

        </header>
    );
};

export default Navbar;
