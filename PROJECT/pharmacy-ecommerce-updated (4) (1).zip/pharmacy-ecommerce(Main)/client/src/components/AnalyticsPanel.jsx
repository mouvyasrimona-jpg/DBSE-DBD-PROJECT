import React, { useEffect, useState } from "react";
import { useAuth } from "../context/AuthContext";

const API_BASE = "http://localhost:5000/api";

function AnalyticsPanel() {
    const { token } = useAuth();
    const [data, setData] = useState(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState("");

    useEffect(() => {
        const fetchAnalytics = async () => {
            try {
                setLoading(true);
                const res = await fetch(`${API_BASE}/analytics/admin`, {
                    headers: { Authorization: `Bearer ${token}` }
                });
                const json = await res.json();
                if (json.success) {
                    setData(json);
                } else {
                    setError(json.message || "Failed to load analytics");
                }
            } catch (err) {
                setError("Failed to load analytics");
            } finally {
                setLoading(false);
            }
        };
        if (token) fetchAnalytics();
    }, [token]);

    if (loading) return <div className="analytics-loading">Loading analytics...</div>;
    if (error) return <div className="analytics-error">{error}</div>;
    if (!data) return null;

    const { totals, charts } = data;

    const statCards = [
        { label: "Total Orders", value: totals.totalOrders, icon: "📦" },
        { label: "Total Revenue", value: `₹${totals.totalRevenue.toFixed(0)}`, icon: "💰" },
        { label: "Customers", value: totals.totalCustomers, icon: "👥" },
        { label: "Medicines", value: totals.totalMedicines, icon: "💊" },
        { label: "Pending Rx", value: totals.pendingPrescriptions, icon: "⏳" },
        { label: "Approved Rx", value: totals.approvedPrescriptions, icon: "✅" },
        { label: "Rejected Rx", value: totals.rejectedPrescriptions, icon: "❌" },
        { label: "Low Stock", value: totals.lowStockCount, icon: "⚠️" },
        { label: "Expiring Soon", value: totals.expiringBatchCount, icon: "⏰" },
        { label: "Delivered", value: totals.deliveredOrders, icon: "🎉" },
        { label: "Cancelled", value: totals.cancelledOrders, icon: "🚫" }
    ];

    const maxOrders = Math.max(1, ...charts.ordersOverTime.map((d) => d.count));
    const maxRevenue = Math.max(1, ...charts.revenueOverTime.map((d) => d.revenue));
    const maxTopMed = Math.max(1, ...charts.topMedicines.map((d) => d.totalQuantity));

    return (
        <div className="analytics-panel">
            <div className="analytics-stats-grid">
                {statCards.map((s) => (
                    <div className="analytics-stat-card" key={s.label}>
                        <span className="a-icon">{s.icon}</span>
                        <div>
                            <strong>{s.value}</strong>
                            <p>{s.label}</p>
                        </div>
                    </div>
                ))}
            </div>

            <div className="analytics-charts-grid">

                <div className="analytics-chart-card">
                    <h4>Orders — Last 30 Days</h4>
                    {charts.ordersOverTime.length === 0 ? (
                        <p className="chart-empty">No orders in this period yet.</p>
                    ) : (
                        <svg viewBox={`0 0 ${charts.ordersOverTime.length * 24} 100`} className="bar-chart-svg">
                            {charts.ordersOverTime.map((d, i) => (
                                <rect
                                    key={d._id}
                                    x={i * 24 + 4}
                                    y={100 - (d.count / maxOrders) * 90}
                                    width={16}
                                    height={(d.count / maxOrders) * 90}
                                    rx={3}
                                    fill="#0d9488"
                                >
                                    <title>{d._id}: {d.count} orders</title>
                                </rect>
                            ))}
                        </svg>
                    )}
                </div>

                <div className="analytics-chart-card">
                    <h4>Revenue — Last 30 Days</h4>
                    {charts.revenueOverTime.length === 0 ? (
                        <p className="chart-empty">No revenue in this period yet.</p>
                    ) : (
                        <svg viewBox={`0 0 ${charts.revenueOverTime.length * 24} 100`} className="bar-chart-svg">
                            {charts.revenueOverTime.map((d, i) => (
                                <rect
                                    key={d._id}
                                    x={i * 24 + 4}
                                    y={100 - (d.revenue / maxRevenue) * 90}
                                    width={16}
                                    height={(d.revenue / maxRevenue) * 90}
                                    rx={3}
                                    fill="#2563eb"
                                >
                                    <title>{d._id}: ₹{d.revenue.toFixed(0)}</title>
                                </rect>
                            ))}
                        </svg>
                    )}
                </div>

                <div className="analytics-chart-card">
                    <h4>Most Ordered Medicines</h4>
                    {charts.topMedicines.length === 0 ? (
                        <p className="chart-empty">No order data yet.</p>
                    ) : (
                        <div className="top-med-bars">
                            {charts.topMedicines.map((m) => (
                                <div className="top-med-row" key={m._id}>
                                    <span className="top-med-label">{m._id}</span>
                                    <div className="top-med-bar-track">
                                        <div
                                            className="top-med-bar-fill"
                                            style={{ width: `${(m.totalQuantity / maxTopMed) * 100}%` }}
                                        />
                                    </div>
                                    <span className="top-med-count">{m.totalQuantity}</span>
                                </div>
                            ))}
                        </div>
                    )}
                </div>

                <div className="analytics-chart-card">
                    <h4>Order Status Distribution</h4>
                    {charts.statusDistribution.length === 0 ? (
                        <p className="chart-empty">No orders yet.</p>
                    ) : (
                        <div className="status-dist-list">
                            {charts.statusDistribution.map((s) => (
                                <div className="status-dist-row" key={s._id}>
                                    <span>{s._id}</span>
                                    <span className="status-dist-count">{s.count}</span>
                                </div>
                            ))}
                        </div>
                    )}
                </div>

            </div>
        </div>
    );
}

export default AnalyticsPanel;
