import React, { useState, useRef, useEffect } from "react";
import "./SupportAssistant.css";

// Rule-based FAQ matching — deliberately NOT a medical AI. Every
// entry here answers a website/process question only. Any message
// matching medical-sounding keywords gets redirected to a doctor,
// never answered directly.
const FAQ = [
    {
        keywords: ["upload", "prescription upload", "how to upload"],
        answer: "To upload a prescription: go to the Prescription page from the navbar, click 'Upload Prescription', and choose a clear photo or PDF of your prescription. Our OCR system will scan it automatically."
    },
    {
        keywords: ["verify", "verification", "approve", "pharmacist review"],
        answer: "After upload, our system scans your prescription and a licensed pharmacist manually reviews it. You'll get a notification once it's Approved or Rejected — this usually only allows checkout for medicines that specifically match your approved prescription."
    },
    {
        keywords: ["track", "tracking", "where is my order", "order status"],
        answer: "Go to 'My Orders' and click on any order to see live tracking — including a map view once your order is out for delivery."
    },
    {
        keywords: ["reorder", "buy again", "order again"],
        answer: "On the 'My Orders' page, click the 'Reorder' button on any past order — we'll add the same items to your cart at current prices and stock."
    },
    {
        keywords: ["delivery", "otp", "delivery partner", "how delivery works"],
        answer: "Once your order is out for delivery, you'll get a 6-digit OTP. Share it with the delivery partner only when they arrive — this confirms it's really you receiving the order."
    },
    {
        keywords: ["invoice", "bill", "receipt", "download invoice"],
        answer: "Open any order's details page and click 'View Invoice' to see a printable, downloadable invoice with the full price breakdown."
    },
    {
        keywords: ["pharmacy", "compare", "marketplace", "multiple pharmacy"],
        answer: "On a medicine's details page, scroll to 'Available at Nearby Pharmacies' to compare price, discount, delivery time and stock across different pharmacies before choosing one."
    },
    {
        keywords: ["contact", "support", "help", "human", "talk to someone"],
        answer: "For anything I can't help with, please reach our support team at support@pharmacare.example or call the number listed in the About page."
    },
    {
        keywords: ["review", "rating", "rate"],
        answer: "Once an order is marked Delivered, open its details page to leave a star rating and review for each medicine you purchased."
    }
];

const MEDICAL_KEYWORDS = [
    "diagnos", "symptom", "should i take", "dosage for me", "side effect",
    "is it safe", "can i take", "overdose", "allergic", "pregnant", "pain",
    "fever", "infection", "disease", "cure", "treatment for"
];

const getResponse = (userText) => {
    const lower = userText.toLowerCase();

    if (MEDICAL_KEYWORDS.some((k) => lower.includes(k))) {
        return "I'm only able to help with how the website works — I can't give medical advice, diagnose anything, or suggest medicines for a condition. Please consult a licensed doctor or pharmacist for that. I can help you upload a prescription, track an order, or find support contact info though!";
    }

    const match = FAQ.find((entry) => entry.keywords.some((k) => lower.includes(k)));
    if (match) return match.answer;

    return "I'm not sure about that one — I can help with prescription uploads, order tracking, reordering, delivery/OTP, invoices, pharmacy comparison, or reviews. For anything else, please contact support@pharmacare.example.";
};

function SupportAssistant() {
    const [open, setOpen] = useState(false);
    const [input, setInput] = useState("");
    const [messages, setMessages] = useState([
        { from: "bot", text: "Hi! I'm the PharmaCare support assistant. I can help with website navigation, order tracking, prescriptions and more. I can't give medical advice — for that, please see a doctor. How can I help?" }
    ]);
    const endRef = useRef(null);

    useEffect(() => {
        endRef.current?.scrollIntoView({ behavior: "smooth" });
    }, [messages, open]);

    const handleSend = (e) => {
        e.preventDefault();
        const trimmed = input.trim();
        if (!trimmed) return;

        const userMsg = { from: "user", text: trimmed };
        const botMsg = { from: "bot", text: getResponse(trimmed) };

        setMessages((prev) => [...prev, userMsg, botMsg]);
        setInput("");
    };

    return (
        <div className="support-assistant-root">
            {open && (
                <div className="support-chat-panel">
                    <div className="support-chat-header">
                        <span>💬 PharmaCare Support</span>
                        <button onClick={() => setOpen(false)}>×</button>
                    </div>

                    <div className="support-chat-messages">
                        {messages.map((m, i) => (
                            <div key={i} className={`support-msg ${m.from}`}>
                                {m.text}
                            </div>
                        ))}
                        <div ref={endRef} />
                    </div>

                    <form className="support-chat-input" onSubmit={handleSend}>
                        <input
                            type="text"
                            placeholder="Ask about orders, prescriptions..."
                            value={input}
                            onChange={(e) => setInput(e.target.value)}
                        />
                        <button type="submit">➤</button>
                    </form>
                </div>
            )}

            <button className="support-fab" onClick={() => setOpen(!open)}>
                {open ? "×" : "💬"}
            </button>
        </div>
    );
}

export default SupportAssistant;
