import React, { useEffect, useState } from "react";
import { useAuth } from "../context/AuthContext";

const API_BASE = "http://localhost:5000/api";

function InventoryPanel() {
    const { token } = useAuth();
    const [overview, setOverview] = useState(null);
    const [loading, setLoading] = useState(true);
    const [showForm, setShowForm] = useState(false);
    const [medicines, setMedicines] = useState([]);
    const [message, setMessage] = useState("");

    const [form, setForm] = useState({
        medicineId: "", batchNumber: "", manufacturingDate: "", expiryDate: "",
        quantity: "", purchasePrice: "", sellingPrice: "", supplier: "", pharmacyName: ""
    });

    const fetchOverview = async () => {
        try {
            setLoading(true);
            const res = await fetch(`${API_BASE}/inventory/overview`, {
                headers: { Authorization: `Bearer ${token}` }
            });
            const json = await res.json();
            if (json.success) setOverview(json);
        } catch (err) {
            console.error(err);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        if (token) {
            fetchOverview();
            fetch(`${API_BASE}/medicines`).then(r => r.json()).then(d => {
                if (d.success) setMedicines(d.medicines);
            });
        }
    }, [token]);

    const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            const res = await fetch(`${API_BASE}/inventory/batches`, {
                method: "POST",
                headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
                body: JSON.stringify(form)
            });
            const data = await res.json();
            if (data.success) {
                setMessage("✅ Batch created successfully");
                setShowForm(false);
                fetchOverview();
            } else {
                setMessage(`⚠️ ${data.message}`);
            }
        } catch (err) {
            setMessage("Failed to create batch");
        }
        setTimeout(() => setMessage(""), 3000);
    };

    if (loading) return <div className="analytics-loading">Loading inventory...</div>;

    return (
        <div className="inventory-panel">
            <div className="inventory-header">
                <h3>Batch & Expiry Inventory</h3>
                <button className="add-batch-btn" onClick={() => setShowForm(!showForm)}>
                    {showForm ? "Cancel" : "+ Add Batch"}
                </button>
            </div>

            {message && <div className="inventory-message">{message}</div>}

            {showForm && (
                <form className="batch-form" onSubmit={handleSubmit}>
                    <select name="medicineId" value={form.medicineId} onChange={handleChange} required>
                        <option value="">Select Medicine</option>
                        {medicines.map((m) => <option key={m._id} value={m._id}>{m.name}</option>)}
                    </select>
                    <input name="batchNumber" placeholder="Batch Number" value={form.batchNumber} onChange={handleChange} required />
                    <input name="manufacturingDate" type="date" value={form.manufacturingDate} onChange={handleChange} required />
                    <input name="expiryDate" type="date" value={form.expiryDate} onChange={handleChange} required />
                    <input name="quantity" type="number" placeholder="Quantity" value={form.quantity} onChange={handleChange} required />
                    <input name="purchasePrice" type="number" placeholder="Purchase Price" value={form.purchasePrice} onChange={handleChange} required />
                    <input name="sellingPrice" type="number" placeholder="Selling Price" value={form.sellingPrice} onChange={handleChange} required />
                    <input name="supplier" placeholder="Supplier" value={form.supplier} onChange={handleChange} />
                    <input name="pharmacyName" placeholder="Pharmacy Name" value={form.pharmacyName} onChange={handleChange} />
                    <button type="submit" className="save-batch-btn">Save Batch</button>
                </form>
            )}

            <div className="inventory-alert-grid">
                <div className="inventory-alert-card expired">
                    <h4>❌ Expired Batches ({overview?.expiredBatches?.length || 0})</h4>
                    {overview?.expiredBatches?.length === 0 && <p>None — good.</p>}
                    {overview?.expiredBatches?.map((b) => (
                        <div className="inventory-row" key={b._id}>
                            {b.medicineId?.name} — Batch {b.batchNumber} — expired {new Date(b.expiryDate).toLocaleDateString()}
                        </div>
                    ))}
                </div>

                <div className="inventory-alert-card near-expiry">
                    <h4>⏰ Expiring Within 30 Days ({overview?.nearExpiryBatches?.length || 0})</h4>
                    {overview?.nearExpiryBatches?.length === 0 && <p>None.</p>}
                    {overview?.nearExpiryBatches?.map((b) => (
                        <div className="inventory-row" key={b._id}>
                            {b.medicineId?.name} — Batch {b.batchNumber} — expires {new Date(b.expiryDate).toLocaleDateString()}
                        </div>
                    ))}
                </div>

                <div className="inventory-alert-card low-stock">
                    <h4>⚠️ Low Stock ({overview?.lowStockMedicines?.length || 0})</h4>
                    {overview?.lowStockMedicines?.length === 0 && <p>None.</p>}
                    {overview?.lowStockMedicines?.map((m) => (
                        <div className="inventory-row" key={m._id}>{m.name} — {m.stock} units left</div>
                    ))}
                </div>

                <div className="inventory-alert-card out-of-stock">
                    <h4>🚫 Out of Stock ({overview?.outOfStockMedicines?.length || 0})</h4>
                    {overview?.outOfStockMedicines?.length === 0 && <p>None.</p>}
                    {overview?.outOfStockMedicines?.map((m) => (
                        <div className="inventory-row" key={m._id}>{m.name}</div>
                    ))}
                </div>
            </div>
        </div>
    );
}

export default InventoryPanel;
