import React, { useEffect, useState } from "react";
import { useAuth } from "../context/AuthContext";

const API_BASE = "http://localhost:5000/api";

function LabTestPanel() {
    const { token } = useAuth();
    const [tests, setTests] = useState([]);
    const [centers, setCenters] = useState([]);
    const [bookings, setBookings] = useState([]);
    const [subTab, setSubTab] = useState("tests");
    const [message, setMessage] = useState("");

    const [showTestForm, setShowTestForm] = useState(false);
    const [testForm, setTestForm] = useState({
        name: "", category: "", description: "", price: "", mrp: "",
        discountPercent: "", sampleType: "Blood", homeCollection: true, preparationInfo: ""
    });

    const [showCenterForm, setShowCenterForm] = useState(false);
    const [centerForm, setCenterForm] = useState({ name: "", address: "", phone: "", openHours: "" });

    const fetchAll = async () => {
        try {
            const [testsRes, centersRes, bookingsRes] = await Promise.all([
                fetch(`${API_BASE}/lab-tests`).then((r) => r.json()),
                fetch(`${API_BASE}/lab-centers`).then((r) => r.json()),
                fetch(`${API_BASE}/lab-bookings`, { headers: { Authorization: `Bearer ${token}` } }).then((r) => r.json())
            ]);
            if (testsRes.success) setTests(testsRes.tests);
            if (centersRes.success) setCenters(centersRes.centers);
            if (bookingsRes.success) setBookings(bookingsRes.bookings);
        } catch (err) {
            console.error(err);
        }
    };

    useEffect(() => { if (token) fetchAll(); }, [token]);

    const handleTestSubmit = async (e) => {
        e.preventDefault();
        try {
            const res = await fetch(`${API_BASE}/lab-tests`, {
                method: "POST",
                headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
                body: JSON.stringify({
                    ...testForm,
                    price: Number(testForm.price),
                    mrp: Number(testForm.mrp),
                    discountPercent: Number(testForm.discountPercent) || 0,
                    parameters: []
                })
            });
            const data = await res.json();
            if (data.success) {
                setMessage("✅ Lab test created");
                setShowTestForm(false);
                setTestForm({ name: "", category: "", description: "", price: "", mrp: "", discountPercent: "", sampleType: "Blood", homeCollection: true, preparationInfo: "" });
                fetchAll();
            } else {
                setMessage(`❌ ${data.message}`);
            }
        } catch (err) {
            setMessage("❌ Failed to create lab test");
        }
        setTimeout(() => setMessage(""), 3000);
    };

    const handleDisableTest = async (id) => {
        await fetch(`${API_BASE}/lab-tests/${id}`, { method: "DELETE", headers: { Authorization: `Bearer ${token}` } });
        fetchAll();
    };

    const handleCenterSubmit = async (e) => {
        e.preventDefault();
        try {
            const res = await fetch(`${API_BASE}/lab-centers`, {
                method: "POST",
                headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
                body: JSON.stringify(centerForm)
            });
            const data = await res.json();
            if (data.success) {
                setMessage("✅ Lab center added");
                setShowCenterForm(false);
                setCenterForm({ name: "", address: "", phone: "", openHours: "" });
                fetchAll();
            }
        } catch (err) {
            setMessage("❌ Failed to add lab center");
        }
        setTimeout(() => setMessage(""), 3000);
    };

    const handleStatusChange = async (bookingId, status) => {
        await fetch(`${API_BASE}/lab-bookings/${bookingId}/status`, {
            method: "PUT",
            headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
            body: JSON.stringify({ status })
        });
        fetchAll();
    };

    return (
        <div className="labtest-panel">

            {message && <div className="inventory-message">{message}</div>}

            <div className="labtest-subtabs">
                <button className={subTab === "tests" ? "active" : ""} onClick={() => setSubTab("tests")}>Lab Tests ({tests.length})</button>
                <button className={subTab === "centers" ? "active" : ""} onClick={() => setSubTab("centers")}>Centers ({centers.length})</button>
                <button className={subTab === "bookings" ? "active" : ""} onClick={() => setSubTab("bookings")}>Bookings ({bookings.length})</button>
            </div>

            {subTab === "tests" && (
                <>
                    <div className="inventory-header">
                        <h3>Lab Test Catalog</h3>
                        <button className="add-batch-btn" onClick={() => setShowTestForm(!showTestForm)}>
                            {showTestForm ? "Cancel" : "+ Add Lab Test"}
                        </button>
                    </div>

                    {showTestForm && (
                        <form className="batch-form" onSubmit={handleTestSubmit}>
                            <input placeholder="Test name" value={testForm.name} onChange={(e) => setTestForm({ ...testForm, name: e.target.value })} required />
                            <input placeholder="Category (e.g. Full Body Checkup)" value={testForm.category} onChange={(e) => setTestForm({ ...testForm, category: e.target.value })} required />
                            <input placeholder="Sample type" value={testForm.sampleType} onChange={(e) => setTestForm({ ...testForm, sampleType: e.target.value })} />
                            <input type="number" placeholder="MRP" value={testForm.mrp} onChange={(e) => setTestForm({ ...testForm, mrp: e.target.value })} required />
                            <input type="number" placeholder="Price" value={testForm.price} onChange={(e) => setTestForm({ ...testForm, price: e.target.value })} required />
                            <input type="number" placeholder="Discount %" value={testForm.discountPercent} onChange={(e) => setTestForm({ ...testForm, discountPercent: e.target.value })} />
                            <textarea placeholder="Description" value={testForm.description} onChange={(e) => setTestForm({ ...testForm, description: e.target.value })} />
                            <button type="submit" className="save-batch-btn">Save Lab Test</button>
                        </form>
                    )}

                    <div className="labtest-list">
                        {tests.map((t) => (
                            <div className="inventory-row" key={t._id}>
                                <span>{t.name}</span>
                                <span>{t.category}</span>
                                <span>₹{t.price} (MRP ₹{t.mrp})</span>
                                <button className="disable-btn" onClick={() => handleDisableTest(t._id)}>Disable</button>
                            </div>
                        ))}
                    </div>
                </>
            )}

            {subTab === "centers" && (
                <>
                    <div className="inventory-header">
                        <h3>Lab Collection Centers</h3>
                        <button className="add-batch-btn" onClick={() => setShowCenterForm(!showCenterForm)}>
                            {showCenterForm ? "Cancel" : "+ Add Center"}
                        </button>
                    </div>

                    {showCenterForm && (
                        <form className="batch-form" onSubmit={handleCenterSubmit}>
                            <input placeholder="Center name" value={centerForm.name} onChange={(e) => setCenterForm({ ...centerForm, name: e.target.value })} required />
                            <input placeholder="Address" value={centerForm.address} onChange={(e) => setCenterForm({ ...centerForm, address: e.target.value })} required />
                            <input placeholder="Phone" value={centerForm.phone} onChange={(e) => setCenterForm({ ...centerForm, phone: e.target.value })} />
                            <input placeholder="Open hours" value={centerForm.openHours} onChange={(e) => setCenterForm({ ...centerForm, openHours: e.target.value })} />
                            <button type="submit" className="save-batch-btn">Save Center</button>
                        </form>
                    )}

                    <div className="labtest-list">
                        {centers.map((c) => (
                            <div className="inventory-row" key={c._id}>
                                <span>{c.name}</span>
                                <span>{c.address}</span>
                                <span>⭐ {c.rating}</span>
                            </div>
                        ))}
                    </div>
                </>
            )}

            {subTab === "bookings" && (
                <div className="labtest-list">
                    {bookings.map((b) => (
                        <div className="inventory-row labtest-booking-row" key={b._id}>
                            <span>{b.bookingId}</span>
                            <span>{b.testName}</span>
                            <span>{b.userId?.name}</span>
                            <select value={b.bookingStatus} onChange={(e) => handleStatusChange(b._id, e.target.value)}>
                                {["Confirmed", "Scheduled", "SampleCollected", "SampleReceived", "Testing", "ReportReady", "Cancelled"].map((s) => (
                                    <option key={s} value={s}>{s}</option>
                                ))}
                            </select>
                        </div>
                    ))}
                </div>
            )}

        </div>
    );
}

export default LabTestPanel;
