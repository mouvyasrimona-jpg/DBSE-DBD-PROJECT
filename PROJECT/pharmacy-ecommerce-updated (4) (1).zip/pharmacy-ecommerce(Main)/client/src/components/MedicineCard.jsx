import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import "./MedicineCard.css";

const IMAGE_BASE = "http://localhost:5000";

function MedicineCard({ medicine }) {
    const navigate = useNavigate();
    const { isAuthenticated, token } = useAuth();
    const [added, setAdded] = useState(false);

    if (!medicine) return null;

    const inStock = medicine.stock > 0;

    // Best available price across pharmacies, matching the same
    // discount logic used on Medicine Details, so numbers shown
    // here are never invented separately.
    const bestShop = (medicine.availableShops || [])
        .filter((s) => s.price != null)
        .sort((a, b) => (a.price * (1 - (a.discountPercent || 0) / 100)) - (b.price * (1 - (b.discountPercent || 0) / 100)))[0];

    const mrp = bestShop?.price ?? medicine.price;
    const discountPercent = bestShop?.discountPercent || 0;
    const finalPrice = Math.round(mrp * (1 - discountPercent / 100));

    const imageUrl = medicine.image
        ? (medicine.image.startsWith("http") ? medicine.image : `${IMAGE_BASE}${medicine.image}`)
        : null;

    const handleQuickAdd = (e) => {
        e.stopPropagation();

        if (!isAuthenticated || !token) {
            navigate("/login", { state: { from: "/medicines" } });
            return;
        }

        // Prescription-required medicines always go through the
        // full verification flow on the details page — never a
        // one-click add from a listing card.
        if (medicine.prescriptionRequired) {
            navigate(`/medicines/${medicine._id}`);
            return;
        }

        let currentCart = [];
        const stored = localStorage.getItem("cart");
        if (stored) {
            try { currentCart = JSON.parse(stored); } catch { currentCart = []; }
        }

        const existingIndex = currentCart.findIndex((c) => c._id === medicine._id);
        if (existingIndex > -1) {
            currentCart[existingIndex].cartQuantity = Math.min(
                currentCart[existingIndex].cartQuantity + 1,
                medicine.stock
            );
        } else {
            currentCart.push({
                _id: medicine._id,
                name: medicine.name,
                price: medicine.price,
                stock: medicine.stock,
                image: medicine.image || "",
                category: medicine.category || "",
                genericName: medicine.genericName || "",
                prescriptionRequired: false,
                selectedPharmacy: null,
                cartQuantity: 1
            });
        }

        localStorage.setItem("cart", JSON.stringify(currentCart));
        window.dispatchEvent(new Event("cartUpdated"));
        setAdded(true);
        setTimeout(() => setAdded(false), 1500);
    };

    return (
        <div className="medicine-card" onClick={() => navigate(`/medicines/${medicine._id}`)}>

            <div className="medicine-card-image">
                {imageUrl ? (
                    <img src={imageUrl} alt={medicine.name} loading="lazy" />
                ) : (
                    <span className="medicine-card-placeholder">💊</span>
                )}

                {medicine.prescriptionRequired && (
                    <span className="rx-required-badge">Rx Required</span>
                )}
            </div>

            <div className="medicine-card-body">
                <h4>{medicine.name}</h4>
                {medicine.genericName && <p className="generic-name">Generic: {medicine.genericName}</p>}

                <div className="price-row">
                    <span className="final-price">₹{finalPrice}</span>
                    {discountPercent > 0 && (
                        <>
                            <span className="mrp-price">MRP ₹{mrp}</span>
                            <span className="discount-tag">{discountPercent}% OFF</span>
                        </>
                    )}
                </div>

                {medicine.rating > 0 && (
                    <div className="card-rating">⭐ {medicine.rating.toFixed(1)} {medicine.reviewCount > 0 && `(${medicine.reviewCount})`}</div>
                )}

                <div className={`stock-line ${inStock ? "in" : "out"}`}>
                    {inStock ? "✓ In Stock" : "✕ Out of Stock"}
                </div>

                <button
                    className="card-add-btn"
                    onClick={handleQuickAdd}
                    disabled={!inStock}
                >
                    {added ? "✓ Added" : !inStock ? "Out of Stock" : medicine.prescriptionRequired ? "View & Order" : "Add to Cart"}
                </button>
            </div>

        </div>
    );
}

export default MedicineCard;
