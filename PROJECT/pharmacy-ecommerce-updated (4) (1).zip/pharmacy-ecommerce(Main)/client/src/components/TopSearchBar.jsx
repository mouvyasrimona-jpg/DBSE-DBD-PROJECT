import React, { useEffect, useState } from "react";
import { Link, useNavigate, useSearchParams } from "react-router-dom";
import "./TopSearchBar.css";

const API_URL = "http://localhost:5000/api/medicines";

function TopSearchBar() {
    const navigate = useNavigate();
    const [searchParams] = useSearchParams();

    const [query, setQuery] = useState(searchParams.get("q") || "");
    const [searching, setSearching] = useState(false);
    const [categories, setCategories] = useState([]);

    // Real distinct categories from the database — never hardcoded,
    // so a category pill always leads to actual matching medicines.
    useEffect(() => {
        fetch(`${API_URL}/categories`)
            .then((res) => res.json())
            .then((data) => {
                if (data.success) setCategories(data.categories.slice(0, 6));
            })
            .catch(() => setCategories([]));
    }, []);

    const handleSearchSubmit = async (e) => {
        e.preventDefault();

        const trimmed = query.trim();

        if (!trimmed) {
            navigate("/medicines");
            return;
        }

        try {
            setSearching(true);

            const response = await fetch(
                `${API_URL}/search?query=${encodeURIComponent(trimmed)}`
            );
            const data = await response.json();

            const results = data.success ? data.medicines || [] : [];

            // A "strong match" is either the only result, or a result
            // whose name matches the typed query exactly (ignoring case) —
            // e.g. typing "Dolo 650 Tablet" or just "Dolo 650" should both
            // jump straight to that medicine's details page.
            const exactMatch = results.find(
                (medicine) =>
                    medicine.name?.trim().toLowerCase() === trimmed.toLowerCase()
            );

            if (exactMatch) {
                navigate(`/medicines/${exactMatch._id}`);
            } else if (results.length === 1) {
                navigate(`/medicines/${results[0]._id}`);
            } else {
                // Multiple matches, or zero matches — go to the
                // Medicines list, which will show results or a
                // "not found" empty state for this same query.
                navigate(`/medicines?q=${encodeURIComponent(trimmed)}`);
            }

        } catch (err) {
            console.error("Search error:", err);
            // If the search API call itself fails, fall back to the
            // normal list page rather than leaving the user stuck.
            navigate(`/medicines?q=${encodeURIComponent(trimmed)}`);
        } finally {
            setSearching(false);
        }
    };

    const handleCategoryClick = (categoryName) => {
        navigate(`/medicines?category=${encodeURIComponent(categoryName)}`);
    };

    return (
        <div className="top-search-bar-wrapper">
            <div className="top-search-bar-container">

                <div className="search-heading-row">
                    <h2 className="search-heading">What are you looking for?</h2>
                    <Link to="/prescription" className="rx-upload-cta">
                        📄 Order with prescription. <strong>UPLOAD NOW ›</strong>
                    </Link>
                </div>

                {/* SEARCH FORM */}
                <form onSubmit={handleSearchSubmit} className="top-search-form">
                    <div className="top-search-input-box">
                        <span className="search-icon-symbol">🔍</span>
                        <input
                            type="text"
                            placeholder="Search medicines, generic names, health conditions, or brands..."
                            value={query}
                            onChange={(e) => setQuery(e.target.value)}
                        />
                        {query && (
                            <button
                                type="button"
                                className="clear-search-btn"
                                onClick={() => {
                                    setQuery("");
                                    navigate("/medicines");
                                }}
                            >
                                ✕
                            </button>
                        )}
                    </div>

                    <button type="submit" className="top-search-btn" disabled={searching}>
                        {searching ? "Searching..." : "Search Store 💊"}
                    </button>
                </form>

                {/* QUICK CATEGORY PILLS */}
                {categories.length > 0 && (
                    <div className="top-search-shortcuts">
                        <span className="shortcuts-label">Quick Search:</span>
                        <div className="shortcut-pills">
                            {categories.map((cat) => (
                                <button
                                    key={cat}
                                    type="button"
                                    className="shortcut-pill-btn"
                                    onClick={() => handleCategoryClick(cat)}
                                >
                                    {cat}
                                </button>
                            ))}
                        </div>
                    </div>
                )}

                {/* SERVICE TRUST BADGES */}
                <div className="top-trust-badges">
                    <span className="trust-badge">⚡ 24h Express Delivery</span>
                    <span className="trust-badge">🛡️ 100% Genuine Medicines</span>
                    <span className="trust-badge">📄 Licensed Pharmacist Verified</span>
                </div>

            </div>
        </div>
    );
}

export default TopSearchBar;

