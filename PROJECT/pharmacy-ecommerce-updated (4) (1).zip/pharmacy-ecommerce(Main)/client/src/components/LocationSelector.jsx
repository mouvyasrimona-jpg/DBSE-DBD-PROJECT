import React, { useEffect, useState } from "react";
import "./LocationSelector.css";

function LocationSelector() {
    const [open, setOpen] = useState(false);
    const [location, setLocation] = useState(() => {
        const saved = localStorage.getItem("deliveryLocation");
        return saved ? JSON.parse(saved) : null;
    });

    const [city, setCity] = useState("");
    const [area, setArea] = useState("");
    const [pincode, setPincode] = useState("");

    useEffect(() => {
        if (location) {
            setCity(location.city || "");
            setArea(location.area || "");
            setPincode(location.pincode || "");
        }
    }, [open]);

    const handleSave = (e) => {
        e.preventDefault();
        if (!city.trim() || !pincode.trim()) return;

        const newLocation = { city: city.trim(), area: area.trim(), pincode: pincode.trim() };
        localStorage.setItem("deliveryLocation", JSON.stringify(newLocation));
        setLocation(newLocation);
        setOpen(false);
    };

    return (
        <div className="location-selector">
            <button className="location-trigger" onClick={() => setOpen(true)}>
                <span className="location-icon">📍</span>
                <span className="location-text">
                    <small>Deliver to</small>
                    <strong>{location ? `${location.area || location.city}, ${location.pincode}` : "Select Location"}</strong>
                </span>
            </button>

            {open && (
                <div className="location-modal-overlay" onClick={() => setOpen(false)}>
                    <div className="location-modal" onClick={(e) => e.stopPropagation()}>
                        <h3>Select Delivery Location</h3>
                        <p>We'll show pharmacies and delivery estimates for this area.</p>

                        <form onSubmit={handleSave}>
                            <label>City</label>
                            <input value={city} onChange={(e) => setCity(e.target.value)} placeholder="e.g. Hyderabad" required />

                            <label>Area / Locality</label>
                            <input value={area} onChange={(e) => setArea(e.target.value)} placeholder="e.g. Gachibowli" />

                            <label>Pincode</label>
                            <input value={pincode} onChange={(e) => setPincode(e.target.value)} placeholder="e.g. 500032" required maxLength={6} />

                            <div className="location-modal-actions">
                                <button type="button" className="location-cancel" onClick={() => setOpen(false)}>Cancel</button>
                                <button type="submit" className="location-save">Save Location</button>
                            </div>
                        </form>
                    </div>
                </div>
            )}
        </div>
    );
}

export default LocationSelector;
