import React, { useEffect, useRef, useState } from "react";
import { useAuth } from "../context/AuthContext";
import "./NotificationBell.css";

const API_BASE = "http://localhost:5000/api";

function NotificationBell() {
    const { token, isAuthenticated } = useAuth();
    const [open, setOpen] = useState(false);
    const [notifications, setNotifications] = useState([]);
    const [unreadCount, setUnreadCount] = useState(0);
    const wrapperRef = useRef(null);

    const fetchNotifications = async () => {
        if (!token) return;
        try {
            const res = await fetch(`${API_BASE}/notifications`, {
                headers: { Authorization: `Bearer ${token}` }
            });
            const data = await res.json();
            if (data.success) {
                setNotifications(data.notifications);
                setUnreadCount(data.unreadCount);
            }
        } catch (err) {
            console.error("Notification fetch error:", err);
        }
    };

    useEffect(() => {
        if (!isAuthenticated) return;
        fetchNotifications();
        // Poll every 30s — simple, no websocket infrastructure needed
        const interval = setInterval(fetchNotifications, 30000);
        return () => clearInterval(interval);
    }, [isAuthenticated, token]);

    useEffect(() => {
        const handleClickOutside = (e) => {
            if (wrapperRef.current && !wrapperRef.current.contains(e.target)) {
                setOpen(false);
            }
        };
        document.addEventListener("mousedown", handleClickOutside);
        return () => document.removeEventListener("mousedown", handleClickOutside);
    }, []);

    const markAsRead = async (id) => {
        try {
            await fetch(`${API_BASE}/notifications/${id}/read`, {
                method: "PUT",
                headers: { Authorization: `Bearer ${token}` }
            });
            setNotifications((prev) => prev.map((n) => (n._id === id ? { ...n, isRead: true } : n)));
            setUnreadCount((prev) => Math.max(0, prev - 1));
        } catch (err) {
            console.error(err);
        }
    };

    const markAllRead = async () => {
        try {
            await fetch(`${API_BASE}/notifications/read-all`, {
                method: "PUT",
                headers: { Authorization: `Bearer ${token}` }
            });
            setNotifications((prev) => prev.map((n) => ({ ...n, isRead: true })));
            setUnreadCount(0);
        } catch (err) {
            console.error(err);
        }
    };

    const timeAgo = (dateStr) => {
        const diffMs = Date.now() - new Date(dateStr).getTime();
        const mins = Math.floor(diffMs / 60000);
        if (mins < 1) return "just now";
        if (mins < 60) return `${mins}m ago`;
        const hours = Math.floor(mins / 60);
        if (hours < 24) return `${hours}h ago`;
        return `${Math.floor(hours / 24)}d ago`;
    };

    if (!isAuthenticated) return null;

    return (
        <div className="notif-bell-wrapper" ref={wrapperRef}>
            <button className="notif-bell-btn" onClick={() => setOpen((o) => !o)}>
                🔔
                {unreadCount > 0 && <span className="notif-badge">{unreadCount > 9 ? "9+" : unreadCount}</span>}
            </button>

            {open && (
                <div className="notif-dropdown">
                    <div className="notif-dropdown-header">
                        <span>Notifications</span>
                        {unreadCount > 0 && (
                            <button className="notif-mark-all" onClick={markAllRead}>Mark all read</button>
                        )}
                    </div>

                    <div className="notif-list">
                        {notifications.length === 0 ? (
                            <div className="notif-empty">No notifications yet.</div>
                        ) : (
                            notifications.map((n) => (
                                <div
                                    key={n._id}
                                    className={`notif-item ${!n.isRead ? "unread" : ""}`}
                                    onClick={() => !n.isRead && markAsRead(n._id)}
                                >
                                    <strong>{n.title}</strong>
                                    <p>{n.message}</p>
                                    <span className="notif-time">{timeAgo(n.createdAt)}</span>
                                </div>
                            ))
                        )}
                    </div>
                </div>
            )}
        </div>
    );
}

export default NotificationBell;
