import React from "react";
import { Navigate, Outlet, useLocation } from "react-router-dom";
import { useAuth } from "../context/AuthContext";

const ProtectedRoute = () => {
  const { isAuthenticated, loading } = useAuth();
  const location = useLocation();

  // Session check complete ayye varaku wait
  if (loading) {
    return (
      <div style={{ textAlign: "center", padding: "50px" }}>
        Checking authentication...
      </div>
    );
  }

  // Login kakapothe login page ki pampinchali
  if (!isAuthenticated) {
    return (
      <Navigate
        to="/login"
        replace
        state={{ from: location.pathname }}
      />
    );
  }

  // Login ayithe requested page ki allow
  return <Outlet />;
};

export default ProtectedRoute;