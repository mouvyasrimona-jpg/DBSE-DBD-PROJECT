import React, { useEffect, useState } from "react";
import { useAuth } from "../context/AuthContext";
import { useNavigate } from "react-router-dom";
import "./AdminDashboard.css";
import AnalyticsPanel from "../components/AnalyticsPanel";
import InventoryPanel from "../components/InventoryPanel";
import LabTestPanel from "../components/LabTestPanel";

const API_BASE = "http://localhost:5000/api";

function AdminDashboard() {
    const navigate = useNavigate();
    const { token, user, isAuthenticated } = useAuth();

    const [activeTab, setActiveTab] = useState("overview");

    // Data state
    const [medicines, setMedicines] = useState([]);
    const [orders, setOrders] = useState([]);
    const [prescriptions, setPrescriptions] = useState([]);
    const [loading, setLoading] = useState(true);
    const [message, setMessage] = useState({ type: "", text: "" });

    // Add Medicine Form state
    const [showAddModal, setShowAddModal] = useState(false);
    const [medForm, setMedForm] = useState({
        name: "",
        genericName: "",
        brand: "",
        manufacturer: "",
        category: "Pain Relief",
        therapeuticCategory: "",
        form: "Tablet",
        dosage: "500mg",
        condition: "Fever & Pain",
        price: "",
        stock: "",
        prescriptionRequired: false,
        image: "",
        description: ""
    });

    const [editingMedId, setEditingMedId] = useState(null);

    // Verify admin role
    useEffect(() => {
        if (!isAuthenticated) {
            navigate("/login");
            return;
        }

        if (user && user.role !== "admin" && user.role !== "pharmacist") {
            navigate("/");
            return;
        }

        fetchAllData();
    }, [isAuthenticated, user, token, navigate]);

    const fetchAllData = async () => {
        try {
            setLoading(true);
            const headers = { Authorization: `Bearer ${token}` };

            const [medRes, orderRes, rxRes] = await Promise.all([
                fetch(`${API_BASE}/medicines`),
                fetch(`${API_BASE}/orders`, { headers }),
                fetch(`${API_BASE}/prescriptions`, { headers })
            ]);

            const medData = await medRes.json();
            const orderData = await orderRes.json();
            const rxData = await rxRes.json();

            if (medData.success) setMedicines(medData.medicines || []);
            if (orderData.success) setOrders(orderData.orders || []);
            if (rxData.success) setPrescriptions(rxData.prescriptions || []);

        } catch (err) {
            console.error("Admin data fetch error:", err);
            setMessage({ type: "error", text: "Failed to load dashboard data." });
        } finally {
            setLoading(false);
        }
    };

    // Calculate Dashboard Stats
    const totalRevenue = orders.reduce((sum, o) => sum + (Number(o.totalAmount) || 0), 0);
    const pendingOrdersCount = orders.filter((o) => o.status === "Pending").length;
    const pendingRxCount = prescriptions.filter((r) => r.status === "Pending").length;

    // Medicine Form Handlers
    const handleMedInputChange = (e) => {
        const { name, value, type, checked } = e.target;
        setMedForm((prev) => ({
            ...prev,
            [name]: type === "checkbox" ? checked : value
        }));
    };

    const handleSaveMedicine = async (e) => {
        e.preventDefault();
        setMessage({ type: "", text: "" });

        if (!medForm.name || !medForm.price || medForm.stock === "") {
            setMessage({ type: "error", text: "Medicine name, price, and stock are required." });
            return;
        }

        try {
            const url = editingMedId
                ? `${API_BASE}/medicines/${editingMedId}`
                : `${API_BASE}/medicines`;
            const method = editingMedId ? "PUT" : "POST";

            const res = await fetch(url, {
                method,
                headers: {
                    "Content-Type": "application/json",
                    Authorization: `Bearer ${token}`
                },
                body: JSON.stringify(medForm)
            });

            const data = await res.json();

            if (res.ok && data.success) {
                setMessage({
                    type: "success",
                    text: editingMedId ? "Medicine updated!" : "New medicine added successfully!"
                });
                setShowAddModal(false);
                setEditingMedId(null);
                resetMedForm();
                fetchAllData();
            } else {
                setMessage({ type: "error", text: data.message || "Operation failed." });
            }
        } catch (err) {
            setMessage({ type: "error", text: err.message });
        }
    };

    const resetMedForm = () => {
        setMedForm({
            name: "",
            genericName: "",
            brand: "",
            manufacturer: "",
            category: "Pain Relief",
            therapeuticCategory: "",
            form: "Tablet",
            dosage: "500mg",
            condition: "Fever & Pain",
            price: "",
            stock: "",
            prescriptionRequired: false,
            image: "",
            description: ""
        });
    };

    const handleEditMedicine = (med) => {
        setEditingMedId(med._id);
        setMedForm({
            name: med.name || "",
            genericName: med.genericName || "",
            brand: med.brand || "",
            manufacturer: med.manufacturer || "",
            category: med.category || "General",
            therapeuticCategory: med.therapeuticCategory || "",
            form: med.form || "Tablet",
            dosage: med.dosage || "",
            condition: med.condition || "",
            price: med.price || "",
            stock: med.stock || 0,
            prescriptionRequired: !!med.prescriptionRequired,
            image: med.image || "",
            description: med.description || ""
        });
        setShowAddModal(true);
    };

    const handleDeleteMedicine = async (medId) => {
        if (!window.confirm("Are you sure you want to delete this medicine?")) return;

        try {
            const res = await fetch(`${API_BASE}/medicines/${medId}`, {
                method: "DELETE",
                headers: { Authorization: `Bearer ${token}` }
            });
            const data = await res.json();
            if (res.ok && data.success) {
                setMessage({ type: "success", text: "Medicine deleted successfully." });
                fetchAllData();
            } else {
                setMessage({ type: "error", text: data.message });
            }
        } catch (err) {
            setMessage({ type: "error", text: err.message });
        }
    };

    // Update Order Status
    const handleOrderStatusChange = async (orderId, newStatus) => {
        try {
            const res = await fetch(`${API_BASE}/orders/${orderId}/status`, {
                method: "PUT",
                headers: {
                    "Content-Type": "application/json",
                    Authorization: `Bearer ${token}`
                },
                body: JSON.stringify({ status: newStatus })
            });

            const data = await res.json();
            if (res.ok && data.success) {
                setMessage({ type: "success", text: `Order #${orderId} status updated to ${newStatus}` });
                fetchAllData();
            } else {
                setMessage({ type: "error", text: data.message });
            }
        } catch (err) {
            setMessage({ type: "error", text: err.message });
        }
    };

    // Update Prescription Status
    const handlePrescriptionStatus = async (rxId, newStatus) => {
        const rejectionReason = newStatus === "Rejected"
            ? prompt("Enter rejection reason for customer:")
            : "";

        try {
            const res = await fetch(`${API_BASE}/prescriptions/${rxId}/status`, {
                method: "PUT",
                headers: {
                    "Content-Type": "application/json",
                    Authorization: `Bearer ${token}`
                },
                body: JSON.stringify({ status: newStatus, rejectionReason })
            });

            const data = await res.json();
            if (res.ok && data.success) {
                setMessage({ type: "success", text: `Prescription marked as ${newStatus}` });
                fetchAllData();
            } else {
                setMessage({ type: "error", text: data.message });
            }
        } catch (err) {
            setMessage({ type: "error", text: err.message });
        }
    };

    return (
        <div className="admin-dashboard-page">
            {/* HEADER */}
            <div className="admin-header">
                <div>
                    <span className="admin-badge">🛡️ Admin Portal</span>
                    <h1>Pharmacy <span>Management Dashboard</span></h1>
                    <p>Manage medicines, inventory stock, customer orders, and prescription reviews.</p>
                </div>
            </div>

            {/* MESSAGE ALERT */}
            {message.text && (
                <div className={`admin-alert ${message.type}`}>
                    {message.type === "success" ? "✅" : "⚠️"} {message.text}
                </div>
            )}

            {/* TAB NAVIGATION */}
            <div className="admin-tabs">
                <button
                    className={`tab-btn ${activeTab === "overview" ? "active" : ""}`}
                    onClick={() => setActiveTab("overview")}
                >
                    📊 Overview
                </button>
                <button
                    className={`tab-btn ${activeTab === "medicines" ? "active" : ""}`}
                    onClick={() => setActiveTab("medicines")}
                >
                    💊 Medicines ({medicines.length})
                </button>
                <button
                    className={`tab-btn ${activeTab === "orders" ? "active" : ""}`}
                    onClick={() => setActiveTab("orders")}
                >
                    📦 Customer Orders ({orders.length})
                </button>
                <button
                    className={`tab-btn ${activeTab === "prescriptions" ? "active" : ""}`}
                    onClick={() => setActiveTab("prescriptions")}
                >
                    📄 Prescriptions ({pendingRxCount} Pending)
                </button>
                <button
                    className={`tab-btn ${activeTab === "analytics" ? "active" : ""}`}
                    onClick={() => setActiveTab("analytics")}
                >
                    📈 Analytics
                </button>
                <button
                    className={`tab-btn ${activeTab === "inventory" ? "active" : ""}`}
                    onClick={() => setActiveTab("inventory")}
                >
                    🏭 Inventory
                </button>
                <button
                    className={`tab-btn ${activeTab === "labtests" ? "active" : ""}`}
                    onClick={() => setActiveTab("labtests")}
                >
                    🧪 Lab Tests
                </button>
            </div>

            {loading ? (
                <div className="admin-loading">
                    <div className="loader"></div>
                    <p>Loading Admin Dashboard...</p>
                </div>
            ) : (
                <div className="admin-tab-content">
                    {/* TAB 1: OVERVIEW */}
                    {activeTab === "overview" && (
                        <div className="overview-tab">
                            <div className="stats-grid">
                                <div className="stat-card">
                                    <div className="stat-icon">💰</div>
                                    <div>
                                        <span className="stat-label">Total Revenue</span>
                                        <h2>₹{totalRevenue.toFixed(2)}</h2>
                                    </div>
                                </div>

                                <div className="stat-card">
                                    <div className="stat-icon">📦</div>
                                    <div>
                                        <span className="stat-label">Total Orders</span>
                                        <h2>{orders.length}</h2>
                                    </div>
                                </div>

                                <div className="stat-card">
                                    <div className="stat-icon">⏳</div>
                                    <div>
                                        <span className="stat-label">Pending Orders</span>
                                        <h2>{pendingOrdersCount}</h2>
                                    </div>
                                </div>

                                <div className="stat-card">
                                    <div className="stat-icon">💊</div>
                                    <div>
                                        <span className="stat-label">Total Medicines</span>
                                        <h2>{medicines.length}</h2>
                                    </div>
                                </div>

                                <div className="stat-card">
                                    <div className="stat-icon">📄</div>
                                    <div>
                                        <span className="stat-label">Pending Prescriptions</span>
                                        <h2>{pendingRxCount}</h2>
                                    </div>
                                </div>
                            </div>
                        </div>
                    )}

                    {/* TAB 2: MEDICINES MANAGEMENT */}
                    {activeTab === "medicines" && (
                        <div className="medicines-tab">
                            <div className="tab-actions-header">
                                <h3>Medicine Inventory</h3>
                                <button
                                    className="add-med-btn"
                                    onClick={() => {
                                        setEditingMedId(null);
                                        resetMedForm();
                                        setShowAddModal(true);
                                    }}
                                >
                                    + Add New Medicine
                                </button>
                            </div>

                            <table className="admin-table">
                                <thead>
                                    <tr>
                                        <th>Medicine</th>
                                        <th>Category</th>
                                        <th>Price</th>
                                        <th>Stock</th>
                                        <th>Rx Required</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {medicines.map((med) => (
                                        <tr key={med._id}>
                                            <td>
                                                <strong>{med.name}</strong>
                                                <br />
                                                <small className="txt-muted">{med.genericName}</small>
                                            </td>
                                            <td>{med.category}</td>
                                            <td><strong>₹{med.price}</strong></td>
                                            <td>
                                                <span className={`stock-badge ${med.stock > 0 ? "in-stock" : "out-stock"}`}>
                                                    {med.stock} units
                                                </span>
                                            </td>
                                            <td>{med.prescriptionRequired ? "📄 Yes" : "No"}</td>
                                            <td>
                                                <button
                                                    className="action-btn edit-btn"
                                                    onClick={() => handleEditMedicine(med)}
                                                >
                                                    Edit
                                                </button>
                                                <button
                                                    className="action-btn delete-btn"
                                                    onClick={() => handleDeleteMedicine(med._id)}
                                                >
                                                    Delete
                                                </button>
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    )}

                    {/* TAB 3: CUSTOMER ORDERS */}
                    {activeTab === "orders" && (
                        <div className="orders-tab">
                            <h3>Customer Order Management</h3>
                            <table className="admin-table">
                                <thead>
                                    <tr>
                                        <th>Order ID & Date</th>
                                        <th>Customer</th>
                                        <th>Items</th>
                                        <th>Total</th>
                                        <th>Payment</th>
                                        <th>Status</th>
                                        <th>Update Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {orders.map((ord) => (
                                        <tr key={ord._id}>
                                            <td>
                                                <strong>#{ord._id}</strong>
                                                <br />
                                                <small className="txt-muted">
                                                    {new Date(ord.createdAt).toLocaleDateString()}
                                                </small>
                                            </td>
                                            <td>
                                                <strong>{ord.userId?.name || ord.shippingAddress?.name}</strong>
                                                <br />
                                                <small className="txt-muted">{ord.shippingAddress?.phone}</small>
                                            </td>
                                            <td>
                                                {ord.items?.map((i, idx) => (
                                                    <div key={idx} className="order-mini-item">
                                                        💊 {i.name} × {i.quantity}
                                                    </div>
                                                ))}
                                            </td>
                                            <td><strong>₹{Number(ord.totalAmount).toFixed(2)}</strong></td>
                                            <td>{ord.paymentMethod} ({ord.paymentStatus})</td>
                                            <td>
                                                <span className={`status-pill ${ord.status?.toLowerCase()}`}>
                                                    {ord.status}
                                                </span>
                                            </td>
                                            <td>
                                                <select
                                                    value={ord.status}
                                                    onChange={(e) => handleOrderStatusChange(ord._id, e.target.value)}
                                                    className="status-select"
                                                >
                                                    <option value="Pending">Pending</option>
                                                    <option value="Confirmed">Confirmed</option>
                                                    <option value="Preparing">Preparing</option>
                                                    <option value="Packed">Packed</option>
                                                    <option value="PickedUp">Picked Up</option>
                                                    <option value="OutForDelivery">Out for Delivery</option>
                                                    <option value="Delivered">Delivered</option>
                                                    <option value="Cancelled">Cancelled</option>
                                                    <option value="Failed">Failed</option>
                                                    <option value="Returned">Returned</option>
                                                </select>
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    )}

                    {/* TAB 4: PRESCRIPTION REVIEWS */}
                    {activeTab === "prescriptions" && (
                        <div className="rx-tab">
                            <h3>Uploaded Prescription Reviews</h3>
                            <table className="admin-table">
                                <thead>
                                    <tr>
                                        <th>Date</th>
                                        <th>Customer</th>
                                        <th>Prescription File</th>
                                        <th>OCR Detected Medicines</th>
                                        <th>Status</th>
                                        <th>Review Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    {prescriptions.map((rx) => (
                                        <tr key={rx._id}>
                                            <td>{new Date(rx.createdAt).toLocaleDateString()}</td>
                                            <td>
                                                <strong>{rx.userId?.name || "Customer"}</strong>
                                                <br />
                                                <small className="txt-muted">{rx.userId?.email}</small>
                                            </td>
                                            <td>
                                                <a
                                                    href={`http://localhost:5000${rx.filePath}`}
                                                    target="_blank"
                                                    rel="noopener noreferrer"
                                                    className="rx-file-link"
                                                >
                                                    📄 {rx.originalName} ↗
                                                </a>
                                            </td>
                                            <td>
                                                {rx.detectedMedicines && rx.detectedMedicines.length > 0 ? (
                                                    <div className="admin-rx-meds">
                                                        {rx.detectedMedicines.map((m, i) => (
                                                            <span key={i} className="admin-med-chip">💊 {m}</span>
                                                        ))}
                                                    </div>
                                                ) : (
                                                    <span className="txt-muted">No medicines detected</span>
                                                )}
                                                {rx.ocrDetectedText && (
                                                    <div className="admin-ocr-snippet" title={rx.ocrDetectedText}>
                                                        "{rx.ocrDetectedText.slice(0, 60)}..."
                                                    </div>
                                                )}
                                            </td>
                                            <td>
                                                <span className={`status-pill ${rx.status?.toLowerCase()}`}>
                                                    {rx.status}
                                                </span>
                                            </td>
                                            <td>
                                                <div className="table-actions-cell">
                                                    <button
                                                        className="action-btn approve-btn"
                                                        onClick={() => handlePrescriptionStatus(rx._id, "Approved")}
                                                    >
                                                        Approve ✓
                                                    </button>
                                                    <button
                                                        className="action-btn reject-btn"
                                                        onClick={() => handlePrescriptionStatus(rx._id, "Rejected")}
                                                    >
                                                        Reject ✕
                                                    </button>
                                                </div>
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    )}

                    {/* TAB 5: ANALYTICS */}
                    {activeTab === "analytics" && <AnalyticsPanel />}

                    {/* TAB 6: INVENTORY */}
                    {activeTab === "inventory" && <InventoryPanel />}

                    {activeTab === "labtests" && <LabTestPanel />}
                </div>
            )}

            {/* ADD / EDIT MEDICINE MODAL */}
            {showAddModal && (
                <div className="modal-overlay">
                    <div className="modal-content">
                        <h2>{editingMedId ? "Edit Medicine" : "Add New Medicine"}</h2>
                        <form onSubmit={handleSaveMedicine} className="med-form">
                            <div className="form-grid">
                                <div className="form-group">
                                    <label>Medicine Name *</label>
                                    <input
                                        type="text"
                                        name="name"
                                        required
                                        value={medForm.name}
                                        onChange={handleMedInputChange}
                                    />
                                </div>

                                <div className="form-group">
                                    <label>Generic Name</label>
                                    <input
                                        type="text"
                                        name="genericName"
                                        value={medForm.genericName}
                                        onChange={handleMedInputChange}
                                    />
                                </div>

                                <div className="form-group">
                                    <label>Brand</label>
                                    <input
                                        type="text"
                                        name="brand"
                                        value={medForm.brand}
                                        onChange={handleMedInputChange}
                                    />
                                </div>

                                <div className="form-group">
                                    <label>Manufacturer</label>
                                    <input
                                        type="text"
                                        name="manufacturer"
                                        value={medForm.manufacturer}
                                        onChange={handleMedInputChange}
                                        required
                                    />
                                </div>

                                <div className="form-group">
                                    <label>Therapeutic Category</label>
                                    <input
                                        type="text"
                                        name="therapeuticCategory"
                                        placeholder="e.g. Pain Relief, Antibiotic, Antacid"
                                        value={medForm.therapeuticCategory}
                                        onChange={handleMedInputChange}
                                        required
                                    />
                                </div>

                                <div className="form-group">
                                    <label>Category</label>
                                    <input
                                        type="text"
                                        name="category"
                                        value={medForm.category}
                                        onChange={handleMedInputChange}
                                    />
                                </div>

                                <div className="form-group">
                                    <label>Price (₹) *</label>
                                    <input
                                        type="number"
                                        step="0.01"
                                        name="price"
                                        required
                                        value={medForm.price}
                                        onChange={handleMedInputChange}
                                    />
                                </div>

                                <div className="form-group">
                                    <label>Stock Quantity *</label>
                                    <input
                                        type="number"
                                        name="stock"
                                        required
                                        value={medForm.stock}
                                        onChange={handleMedInputChange}
                                    />
                                </div>
                            </div>

                            <div className="form-group checkbox-group">
                                <label>
                                    <input
                                        type="checkbox"
                                        name="prescriptionRequired"
                                        checked={medForm.prescriptionRequired}
                                        onChange={handleMedInputChange}
                                    />
                                    Requires Doctor Prescription 📄
                                </label>
                            </div>

                            <div className="modal-actions">
                                <button type="submit" className="save-med-btn">
                                    {editingMedId ? "Update Medicine" : "Save Medicine"}
                                </button>
                                <button
                                    type="button"
                                    className="cancel-modal-btn"
                                    onClick={() => setShowAddModal(false)}
                                >
                                    Cancel
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            )}
        </div>
    );
}

export default AdminDashboard;
