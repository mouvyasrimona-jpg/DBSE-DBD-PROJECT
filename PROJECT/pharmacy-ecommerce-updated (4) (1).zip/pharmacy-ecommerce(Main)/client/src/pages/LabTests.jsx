import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import "./LabTests.css";

const API_BASE = "http://localhost:5000/api/lab-tests";

const CATEGORY_ICONS = {
    "Full Body Checkup": "🩺",
    "Diabetes": "🩸",
    "Thyroid": "🦋",
    "Heart Health": "❤️",
    "Vitamin Tests": "🍊",
    "Fever & Infection": "🌡️",
    "Women's Health": "👩",
    "Men's Health": "👨",
    "Kidney": "🫘",
    "Liver": "🫀"
};

function LabTests() {
    const navigate = useNavigate();
    const [tests, setTests] = useState([]);
    const [categories, setCategories] = useState([]);
    const [search, setSearch] = useState("");
    const [activeCategory, setActiveCategory] = useState("All");
    const [loading, setLoading] = useState(true);

    const fetchTests = async () => {
        try {
            setLoading(true);
            const params = new URLSearchParams();
            if (search.trim()) params.set("search", search.trim());
            if (activeCategory !== "All") params.set("category", activeCategory);

            const res = await fetch(`${API_BASE}?${params.toString()}`);
            const data = await res.json();
            if (data.success) setTests(data.tests);
        } catch (err) {
            console.error(err);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetch(`${API_BASE}/categories`).then((r) => r.json()).then((d) => {
            if (d.success) setCategories(d.categories);
        });
    }, []);

    useEffect(() => {
        const debounce = setTimeout(fetchTests, 300);
        return () => clearTimeout(debounce);
    }, [search, activeCategory]);

    return (
        <div className="labtests-page">

            <div className="labtests-header">
                <h1>Book Lab Tests with PharmaCare</h1>
                <p>Search for tests, packages or health checkups</p>

                <div className="labtests-search-box">
                    <span>🔍</span>
                    <input
                        placeholder="Search for tests, packages or health checkups"
                        value={search}
                        onChange={(e) => setSearch(e.target.value)}
                    />
                </div>
            </div>

            {categories.length > 0 && (
                <div className="labtests-category-row">
                    <button
                        className={activeCategory === "All" ? "active" : ""}
                        onClick={() => setActiveCategory("All")}
                    >
                        All Tests
                    </button>
                    {categories.map((cat) => (
                        <button
                            key={cat}
                            className={activeCategory === cat ? "active" : ""}
                            onClick={() => setActiveCategory(cat)}
                        >
                            <span>{CATEGORY_ICONS[cat] || "🧪"}</span> {cat}
                        </button>
                    ))}
                </div>
            )}

            <div className="labtests-count">
                {loading ? "Loading..." : `${tests.length} test${tests.length !== 1 ? "s" : ""} found`}
            </div>

            {!loading && tests.length === 0 && (
                <div className="labtests-empty">
                    <div>🧪</div>
                    <h3>No lab tests found</h3>
                    <p>Try a different search or category.</p>
                </div>
            )}

            <div className="labtests-grid">
                {tests.map((test) => {
                    const finalPrice = Math.round(test.price * (1 - (test.discountPercent || 0) / 100));
                    return (
                        <div className="labtest-card" key={test._id} onClick={() => navigate(`/lab-tests/${test._id}`)}>
                            <div className="labtest-card-top">
                                <span className="labtest-card-category">{test.category}</span>
                                {test.homeCollection && <span className="home-collection-tag">🏠 Home Collection</span>}
                            </div>
                            <h3>{test.name}</h3>
                            {test.description && <p className="labtest-desc">{test.description}</p>}

                            <div className="labtest-price-row">
                                <span className="labtest-final-price">₹{finalPrice}</span>
                                {test.discountPercent > 0 && (
                                    <>
                                        <span className="labtest-mrp">MRP ₹{test.mrp}</span>
                                        <span className="labtest-discount">{test.discountPercent}% OFF</span>
                                    </>
                                )}
                            </div>

                            <span className="labtest-sample-type">Sample: {test.sampleType}</span>

                            <button className="labtest-book-btn" onClick={() => navigate(`/lab-tests/${test._id}`)}>
                                Book Test →
                            </button>
                        </div>
                    );
                })}
            </div>

        </div>
    );
}

export default LabTests;
