import React, { useEffect, useState } from "react";
import { useParams, useNavigate, Link } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import "./LabTestBooking.css";

const API_BASE = "http://localhost:5000/api";

function getNext7Days() {
    const days = [];
    for (let i = 1; i <= 7; i++) {
        const d = new Date();
        d.setDate(d.getDate() + i);
        days.push(d);
    }
    return days;
}

function LabTestBooking() {
    const { id } = useParams();
    const navigate = useNavigate();
    const { token, isAuthenticated } = useAuth();

    const [test, setTest] = useState(null);
    const [centers, setCenters] = useState([]);
    const [slots, setSlots] = useState([]);
    const [loading, setLoading] = useState(true);
    const [submitting, setSubmitting] = useState(false);
    const [error, setError] = useState("");

    const availableDates = getNext7Days();

    const [form, setForm] = useState({
        patientName: "", patientAge: "", patientGender: "Male", patientPhone: "",
        collectionType: "Home", centerId: "", homeAddress: "",
        bookingDate: availableDates[0].toISOString().split("T")[0],
        timeSlot: ""
    });

    useEffect(() => {
        if (!isAuthenticated) {
            navigate("/login", { state: { from: `/lab-tests/${id}/book` } });
            return;
        }

        Promise.all([
            fetch(`${API_BASE}/lab-tests/${id}`).then((r) => r.json()),
            fetch(`${API_BASE}/lab-centers`).then((r) => r.json())
        ]).then(([testData, centerData]) => {
            if (testData.success) setTest(testData.test);
            if (centerData.success) setCenters(centerData.centers);
        }).finally(() => setLoading(false));
    }, [id]);

    useEffect(() => {
        if (!form.bookingDate) return;
        fetch(`${API_BASE}/lab-bookings/available-slots?date=${form.bookingDate}`)
            .then((r) => r.json())
            .then((d) => { if (d.success) setSlots(d.slots); });
    }, [form.bookingDate]);

    const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

    const handleSubmit = async (e) => {
        e.preventDefault();
        setError("");

        if (form.collectionType === "Home" && !form.homeAddress.trim()) {
            setError("Please enter your home address for sample collection.");
            return;
        }
        if (form.collectionType === "Center" && !form.centerId) {
            setError("Please select a collection center.");
            return;
        }
        if (!form.timeSlot) {
            setError("Please select a time slot.");
            return;
        }

        try {
            setSubmitting(true);
            const res = await fetch(`${API_BASE}/lab-bookings`, {
                method: "POST",
                headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
                body: JSON.stringify({
                    testId: id,
                    patient: {
                        name: form.patientName,
                        age: Number(form.patientAge),
                        gender: form.patientGender,
                        phone: form.patientPhone
                    },
                    collectionType: form.collectionType,
                    centerId: form.collectionType === "Center" ? form.centerId : undefined,
                    homeAddress: form.homeAddress,
                    bookingDate: form.bookingDate,
                    timeSlot: form.timeSlot
                })
            });
            const data = await res.json();

            if (data.success) {
                navigate(`/lab-bookings/${data.booking._id}`, { state: { justBooked: true } });
            } else {
                setError(data.message || "Failed to create booking");
            }
        } catch (err) {
            setError("Server error while booking. Please try again.");
        } finally {
            setSubmitting(false);
        }
    };

    if (loading) return <div className="labtest-details-loading">Loading...</div>;
    if (!test) return <div className="labtest-details-loading">Test not found</div>;

    return (
        <div className="lab-booking-page">

            <Link to={`/lab-tests/${id}`} className="labtest-back-link">← Back to Test Details</Link>

            <h1>Book: {test.name}</h1>

            {error && <div className="lab-booking-error">⚠️ {error}</div>}

            <form className="lab-booking-form" onSubmit={handleSubmit}>

                <div className="lab-booking-section">
                    <h3>Patient Details</h3>
                    <div className="lab-booking-row">
                        <input name="patientName" placeholder="Patient name" value={form.patientName} onChange={handleChange} required />
                        <input name="patientAge" type="number" placeholder="Age" value={form.patientAge} onChange={handleChange} required min="0" max="120" />
                    </div>
                    <div className="lab-booking-row">
                        <select name="patientGender" value={form.patientGender} onChange={handleChange}>
                            <option value="Male">Male</option>
                            <option value="Female">Female</option>
                            <option value="Other">Other</option>
                        </select>
                        <input name="patientPhone" placeholder="Phone (optional)" value={form.patientPhone} onChange={handleChange} />
                    </div>
                </div>

                <div className="lab-booking-section">
                    <h3>Sample Collection</h3>
                    <div className="collection-toggle">
                        <button type="button" className={form.collectionType === "Home" ? "active" : ""} onClick={() => setForm({ ...form, collectionType: "Home" })}>🏠 Home Collection</button>
                        <button type="button" className={form.collectionType === "Center" ? "active" : ""} onClick={() => setForm({ ...form, collectionType: "Center" })}>🏥 Visit Center</button>
                    </div>

                    {form.collectionType === "Home" ? (
                        <textarea name="homeAddress" placeholder="Enter full address for sample collection" value={form.homeAddress} onChange={handleChange} required />
                    ) : (
                        <select name="centerId" value={form.centerId} onChange={handleChange} required>
                            <option value="">Select a center</option>
                            {centers.map((c) => (
                                <option key={c._id} value={c._id}>{c.name} — {c.address}</option>
                            ))}
                        </select>
                    )}
                </div>

                <div className="lab-booking-section">
                    <h3>Date &amp; Time Slot</h3>
                    <div className="date-picker-row">
                        {availableDates.map((d) => {
                            const dateStr = d.toISOString().split("T")[0];
                            return (
                                <button
                                    type="button"
                                    key={dateStr}
                                    className={form.bookingDate === dateStr ? "active" : ""}
                                    onClick={() => setForm({ ...form, bookingDate: dateStr, timeSlot: "" })}
                                >
                                    <small>{d.toLocaleDateString("en-IN", { weekday: "short" })}</small>
                                    <strong>{d.getDate()}</strong>
                                </button>
                            );
                        })}
                    </div>

                    <div className="slot-picker-row">
                        {slots.map((s) => (
                            <button
                                type="button"
                                key={s.slot}
                                disabled={!s.available}
                                className={form.timeSlot === s.slot ? "active" : ""}
                                onClick={() => setForm({ ...form, timeSlot: s.slot })}
                            >
                                {s.slot} {!s.available && "(Full)"}
                            </button>
                        ))}
                    </div>
                </div>

                <button type="submit" className="lab-booking-confirm-btn" disabled={submitting}>
                    {submitting ? "Booking..." : `Confirm Booking — ₹${Math.round(test.price * (1 - (test.discountPercent || 0) / 100))}`}
                </button>

            </form>

        </div>
    );
}

export default LabTestBooking;
