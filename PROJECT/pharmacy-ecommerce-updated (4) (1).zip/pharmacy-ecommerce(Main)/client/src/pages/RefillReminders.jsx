﻿import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import "./RefillReminders.css";

const API_BASE = "http://localhost:5000/api";

function RefillReminders() {
    const { token } = useAuth();
    const [reminders, setReminders] = useState([]);
    const [predictions, setPredictions] = useState([]);
    const [loading, setLoading] = useState(true);
    const [showModal, setShowModal] = useState(false);
    const [message, setMessage] = useState({ type: "", text: "" });
    const [acceptingId, setAcceptingId] = useState(null);

    const [form, setForm] = useState({
        medicineName: "",
        refillDate: "",
        quantity: 1,
        note: ""
    });

    const fetchReminders = async () => {
        try {
            setLoading(true);
            const res = await fetch(`${API_BASE}/reminders`, {
                headers: { Authorization: `Bearer ${token}` }
            });
            const data = await res.json();
            if (data.success) {
                setReminders(data.reminders || []);
            }
        } catch (err) {
            console.error("Fetch reminders error:", err);
            setMessage({ type: "error", text: "Failed to load refill reminders." });
        } finally {
            setLoading(false);
        }
    };

    // Predictive Refill — suggested reminders based on real order
    // history (only shown for medicines ordered 2+ times that don't
    // already have a reminder set).
    const fetchPredictions = async () => {
        try {
            const res = await fetch(`${API_BASE}/reminders/predictions`, {
                headers: { Authorization: `Bearer ${token}` }
            });
            const data = await res.json();
            if (data.success) {
                setPredictions(data.predictions || []);
            }
        } catch (err) {
            console.error("Fetch predictions error:", err);
        }
    };

    useEffect(() => {
        if (token) {
            fetchReminders();
            fetchPredictions();
        }
    }, [token]);

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setForm(prev => ({ ...prev, [name]: value }));
    };

    const handleCreateReminder = async (e) => {
        e.preventDefault();
        setMessage({ type: "", text: "" });

        if (!form.medicineName.trim() || !form.refillDate) {
            setMessage({ type: "error", text: "Medicine name and refill date are required." });
            return;
        }

        try {
            const res = await fetch(`${API_BASE}/reminders`, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    Authorization: `Bearer ${token}`
                },
                body: JSON.stringify(form)
            });
            const data = await res.json();

            if (data.success) {
                setMessage({ type: "success", text: "Refill reminder scheduled successfully!" });
                setShowModal(false);
                setForm({ medicineName: "", refillDate: "", quantity: 1, note: "" });
                fetchReminders();
            } else {
                setMessage({ type: "error", text: data.message || "Failed to create reminder." });
            }
        } catch (err) {
            setMessage({ type: "error", text: "Server error creating reminder." });
        }
    };

    const handleDeleteReminder = async (id) => {
        if (!window.confirm("Remove this refill reminder?")) return;

        try {
            const res = await fetch(`${API_BASE}/reminders/${id}`, {
                method: "DELETE",
                headers: { Authorization: `Bearer ${token}` }
            });
            const data = await res.json();

            if (data.success) {
                setMessage({ type: "success", text: "Reminder removed." });
                fetchReminders();
            } else {
                setMessage({ type: "error", text: data.message || "Failed to remove reminder." });
            }
        } catch (err) {
            setMessage({ type: "error", text: "Server error deleting reminder." });
        }
    };

    const handleAcceptPrediction = async (prediction) => {
        try {
            setAcceptingId(prediction.medicineId);

            const res = await fetch(`${API_BASE}/reminders`, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    Authorization: `Bearer ${token}`
                },
                body: JSON.stringify({
                    medicineId: prediction.medicineId,
                    medicineName: prediction.medicineName,
                    refillDate: prediction.predictedRefillDate,
                    quantity: 1,
                    note: `Auto-suggested based on your last ${prediction.orderCount} orders (avg. every ${prediction.averageGapDays} days).`
                })
            });
            const data = await res.json();

            if (data.success) {
                setMessage({ type: "success", text: `Reminder set for ${prediction.medicineName}.` });
                setPredictions((prev) => prev.filter((p) => p.medicineId !== prediction.medicineId));
                fetchReminders();
            } else {
                setMessage({ type: "error", text: data.message || "Failed to accept suggestion." });
            }
        } catch (err) {
            setMessage({ type: "error", text: "Server error accepting suggestion." });
        } finally {
            setAcceptingId(null);
        }
    };

    const now = new Date();

    return (
        <div className="reminders-page">
            <div className="reminders-header">
                <div>
                    <div className="reminders-badge">🔔 Smart Medication Care</div>
                    <h1>Prescription <span>Refill Reminders</span></h1>
                    <p>Stay on track with your doses. We help you remember refills before your supply runs out.</p>
                </div>
                <button className="add-reminder-btn" onClick={() => setShowModal(true)}>
                    + Set Refill Reminder
                </button>
            </div>

            {message.text && (
                <div className={`reminder-alert ${message.type}`}>
                    {message.type === "success" ? "✅" : "⚠️"} {message.text}
                </div>
            )}

            {/* PREDICTIVE REFILL SUGGESTIONS */}
            {predictions.length > 0 && (
                <div className="predicted-refills-section">
                    <div className="predicted-refills-header">
                        <span>🧠 Smart Suggestions</span>
                        <p>Based on your order history, you may be due for a refill soon.</p>
                    </div>

                    <div className="predicted-refills-grid">
                        {predictions.map((p) => (
                            <div className="predicted-refill-card" key={p.medicineId}>
                                <div className="pr-icon">💊</div>
                                <div className="pr-info">
                                    <strong>{p.medicineName}</strong>
                                    <p>
                                        Ordered {p.orderCount} times, roughly every {p.averageGapDays} days.
                                        Predicted refill:{" "}
                                        {new Date(p.predictedRefillDate).toLocaleDateString("en-IN", {
                                            day: "numeric", month: "short", year: "numeric"
                                        })}
                                    </p>
                                </div>
                                <button
                                    className="accept-prediction-btn"
                                    onClick={() => handleAcceptPrediction(p)}
                                    disabled={acceptingId === p.medicineId}
                                >
                                    {acceptingId === p.medicineId ? "Adding..." : "+ Set Reminder"}
                                </button>
                            </div>
                        ))}
                    </div>
                </div>
            )}

            {loading ? (
                <div className="reminders-loading">Loading reminders...</div>
            ) : reminders.length === 0 ? (
                <div className="empty-reminders-card">
                    <div className="empty-icon">📅</div>
                    <h3>No Active Refill Reminders</h3>
                    <p>You haven't set any refill reminders yet. Set one to receive reminders before your medication runs out.</p>
                    <button className="btn-primary" onClick={() => setShowModal(true)}>+ Set My First Reminder</button>
                </div>
            ) : (
                <div className="reminders-grid">
                    {reminders.map((r) => {
                        const rDate = new Date(r.refillDate);
                        const diffDays = Math.ceil((rDate - now) / (1000 * 60 * 60 * 24));
                        const isOverdue = diffDays < 0;
                        const isDueSoon = diffDays >= 0 && diffDays <= 7;

                        return (
                            <div key={r._id} className={`reminder-card ${isOverdue ? "overdue" : isDueSoon ? "due-soon" : ""}`}>
                                <div className="reminder-card-top">
                                    <div className="reminder-med-info">
                                        <span className="reminder-med-icon">💊</span>
                                        <div>
                                            <h3>{r.medicineName}</h3>
                                            <span className="reminder-qty">Quantity: {r.quantity} pack(s)</span>
                                        </div>
                                    </div>
                                    <span className={`reminder-status-tag ${isOverdue ? "tag-red" : isDueSoon ? "tag-amber" : "tag-blue"}`}>
                                        {isOverdue ? "⚠️ Overdue" : isDueSoon ? `🔔 Due in ${diffDays} day${diffDays === 1 ? "" : "s"}` : "Scheduled"}
                                    </span>
                                </div>

                                <div className="reminder-date-box">
                                    <span className="date-label">Refill Due Date:</span>
                                    <span className="date-val">
                                        {rDate.toLocaleDateString("en-IN", {
                                            weekday: "short",
                                            day: "numeric",
                                            month: "short",
                                            year: "numeric"
                                        })}
                                    </span>
                                </div>

                                {r.note && <div className="reminder-note">📝 "{r.note}"</div>}

                                <div className="reminder-card-actions">
                                    <Link to={`/medicines?q=${encodeURIComponent(r.medicineName)}`} className="refill-order-btn">
                                        🛒 Order Medicine
                                    </Link>
                                    <button className="reminder-delete-btn" onClick={() => handleDeleteReminder(r._id)}>
                                        Dismiss ✕
                                    </button>
                                </div>
                            </div>
                        );
                    })}
                </div>
            )}

            {/* ADD REMINDER MODAL */}
            {showModal && (
                <div className="modal-overlay" onClick={() => setShowModal(false)}>
                    <div className="modal-card" onClick={e => e.stopPropagation()}>
                        <div className="modal-header">
                            <h3>Set Medication Refill Reminder</h3>
                            <button className="modal-close-btn" onClick={() => setShowModal(false)}>✕</button>
                        </div>
                        <form onSubmit={handleCreateReminder} className="reminder-form">
                            <div className="form-group">
                                <label>Medicine Name *</label>
                                <input
                                    type="text"
                                    name="medicineName"
                                    value={form.medicineName}
                                    onChange={handleInputChange}
                                    placeholder="e.g., Amoxicillin 500mg, Metformin"
                                    required
                                />
                            </div>

                            <div className="form-row">
                                <div className="form-group">
                                    <label>Refill Due Date *</label>
                                    <input
                                        type="date"
                                        name="refillDate"
                                        value={form.refillDate}
                                        onChange={handleInputChange}
                                        required
                                    />
                                </div>
                                <div className="form-group">
                                    <label>Quantity / Packs</label>
                                    <input
                                        type="number"
                                        name="quantity"
                                        min="1"
                                        value={form.quantity}
                                        onChange={handleInputChange}
                                    />
                                </div>
                            </div>

                            <div className="form-group">
                                <label>Personal Note / Doctor's Instruction (Optional)</label>
                                <textarea
                                    name="note"
                                    rows="2"
                                    value={form.note}
                                    onChange={handleInputChange}
                                    placeholder="e.g., Take 1 capsule twice daily after meals"
                                />
                            </div>

                            <div className="modal-actions">
                                <button type="button" className="btn-secondary" onClick={() => setShowModal(false)}>
                                    Cancel
                                </button>
                                <button type="submit" className="btn-primary">
                                    Save Reminder
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            )}
        </div>
    );
}

export default RefillReminders;
