import React from "react";
import { Link } from "react-router-dom";
import "./StaticPage.css";

function About() {
    return (
        <div className="static-page">
            <h1>About PharmaCare</h1>
            <p className="static-subtitle">Your trusted digital pharmacy platform.</p>

            <p>
                PharmaCare is an online pharmacy platform built around one core idea: buying
                medicines online should be convenient, but never at the cost of safety. Every
                prescription-required medicine on PharmaCare goes through OCR-assisted
                extraction and is manually reviewed by a licensed pharmacist before it can be
                ordered — we never let software alone approve a prescription.
            </p>

            <h2>What we offer</h2>
            <ul>
                <li>A searchable catalogue of medicines with substitute recommendations</li>
                <li>Prescription upload, OCR extraction, and pharmacist verification</li>
                <li>Real-time order tracking from pharmacy to your door</li>
                <li>Refill reminders based on your own order history</li>
                <li>Multi-pharmacy price comparison for the same medicine</li>
            </ul>

            <h2>Our commitment</h2>
            <p>
                We only display information that actually exists in our system — real stock
                levels, real prescription review outcomes, and real order status. We don't
                fabricate reviews, statistics, or medical claims.
            </p>

            <p>
                Have a question? Visit our <Link to="/faq" style={{ color: "#0d9488", fontWeight: 700 }}>FAQ page</Link> or
                reach out via the contact details there.
            </p>
        </div>
    );
}

export default About;
