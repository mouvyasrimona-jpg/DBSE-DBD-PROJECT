import React, { useEffect, useState } from "react";
import { useParams, useNavigate, Link } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import { getOrderById } from "../services/orderService";
import "./OrderDetails.css";

const statusSteps = ["Pending", "Confirmed", "Preparing", "Packed", "PickedUp", "OutForDelivery", "Delivered"];

function OrderDetails() {
    const { id } = useParams();
    const navigate = useNavigate();
    const { token, isAuthenticated } = useAuth();

    const [order, setOrder] = useState(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState("");
    const [eligibleItems, setEligibleItems] = useState([]);
    const [reviewDrafts, setReviewDrafts] = useState({});
    const [reviewMsg, setReviewMsg] = useState("");
    const [submittingReview, setSubmittingReview] = useState(null);

    useEffect(() => {
        if (!isAuthenticated) {
            navigate("/login", { state: { from: `/orders/${id}` } });
            return;
        }

        const fetchOrder = async () => {
            try {
                setLoading(true);
                setError("");
                const data = await getOrderById(id, token);

                if (data && data.success) {
                    setOrder(data.order);

                    if (data.order.status === "Delivered") {
                        try {
                            const elRes = await fetch(
                                `http://localhost:5000/api/reviews/eligible/${data.order._id}`,
                                { headers: { Authorization: `Bearer ${token}` } }
                            );
                            const elData = await elRes.json();
                            if (elData.success) setEligibleItems(elData.eligibleItems);
                        } catch (e) {
                            console.error("Eligible review fetch error:", e);
                        }
                    }
                } else {
                    setError("Order not found or access denied.");
                }
            } catch (err) {
                console.error("Fetch order details error:", err);
                setError(err.message || "Order not found or access denied.");
            } finally {
                setLoading(false);
            }
        };

        fetchOrder();
    }, [id, isAuthenticated, token, navigate]);

    const getStepIndex = (currentStatus) => {
        const index = statusSteps.indexOf(currentStatus);
        return index >= 0 ? index : 0;
    };

    const submitReview = async (medicineId) => {
        const draft = reviewDrafts[medicineId] || { rating: 5, comment: "" };
        try {
            setSubmittingReview(medicineId);
            const res = await fetch("http://localhost:5000/api/reviews", {
                method: "POST",
                headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
                body: JSON.stringify({
                    orderId: order._id,
                    medicineId,
                    rating: draft.rating,
                    comment: draft.comment
                })
            });
            const data = await res.json();
            if (data.success) {
                setEligibleItems((prev) => prev.filter((it) => it.medicineId !== medicineId));
                setReviewMsg("✅ Thanks for your review!");
            } else {
                setReviewMsg(`⚠️ ${data.message}`);
            }
        } catch (err) {
            setReviewMsg("⚠️ Failed to submit review.");
        } finally {
            setSubmittingReview(null);
            setTimeout(() => setReviewMsg(""), 3000);
        }
    };

    if (loading) {
        return (
            <div className="order-details-page">
                <div className="details-message">
                    <div className="loader"></div>
                    <p>Loading order details...</p>
                </div>
            </div>
        );
    }

    if (error || !order) {
        return (
            <div className="order-details-page">
                <div className="details-error-card">
                    <div className="error-icon">🔒</div>
                    <h2>Order Not Found</h2>
                    <p>{error || "You do not have permission to view this order."}</p>
                    <Link to="/orders" className="back-orders-btn">
                        ← Back to My Orders
                    </Link>
                </div>
            </div>
        );
    }

    const currentStepIdx = getStepIndex(order.status);
    const isCancelled = order.status === "Cancelled";

    return (
        <div className="order-details-page">
            <div className="details-header">
                <Link to="/orders" className="back-link">
                    ← Back to Order History
                </Link>
                <div className="header-title-row">
                    <div>
                        <h1>Order <span>#{order._id}</span></h1>
                        <p className="order-timestamp">
                            Placed on {new Date(order.createdAt).toLocaleString("en-IN", {
                                day: "numeric",
                                month: "long",
                                year: "numeric",
                                hour: "2-digit",
                                minute: "2-digit"
                            })}
                        </p>
                    </div>
                    <span className={`status-pill ${order.status?.toLowerCase()}`}>
                        {order.status}
                    </span>
                </div>
                {!["Delivered", "Cancelled", "Failed", "Returned"].includes(order.status) && (
                    <Link to={`/orders/${order._id}/tracking`} className="track-live-btn">
                        📍 Track Live on Map
                    </Link>
                )}
                <Link to={`/orders/${order._id}/invoice`} className="track-live-btn">
                    🧾 View Invoice
                </Link>
            </div>

            {/* STATUS TIMELINE */}
            <div className="timeline-container">
                <h3>Order Status Tracking</h3>
                {isCancelled ? (
                    <div className="cancelled-banner">
                        ❌ This order was cancelled.
                    </div>
                ) : (
                    <div className="timeline">
                        {statusSteps.map((step, idx) => {
                            const isCompleted = idx <= currentStepIdx;
                            const isCurrent = idx === currentStepIdx;
                            return (
                                <div
                                    key={step}
                                    className={`timeline-step ${isCompleted ? "completed" : ""} ${isCurrent ? "current" : ""}`}
                                >
                                    <div className="step-circle">
                                        {isCompleted ? "✓" : idx + 1}
                                    </div>
                                    <span className="step-label">{step}</span>
                                </div>
                            );
                        })}
                    </div>
                )}
            </div>

            {/* PRESCRIPTION-TO-ORDER AUDIT TRAIL */}
            {/* Built only from real, stored timestamps on this order —
                nothing here is invented or estimated. */}
            <div className="audit-trail-container card">
                <h3>Order Audit Trail</h3>
                <div className="audit-trail-list">

                    <div className="audit-event">
                        <span className="audit-dot">✅</span>
                        <div>
                            <strong>Order Placed</strong>
                            <p>
                                {new Date(order.createdAt).toLocaleString("en-IN", {
                                    day: "numeric", month: "short", year: "numeric",
                                    hour: "2-digit", minute: "2-digit"
                                })}
                            </p>
                        </div>
                    </div>

                    {order.items?.some((it) => it.selectedPharmacy) && (
                        <div className="audit-event">
                            <span className="audit-dot">🏥</span>
                            <div>
                                <strong>
                                    Pharmacy Assigned —{" "}
                                    {order.selectedPharmacy?.shopName ||
                                        order.items.find((it) => it.selectedPharmacy)?.selectedPharmacy?.shopName}
                                </strong>
                                <p>Confirmed at order placement</p>
                            </div>
                        </div>
                    )}

                    <div className="audit-event">
                        <span className="audit-dot">
                            {order.paymentStatus === "Paid" ? "💳" : "⏳"}
                        </span>
                        <div>
                            <strong>
                                Payment {order.paymentStatus} — {order.paymentMethod}
                            </strong>
                            <p>
                                {order.paymentStatus === "Paid"
                                    ? "Payment confirmed at order placement"
                                    : "Awaiting collection on delivery (COD)"}
                            </p>
                        </div>
                    </div>

                    {order.shippedAt && (
                        <div className="audit-event">
                            <span className="audit-dot">🚚</span>
                            <div>
                                <strong>Shipped</strong>
                                <p>
                                    {new Date(order.shippedAt).toLocaleString("en-IN", {
                                        day: "numeric", month: "short", year: "numeric",
                                        hour: "2-digit", minute: "2-digit"
                                    })}
                                </p>
                            </div>
                        </div>
                    )}

                    {order.deliveredAt && (
                        <div className="audit-event">
                            <span className="audit-dot">🎉</span>
                            <div>
                                <strong>Delivered</strong>
                                <p>
                                    {new Date(order.deliveredAt).toLocaleString("en-IN", {
                                        day: "numeric", month: "short", year: "numeric",
                                        hour: "2-digit", minute: "2-digit"
                                    })}
                                </p>
                            </div>
                        </div>
                    )}

                    {isCancelled && (
                        <div className="audit-event">
                            <span className="audit-dot">❌</span>
                            <div>
                                <strong>Order Cancelled</strong>
                                <p>Current status: Cancelled</p>
                            </div>
                        </div>
                    )}

                </div>
            </div>

            <div className="details-grid">
                {/* ITEMS TABLE */}
                <div className="items-section card">
                    <h3>Ordered Items ({order.items?.length})</h3>
                    <div className="items-table">
                        {order.items?.map((item, idx) => (
                            <div className="table-row" key={idx}>
                                <div className="item-info">
                                    <div className="item-icon-box">
                                        {item.image ? (
                                            <img src={item.image} alt={item.name} />
                                        ) : (
                                            <span>💊</span>
                                        )}
                                    </div>
                                    <div>
                                        <h4>{item.name}</h4>
                                        <span className="unit-price">₹{item.price} each</span>
                                    </div>
                                </div>
                                <div className="item-qty-col">
                                    Qty: <strong>{item.quantity}</strong>
                                </div>
                                <div className="item-subtotal-col">
                                    <strong>₹{Number(item.subtotal).toFixed(2)}</strong>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>

                {/* SIDEBAR: ADDRESS & PAYMENT */}
                <div className="summary-sidebar">
                    <div className="card shipping-card">
                        <h3>Shipping Address 📍</h3>
                        <p className="recipient-name"><strong>{order.shippingAddress?.name}</strong></p>
                        <p>{order.shippingAddress?.addressLine}</p>
                        <p>{order.shippingAddress?.city}, {order.shippingAddress?.state} - {order.shippingAddress?.pincode}</p>
                        <p className="phone-num">📞 {order.shippingAddress?.phone}</p>
                    </div>

                    <div className="card payment-card">
                        <h3>Payment & Total Summary 💳</h3>
                        <div className="pay-row">
                            <span>Payment Method:</span>
                            <strong>{order.paymentMethod}</strong>
                        </div>
                        <div className="pay-row">
                            <span>Payment Status:</span>
                            <span className={`payment-pill ${order.paymentStatus?.toLowerCase()}`}>
                                {order.paymentStatus}
                            </span>
                        </div>
                        <div className="pay-divider"></div>
                        <div className="pay-row total">
                            <span>Total Amount:</span>
                            <strong className="grand-total">₹{Number(order.totalAmount).toFixed(2)}</strong>
                        </div>
                    </div>
                </div>
            </div>

            {/* REVIEWS — only for delivered orders, only for
                medicines actually in this order, one review each */}
            {order.status === "Delivered" && eligibleItems.length > 0 && (
                <div className="card review-section">
                    <h3>Rate Your Medicines</h3>
                    {reviewMsg && <p className="review-msg">{reviewMsg}</p>}
                    {eligibleItems.map((item) => {
                        const draft = reviewDrafts[item.medicineId] || { rating: 5, comment: "" };
                        return (
                            <div className="review-item-row" key={item.medicineId}>
                                <strong>{item.name}</strong>
                                <div className="star-picker">
                                    {[1, 2, 3, 4, 5].map((n) => (
                                        <span
                                            key={n}
                                            className={n <= draft.rating ? "star filled" : "star"}
                                            onClick={() =>
                                                setReviewDrafts((prev) => ({
                                                    ...prev,
                                                    [item.medicineId]: { ...draft, rating: n }
                                                }))
                                            }
                                        >
                                            ★
                                        </span>
                                    ))}
                                </div>
                                <textarea
                                    placeholder="Optional comment..."
                                    value={draft.comment}
                                    onChange={(e) =>
                                        setReviewDrafts((prev) => ({
                                            ...prev,
                                            [item.medicineId]: { ...draft, comment: e.target.value }
                                        }))
                                    }
                                />
                                <button
                                    className="submit-review-btn"
                                    disabled={submittingReview === item.medicineId}
                                    onClick={() => submitReview(item.medicineId)}
                                >
                                    {submittingReview === item.medicineId ? "Submitting..." : "Submit Review"}
                                </button>
                            </div>
                        );
                    })}
                </div>
            )}
        </div>
    );
}

export default OrderDetails;
