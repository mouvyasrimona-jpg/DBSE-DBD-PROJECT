import React, { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import "./CustomerDashboard.css";

const API = "http://localhost:5000/api";

function CustomerDashboard() {
    const { user, token } = useAuth();
    const navigate = useNavigate();

    const [orders, setOrders] = useState([]);
    const [prescriptions, setPrescriptions] = useState([]);
    const [reminders, setReminders] = useState([]);
    const [labBookings, setLabBookings] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        if (!token) return;
        const headers = { Authorization: `Bearer ${token}` };

        Promise.all([
            fetch(`${API}/orders/my-orders`, { headers }).then(r => r.json()),
            fetch(`${API}/prescriptions/my-prescriptions`, { headers }).then(r => r.json()),
            fetch(`${API}/reminders`, { headers }).then(r => r.json()),
            fetch(`${API}/lab-bookings/my`, { headers }).then(r => r.json())
        ]).then(([ordersData, rxData, remData, labData]) => {
            setOrders(ordersData.orders || []);
            setPrescriptions(rxData.prescriptions || []);
            setReminders(remData.reminders || []);
            setLabBookings(labData.bookings || []);
        }).catch(console.error)
          .finally(() => setLoading(false));
    }, [token]);

    const activeOrders = orders.filter(o => !["Delivered", "Cancelled"].includes(o.status));
    const pendingRx = prescriptions.filter(p => p.status === "Pending");
    const approvedRx = prescriptions.filter(p => p.status === "Approved");

    // Reminders due within 7 days
    const now = new Date();
    const dueSoon = reminders.filter(r => {
        const d = new Date(r.refillDate);
        return d >= now && (d - now) / 86400000 <= 7;
    });

    const stats = [
        { icon: "🚚", label: "Active Orders", value: activeOrders.length, color: "#2563eb", link: "/orders" },
        { icon: "⏳", label: "Pending Prescriptions", value: pendingRx.length, color: "#d97706", link: "/prescription" },
        { icon: "✅", label: "Approved Prescriptions", value: approvedRx.length, color: "#16a34a", link: "/prescription" },
        { icon: "🔔", label: "Refill Reminders", value: reminders.length, color: "#0d9488", link: "/refill-reminders" },
        { icon: "🧪", label: "Lab Bookings", value: labBookings.length, color: "#9333ea", link: "/lab-bookings" }
    ];

    if (loading) {
        return (
            <div className="dashboard-page">
                <div className="dash-loading">⏳ Loading your dashboard...</div>
            </div>
        );
    }

    return (
        <div className="dashboard-page">
            {/* WELCOME */}
            <div className="dash-welcome">
                <div className="dash-welcome-left">
                    <div className="dash-badge">👋 Welcome back</div>
                    <h1 className="dash-name">{user?.name || "Customer"}</h1>
                    <p className="dash-email">{user?.email}</p>
                </div>
                <div className="dash-welcome-actions">
                    <Link to="/medicines" className="btn-primary" style={{ textDecoration: "none" }}>Browse Medicines →</Link>
                    <Link to="/prescription" className="btn-secondary" style={{ textDecoration: "none" }}>Upload Prescription</Link>
                </div>
            </div>

            {/* STATS GRID */}
            <div className="dash-stats-grid">
                {stats.map((s, i) => (
                    <Link to={s.link} className="dash-stat-card" key={i} style={{ textDecoration: "none", borderColor: `${s.color}30` }}>
                        <div className="dash-stat-icon" style={{ background: `${s.color}1a`, color: s.color }}>{s.icon}</div>
                        <div className="dash-stat-value" style={{ color: s.color }}>{s.value}</div>
                        <div className="dash-stat-label">{s.label}</div>
                    </Link>
                ))}
            </div>

            <div className="dash-main-grid">
                {/* RECENT ORDERS */}
                <div className="dash-section-card">
                    <div className="dash-section-header">
                        <h3>Recent Orders</h3>
                        <Link to="/orders" className="dash-see-all">See All →</Link>
                    </div>
                    {orders.length === 0 ? (
                        <div className="dash-empty">No orders yet. <Link to="/medicines">Browse medicines →</Link></div>
                    ) : (
                        orders.slice(0, 4).map(o => {
                            const statusCls = {
                                Pending: "status-amber", Processing: "status-blue",
                                Shipped: "status-purple", Delivered: "status-green", Cancelled: "status-red"
                            }[o.status] || "status-gray";
                            return (
                                <div className="dash-order-row" key={o._id}>
                                    <div>
                                        <div className="dash-order-id">#{String(o._id).slice(-8).toUpperCase()}</div>
                                        <div className="dash-order-date">{new Date(o.createdAt).toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" })}</div>
                                    </div>
                                    <div className={`dash-status-pill ${statusCls}`}>{o.status}</div>
                                    <div className="dash-order-amount">₹{Number(o.totalAmount).toFixed(2)}</div>
                                    <Link to={`/orders/${o._id}`} className="dash-view-btn">View</Link>
                                </div>
                            );
                        })
                    )}
                </div>

                {/* RIGHT COLUMN */}
                <div className="dash-right-col">
                    {/* Prescriptions */}
                    <div className="dash-section-card">
                        <div className="dash-section-header">
                            <h3>Prescriptions</h3>
                            <Link to="/prescription" className="dash-see-all">Manage →</Link>
                        </div>
                        {prescriptions.length === 0 ? (
                            <div className="dash-empty">No prescriptions uploaded.</div>
                        ) : (
                            prescriptions.slice(0, 3).map(p => {
                                const statusColor = { Approved: "#16a34a", Pending: "#d97706", Rejected: "#dc2626" }[p.status] || "#475569";
                                return (
                                    <div className="dash-rx-row" key={p._id}>
                                        <div className="dash-rx-name">{p.originalName || "Prescription"}</div>
                                        <span className="dash-rx-status" style={{ color: statusColor, border: `1px solid ${statusColor}40`, background: `${statusColor}15`, padding: "2px 10px", borderRadius: 20, fontSize: 12, fontWeight: 700 }}>
                                            {p.status}
                                        </span>
                                    </div>
                                );
                            })
                        )}
                    </div>

                    {/* Refill Reminders Due Soon */}
                    <div className="dash-section-card">
                        <div className="dash-section-header">
                            <h3>Upcoming Refills</h3>
                            <Link to="/refill-reminders" className="dash-see-all">All →</Link>
                        </div>
                        {dueSoon.length === 0 ? (
                            <div className="dash-empty">No refills due in the next 7 days.</div>
                        ) : (
                            dueSoon.map(r => (
                                <div className="dash-rx-row" key={r._id}>
                                    <div>
                                        <div className="dash-rx-name">🔔 {r.medicineName}</div>
                                        <div style={{ fontSize: 11, color: "#d97706", marginTop: 2 }}>
                                            Due: {new Date(r.refillDate).toLocaleDateString("en-IN", { day: "numeric", month: "short" })}
                                        </div>
                                    </div>
                                </div>
                            ))
                        )}
                    </div>

                    {/* Quick Actions */}
                    <div className="dash-section-card">
                        <div className="dash-section-header"><h3>Quick Actions</h3></div>
                        <div className="dash-quick-links">
                            {[
                                { to: "/medicines", icon: "💊", label: "Buy Medicines" },
                                { to: "/prescription", icon: "📄", label: "Upload Rx" },
                                { to: "/orders", icon: "📦", label: "My Orders" },
                                { to: "/lab-tests", icon: "🧪", label: "Book Lab Test" },
                                { to: "/refill-reminders", icon: "🔔", label: "Reminders" }
                            ].map(l => (
                                <Link key={l.to} to={l.to} className="dash-quick-link">
                                    <span>{l.icon}</span>
                                    <span>{l.label}</span>
                                </Link>
                            ))}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default CustomerDashboard;
