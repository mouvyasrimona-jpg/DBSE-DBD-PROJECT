import React, { useEffect, useState } from "react";
import "./PharmacistDashboard.css";

const API_BASE = "http://localhost:5000";
const API_URL = `${API_BASE}/api/prescriptions`;

// Prescription files are stored as relative paths (e.g. "/uploads/xyz.pdf")
// and need the backend origin prefixed to open correctly in a new tab.
const resolveFileUrl = (prescription) => {
    const raw =
        prescription.fileUrl ||
        prescription.filePath ||
        prescription.file;

    if (!raw) return null;
    if (raw.startsWith("http://") || raw.startsWith("https://")) return raw;
    return `${API_BASE}${raw.startsWith("/") ? "" : "/"}${raw}`;
};

function PharmacistDashboard() {
    const [prescriptions, setPrescriptions] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState("");

    const [selectedPrescription, setSelectedPrescription] = useState(null);
    const [notes, setNotes] = useState("");
    const [expandedAuditId, setExpandedAuditId] = useState(null);
    const [auditEvents, setAuditEvents] = useState({});

    const toggleAudit = async (prescriptionId) => {
        if (expandedAuditId === prescriptionId) {
            setExpandedAuditId(null);
            return;
        }
        setExpandedAuditId(prescriptionId);
        if (!auditEvents[prescriptionId]) {
            try {
                const token = localStorage.getItem("token") || localStorage.getItem("authToken");
                const res = await fetch(`${API_URL}/${prescriptionId}/audit`, {
                    headers: { Authorization: `Bearer ${token}` }
                });
                const data = await res.json();
                if (data.success) {
                    setAuditEvents((prev) => ({ ...prev, [prescriptionId]: data.events }));
                }
            } catch (err) {
                console.error("Audit fetch error:", err);
            }
        }
    };

    useEffect(() => {
        fetchPrescriptions();
    }, []);

    const getToken = () => {
        return (
            localStorage.getItem("token") ||
            localStorage.getItem("authToken")
        );
    };

    const fetchPrescriptions = async () => {
        try {
            setLoading(true);
            setError("");

            const token = getToken();

            const response = await fetch(API_URL, {
                headers: {
                    Authorization: `Bearer ${token}`
                }
            });

            const data = await response.json();

            if (!response.ok) {
                throw new Error(
                    data.message || "Failed to load prescriptions"
                );
            }

            setPrescriptions(
                data.prescriptions ||
                data.data ||
                []
            );

        } catch (err) {
            console.error(err);
            setError(err.message || "Unable to load prescriptions");
        } finally {
            setLoading(false);
        }
    };

    const updatePrescription = async (id, status) => {
        try {
            const token = getToken();

            const response = await fetch(
                `${API_URL}/${id}/status`,
                {
                    method: "PUT",
                    headers: {
                        "Content-Type": "application/json",
                        Authorization: `Bearer ${token}`
                    },
                    body: JSON.stringify({
                        status,
                        rejectionReason: notes
                    })
                }
            );

            const data = await response.json();

            if (!response.ok) {
                throw new Error(
                    data.message || "Failed to update prescription"
                );
            }

            setSelectedPrescription(null);
            setNotes("");

            await fetchPrescriptions();

        } catch (err) {
            console.error(err);
            alert(err.message || "Something went wrong");
        }
    };

    const pendingCount = prescriptions.filter(
        (p) =>
            (p.status || "").toLowerCase() === "pending"
    ).length;

    const approvedCount = prescriptions.filter(
        (p) =>
            (p.status || "").toLowerCase() === "approved"
    ).length;

    const rejectedCount = prescriptions.filter(
        (p) =>
            (p.status || "").toLowerCase() === "rejected"
    ).length;

    if (loading) {
        return (
            <div className="pharmacist-page">
                <div className="dashboard-loading">
                    Loading prescriptions...
                </div>
            </div>
        );
    }

    return (
        <div className="pharmacist-page">

            <div className="pharmacist-header">
                <div>
                    <h1>Pharmacist Dashboard</h1>
                    <p>
                        Review and manage customer prescriptions
                        before medicine orders are processed.
                    </p>
                </div>

                <button
                    className="refresh-button"
                    onClick={fetchPrescriptions}
                >
                    🔄 Refresh
                </button>
            </div>

            {error && (
                <div className="dashboard-error">
                    ⚠️ {error}
                </div>
            )}

            {/* STATISTICS */}

            <div className="prescription-stats">

                <div className="stat-card">
                    <span>🟠</span>
                    <div>
                        <strong>{pendingCount}</strong>
                        <p>Pending Review</p>
                    </div>
                </div>

                <div className="stat-card">
                    <span>🟢</span>
                    <div>
                        <strong>{approvedCount}</strong>
                        <p>Approved</p>
                    </div>
                </div>

                <div className="stat-card">
                    <span>🔴</span>
                    <div>
                        <strong>{rejectedCount}</strong>
                        <p>Rejected</p>
                    </div>
                </div>

                <div className="stat-card">
                    <span>📄</span>
                    <div>
                        <strong>{prescriptions.length}</strong>
                        <p>Total Prescriptions</p>
                    </div>
                </div>

            </div>

            {/* PRESCRIPTIONS */}

            <div className="prescriptions-section">

                <div className="section-title">
                    <h2>Prescription Reviews</h2>
                    <span>
                        {prescriptions.length} prescriptions
                    </span>
                </div>

                {prescriptions.length === 0 ? (

                    <div className="empty-prescriptions">
                        <div>📄</div>
                        <h3>No prescriptions found</h3>
                        <p>
                            Uploaded prescriptions will appear here.
                        </p>
                    </div>

                ) : (

                    <div className="prescription-list">

                        {prescriptions.map((prescription) => {

                            const status =
                                (
                                    prescription.status ||
                                    "pending"
                                ).toLowerCase();

                            return (

                                <div
                                    className="prescription-card"
                                    key={prescription._id}
                                >

                                    <div className="prescription-top">

                                        <div>
                                            <h3>
                                                📄{" "}
                                                {prescription.fileName ||
                                                    prescription.filename ||
                                                    "Prescription"}
                                            </h3>

                                            <p>
                                                Patient:{" "}
                                                <strong>
                                                    {prescription.userId?.name ||
                                                        prescription.user?.name ||
                                                        prescription.userName ||
                                                        prescription.patientName ||
                                                        "Customer"}
                                                </strong>
                                                {(prescription.userId?.email || prescription.user?.email) && (
                                                    <span style={{ marginLeft: 8, opacity: 0.7 }}>
                                                        ({prescription.userId?.email || prescription.user?.email})
                                                    </span>
                                                )}
                                            </p>

                                            <p>
                                                Uploaded:{" "}
                                                {prescription.createdAt
                                                    ? new Date(
                                                          prescription.createdAt
                                                      ).toLocaleString()
                                                    : "Unknown"}
                                            </p>
                                        </div>

                                        <span
                                            className={`status-badge ${status}`}
                                        >
                                            {status === "approved" &&
                                                "✓ Approved"}

                                            {status === "rejected" &&
                                                "✕ Rejected"}

                                            {status === "pending" &&
                                                "● Pending"}
                                        </span>

                                    </div>

                                    {/* FILE */}

                                    {resolveFileUrl(prescription) ? (

                                        <a
                                            href={resolveFileUrl(prescription)}
                                            target="_blank"
                                            rel="noreferrer"
                                            className="view-file"
                                        >
                                            👁 View Prescription
                                        </a>

                                    ) : null}

                                    {/* PRESCRIPTION INTELLIGENCE (Feature 1) */}

                                    {prescription.extractedInfo?.patientName && (
                                        <div className="intel-panel">
                                            <div className="intel-row">
                                                <span>👤 Patient: <strong>{prescription.extractedInfo.patientName}</strong></span>
                                                <span>🩺 Doctor: <strong>{prescription.extractedInfo.doctorName}</strong></span>
                                            </div>

                                            <div className="intel-flags">
                                                {prescription.isExpired && (
                                                    <span className="intel-flag flag-warn">⚠️ Prescription may be expired</span>
                                                )}
                                                {prescription.needsManualReview && (
                                                    <span className="intel-flag flag-warn">🔎 Needs careful manual review</span>
                                                )}
                                                <span className="intel-flag flag-info">
                                                    Confidence: {prescription.overallConfidence}%
                                                </span>
                                            </div>

                                            {prescription.medicineMatchResults?.length > 0 && (
                                                <div className="match-chips">
                                                    {prescription.medicineMatchResults.map((m, i) => (
                                                        <span key={i} className={`match-chip match-${m.matchType}`}>
                                                            {m.detectedName} — {m.matchType}
                                                        </span>
                                                    ))}
                                                </div>
                                            )}

                                            <button
                                                type="button"
                                                className="audit-toggle-btn"
                                                onClick={() => toggleAudit(prescription._id)}
                                            >
                                                {expandedAuditId === prescription._id ? "Hide Audit Trail ▲" : "View Audit Trail ▼"}
                                            </button>

                                            {expandedAuditId === prescription._id && (
                                                <div className="audit-events-list">
                                                    {(auditEvents[prescription._id] || []).map((ev) => (
                                                        <div className="audit-event-row" key={ev._id}>
                                                            <span className="audit-event-action">{ev.action.replace(/_/g, " ")}</span>
                                                            <span className="audit-event-time">
                                                                {new Date(ev.createdAt).toLocaleString("en-IN", { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" })}
                                                            </span>
                                                            {ev.performedBy?.name && <span className="audit-event-by">by {ev.performedBy.name}</span>}
                                                        </div>
                                                    ))}
                                                </div>
                                            )}
                                        </div>
                                    )}

                                    {/* OCR / DETECTED MEDICINES */}

                                    {(prescription.detectedMedicines?.length > 0 || prescription.ocrDetectedText) && (

                                        <div className="existing-notes">
                                            <strong>
                                                🔍 OCR Scan Results
                                            </strong>

                                            {prescription.detectedMedicines?.length > 0 && (
                                                <p>
                                                    Detected medicines: {prescription.detectedMedicines.join(", ")}
                                                </p>
                                            )}

                                            {prescription.ocrDetectedText && (
                                                <p style={{ fontStyle: "italic", opacity: 0.85 }}>
                                                    "{prescription.ocrDetectedText}"
                                                </p>
                                            )}
                                        </div>

                                    )}

                                    {/* NOTES */}

                                    {prescription.rejectionReason && (

                                        <div className="existing-notes">
                                            <strong>
                                                Pharmacist Notes
                                            </strong>

                                            <p>
                                                {
                                                    prescription.rejectionReason
                                                }
                                            </p>
                                        </div>

                                    )}

                                    {/* ACTIONS */}

                                    {status === "pending" && (

                                        <div className="review-actions">

                                            <button
                                                className="approve-button"
                                                onClick={() => {
                                                    setSelectedPrescription(
                                                        prescription
                                                    );
                                                    setNotes("");
                                                }}
                                            >
                                                ✓ Approve
                                            </button>

                                            <button
                                                className="reject-button"
                                                onClick={() => {
                                                    setSelectedPrescription(
                                                        prescription
                                                    );
                                                    setNotes("");
                                                }}
                                            >
                                                ✕ Reject
                                            </button>

                                        </div>

                                    )}

                                </div>

                            );
                        })}

                    </div>

                )}

            </div>

            {/* REVIEW MODAL */}

            {selectedPrescription && (

                <div className="review-overlay">

                    <div className="review-modal">

                        <button
                            className="close-modal"
                            onClick={() =>
                                setSelectedPrescription(null)
                            }
                        >
                            ×
                        </button>

                        <h2>
                            Review Prescription
                        </h2>

                        <p>
                            {selectedPrescription.fileName ||
                                selectedPrescription.filename ||
                                "Prescription"}
                        </p>

                        <div className="review-file">

                            {resolveFileUrl(selectedPrescription) ? (

                                <a
                                    href={resolveFileUrl(selectedPrescription)}
                                    target="_blank"
                                    rel="noreferrer"
                                >
                                    📄 Open Prescription
                                </a>

                            ) : (

                                <p>
                                    Prescription file unavailable
                                </p>

                            )}

                            {selectedPrescription.detectedMedicines?.length > 0 && (
                                <p style={{ marginTop: 8 }}>
                                    🔍 Detected: {selectedPrescription.detectedMedicines.join(", ")}
                                </p>
                            )}

                        </div>

                        <label>
                            Pharmacist Notes
                        </label>

                        <textarea
                            value={notes}
                            onChange={(e) =>
                                setNotes(e.target.value)
                            }
                            placeholder="Enter review notes..."
                            rows="5"
                        />

                        <div className="modal-actions">

                            <button
                                className="approve-button"
                                onClick={() =>
                                    updatePrescription(
                                        selectedPrescription._id,
                                        "Approved"
                                    )
                                }
                            >
                                ✓ Approve Prescription
                            </button>

                            <button
                                className="reject-button"
                                onClick={() =>
                                    updatePrescription(
                                        selectedPrescription._id,
                                        "Rejected"
                                    )
                                }
                            >
                                ✕ Reject Prescription
                            </button>

                        </div>

                    </div>

                </div>

            )}

        </div>
    );
}

export default PharmacistDashboard;