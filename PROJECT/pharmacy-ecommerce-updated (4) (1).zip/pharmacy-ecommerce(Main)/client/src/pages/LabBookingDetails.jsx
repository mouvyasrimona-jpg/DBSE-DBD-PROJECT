import React, { useEffect, useState } from "react";
import { useParams, useLocation, Link } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import "./LabBookingDetails.css";

const API_BASE = "http://localhost:5000/api/lab-bookings";

// Real lifecycle order — matches the LabBooking model's enum
// exactly. A step only shows as complete if the booking's actual
// current status has reached or passed it.
const STEPS = [
    { key: "Confirmed", label: "Booking Confirmed", icon: "✅" },
    { key: "Scheduled", label: "Slot Scheduled", icon: "📅" },
    { key: "SampleCollected", label: "Sample Collection", icon: "🧪" },
    { key: "SampleReceived", label: "Sample Received", icon: "📥" },
    { key: "Testing", label: "Testing", icon: "🔬" },
    { key: "ReportReady", label: "Report Ready", icon: "📄" }
];

function LabBookingDetails() {
    const { id } = useParams();
    const location = useLocation();
    const { token } = useAuth();
    const [booking, setBooking] = useState(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState("");

    useEffect(() => {
        fetch(`${API_BASE}/${id}`, { headers: { Authorization: `Bearer ${token}` } })
            .then((r) => r.json())
            .then((d) => {
                if (d.success) setBooking(d.booking);
                else setError(d.message || "Booking not found");
            })
            .catch(() => setError("Failed to load booking"))
            .finally(() => setLoading(false));
    }, [id, token]);

    if (loading) return <div className="lab-details-page"><div className="lab-loading">Loading booking...</div></div>;
    if (error || !booking) return <div className="lab-details-page"><div className="lab-error">{error || "Booking not found"}</div></div>;

    const isCancelled = booking.bookingStatus === "Cancelled";
    const currentStepIndex = STEPS.findIndex((s) => s.key === booking.bookingStatus);

    return (
        <div className="lab-details-page">

            {location.state?.justBooked && (
                <div className="lab-success-banner">✅ Your lab test has been booked successfully!</div>
            )}

            <div className="lab-details-header">
                <div>
                    <h1>{booking.testName}</h1>
                    <p>Booking ID: <strong>{booking.bookingId}</strong></p>
                </div>
                <Link to="/lab-bookings" className="lab-back-link">← All Bookings</Link>
            </div>

            {isCancelled ? (
                <div className="lab-cancelled-box">❌ This booking was cancelled.</div>
            ) : (
                <div className="lab-timeline card">
                    {STEPS.map((step, i) => {
                        const isDone = currentStepIndex >= 0 && i <= currentStepIndex;
                        return (
                            <div className={`lab-timeline-step ${isDone ? "done" : ""}`} key={step.key}>
                                <div className="lab-timeline-icon">{isDone ? step.icon : "○"}</div>
                                <span>{step.label}</span>
                                {i < STEPS.length - 1 && <div className="lab-timeline-line" />}
                            </div>
                        );
                    })}
                </div>
            )}

            <div className="lab-details-grid">
                <div className="card">
                    <h3>Patient Details</h3>
                    <p><strong>{booking.patient.name}</strong> — {booking.patient.age} yrs, {booking.patient.gender}</p>
                    {booking.patient.phone && <p>📞 {booking.patient.phone}</p>}
                </div>

                <div className="card">
                    <h3>Appointment</h3>
                    <p>📅 {new Date(booking.bookingDate).toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" })}</p>
                    <p>⏰ {booking.timeSlot}</p>
                    <p>{booking.collectionType === "Home" ? `🏠 Home: ${booking.homeAddress}` : `🏥 ${booking.centerId?.name || "Center"} — ${booking.centerId?.address || ""}`}</p>
                </div>

                <div className="card">
                    <h3>Payment</h3>
                    <p>Amount: ₹{booking.price}</p>
                    <p>Status: {booking.paymentStatus}</p>
                </div>
            </div>

            {booking.bookingStatus === "ReportReady" ? (
                <div className="lab-report-box">
                    📄 Your report is ready. Please contact support to access your official report.
                </div>
            ) : (
                <div className="lab-report-pending-box">
                    Your report will appear here once testing is complete — no report exists yet.
                </div>
            )}

        </div>
    );
}

export default LabBookingDetails;
