import React, { useEffect, useRef, useState } from "react";
import { useParams, Link, useNavigate } from "react-router-dom";
import { MapContainer, TileLayer, Marker, Popup, Polyline } from "react-leaflet";
import L from "leaflet";
import "leaflet/dist/leaflet.css";
import { useAuth } from "../context/AuthContext";
import { getOrderTracking } from "../services/orderService";
import "./OrderTracking.css";

// Default marker icons don't ship correctly with bundlers — build
// simple, dependency-free emoji-based divIcons instead.
const makeEmojiIcon = (emoji, size = 34) =>
    L.divIcon({
        html: `<div class="tracking-marker-emoji" style="font-size:${size}px">${emoji}</div>`,
        className: "tracking-marker-wrapper",
        iconSize: [size, size],
        iconAnchor: [size / 2, size / 2]
    });

const pharmacyIcon = makeEmojiIcon("🏥");
const homeIcon = makeEmojiIcon("🏠");
const courierIcon = makeEmojiIcon("🛵", 30);

const PHASE_STEPS = [
    { key: "Order Confirmed", label: "Order Placed", icon: "✅" },
    { key: "Preparing Order", label: "Pharmacy Preparing", icon: "🧪" },
    { key: "Out for Delivery", label: "Out for Delivery", icon: "🛵" },
    { key: "Arriving", label: "Arriving", icon: "📍" },
    { key: "Delivered", label: "Delivered", icon: "🎉" }
];

const phaseIndex = (phase) => {
    if (phase === "Cancelled") return -1;
    const idx = PHASE_STEPS.findIndex((s) => s.key === phase);
    // "Order Confirmed" / "Preparing Order" collapse onto the same
    // step index progression used for the stepper UI.
    return idx >= 0 ? idx : 0;
};

function FitBounds({ points, mapRef }) {
    useEffect(() => {
        if (!mapRef.current || points.length === 0) return;
        const bounds = L.latLngBounds(points.map((p) => [p.lat, p.lng]));
        mapRef.current.fitBounds(bounds, { padding: [50, 50] });
    }, [points, mapRef]);
    return null;
}

function OrderTracking() {
    const { id } = useParams();
    const navigate = useNavigate();
    const { token, isAuthenticated } = useAuth();

    const [tracking, setTracking] = useState(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState("");
    const mapRef = useRef(null);
    const pollRef = useRef(null);

    useEffect(() => {
        if (!isAuthenticated) {
            navigate("/login", { state: { from: `/orders/${id}/tracking` } });
            return;
        }

        const fetchTracking = async () => {
            try {
                const data = await getOrderTracking(id, token);
                if (data && data.success) {
                    setTracking(data.tracking);
                    setError("");
                } else {
                    setError("Unable to load tracking information.");
                }
            } catch (err) {
                console.error("Tracking fetch error:", err);
                setError(err.message || "Unable to load tracking information.");
            } finally {
                setLoading(false);
            }
        };

        fetchTracking();

        // Poll every 4 seconds so the courier marker animates live.
        pollRef.current = setInterval(fetchTracking, 4000);

        return () => clearInterval(pollRef.current);
    }, [id, isAuthenticated, token, navigate]);

    if (loading) {
        return (
            <div className="tracking-page">
                <div className="tracking-message">
                    <div className="tracking-loader"></div>
                    <p>Loading live tracking...</p>
                </div>
            </div>
        );
    }

    if (error || !tracking) {
        return (
            <div className="tracking-page">
                <div className="tracking-error-card">
                    <div className="error-icon">🔒</div>
                    <h2>Tracking Unavailable</h2>
                    <p>{error || "You do not have permission to view this order."}</p>
                    <Link to="/orders" className="back-orders-btn">
                        ← Back to My Orders
                    </Link>
                </div>
            </div>
        );
    }

    const {
        status,
        phase,
        progress,
        pharmacyLocation,
        deliveryLocation,
        courierLocation,
        courierName,
        courierPhone,
        etaMinutesRemaining,
        shippingAddress
    } = tracking;

    const points = [pharmacyLocation, deliveryLocation].filter(Boolean);
    const currentStepIdx = phaseIndex(phase);
    const isCancelled = status === "Cancelled";
    const isDelivered = status === "Delivered";
    const isShipped = status === "Shipped";

    return (
        <div className="tracking-page">
            <div className="tracking-header">
                <Link to={`/orders/${id}`} className="back-link">
                    ← Back to Order Details
                </Link>
                <div className="header-title-row">
                    <div>
                        <h1>Live Order Tracking</h1>
                        <p className="order-id-sub">Order #{id.slice(-8).toUpperCase()}</p>
                    </div>
                    {!isCancelled && (
                        <div className="eta-badge">
                            {isDelivered ? "Delivered 🎉" : `ETA: ${etaMinutesRemaining} min`}
                        </div>
                    )}
                </div>
            </div>

            {isCancelled ? (
                <div className="cancelled-banner">❌ This order was cancelled.</div>
            ) : (
                <>
                    {/* PHASE STEPPER */}
                    <div className="tracking-stepper">
                        {PHASE_STEPS.map((step, idx) => {
                            const isCompleted = idx <= currentStepIdx;
                            const isCurrent = idx === currentStepIdx;
                            return (
                                <div
                                    key={step.key}
                                    className={`tracking-step ${isCompleted ? "completed" : ""} ${isCurrent ? "current" : ""}`}
                                >
                                    <div className="tracking-step-icon">{isCompleted ? "✓" : step.icon}</div>
                                    <span>{step.label}</span>
                                </div>
                            );
                        })}
                    </div>

                    {/* MAP */}
                    <div className="tracking-map-card">
                        {!isShipped && !isDelivered && (
                            <div className="tracking-waiting-banner">
                                🧪 Your order is being prepared by the pharmacy. The courier will appear here
                                on the map once it's out for delivery.
                            </div>
                        )}

                        <MapContainer
                            center={[pharmacyLocation.lat, pharmacyLocation.lng]}
                            zoom={13}
                            scrollWheelZoom={true}
                            className="tracking-leaflet-map"
                            ref={mapRef}
                        >
                            <TileLayer
                                attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
                                url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                            />

                            <FitBounds points={points} mapRef={mapRef} />

                            <Marker position={[pharmacyLocation.lat, pharmacyLocation.lng]} icon={pharmacyIcon}>
                                <Popup>Pharmacy — order dispatch point</Popup>
                            </Marker>

                            <Marker position={[deliveryLocation.lat, deliveryLocation.lng]} icon={homeIcon}>
                                <Popup>
                                    Delivery address
                                    <br />
                                    {shippingAddress?.addressLine}, {shippingAddress?.city}
                                </Popup>
                            </Marker>

                            {(isShipped || isDelivered) && courierLocation && (
                                <Marker position={[courierLocation.lat, courierLocation.lng]} icon={courierIcon}>
                                    <Popup>
                                        {courierName} is on the way
                                        <br />
                                        📞 {courierPhone}
                                    </Popup>
                                </Marker>
                            )}

                            <Polyline
                                positions={[
                                    [pharmacyLocation.lat, pharmacyLocation.lng],
                                    [deliveryLocation.lat, deliveryLocation.lng]
                                ]}
                                pathOptions={{ color: "#2563eb", weight: 3, dashArray: "6 8" }}
                            />
                        </MapContainer>
                    </div>

                    {/* PROGRESS BAR */}
                    {isShipped && (
                        <div className="tracking-progress-bar">
                            <div
                                className="tracking-progress-fill"
                                style={{ width: `${Math.round((progress || 0) * 100)}%` }}
                            ></div>
                        </div>
                    )}

                    {/* COURIER INFO */}
                    {(isShipped || isDelivered) && (
                        <div className="courier-info-card">
                            <div className="courier-avatar">🛵</div>
                            <div>
                                <strong>{courierName}</strong>
                                <p>📞 {courierPhone}</p>
                            </div>
                            <div className="courier-status-pill">
                                {isDelivered ? "Delivered" : "En Route"}
                            </div>
                        </div>
                    )}
                </>
            )}
        </div>
    );
}

export default OrderTracking;
