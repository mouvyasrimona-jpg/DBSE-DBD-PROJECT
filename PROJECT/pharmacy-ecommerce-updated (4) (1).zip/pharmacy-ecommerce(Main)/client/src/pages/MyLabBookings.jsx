import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import "./MyLabBookings.css";

const API_BASE = "http://localhost:5000/api/lab-bookings";

const STATUS_LABELS = {
    Confirmed: "Confirmed",
    Scheduled: "Slot Scheduled",
    SampleCollected: "Sample Collected",
    SampleReceived: "Sample Received",
    Testing: "Testing",
    ReportReady: "Report Ready",
    Cancelled: "Cancelled"
};

function MyLabBookings() {
    const { token } = useAuth();
    const [bookings, setBookings] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState("");

    useEffect(() => {
        fetch(`${API_BASE}/my`, { headers: { Authorization: `Bearer ${token}` } })
            .then((r) => r.json())
            .then((d) => {
                if (d.success) setBookings(d.bookings);
                else setError(d.message || "Failed to load bookings");
            })
            .catch(() => setError("Failed to load bookings"))
            .finally(() => setLoading(false));
    }, [token]);

    if (loading) {
        return <div className="lab-bookings-page"><div className="lab-loading">Loading your lab bookings...</div></div>;
    }

    return (
        <div className="lab-bookings-page">
            <h1>My Lab Bookings</h1>
            <p className="lab-bookings-subtitle">Track and manage your booked lab tests.</p>

            {error && <div className="lab-error">{error}</div>}

            {bookings.length === 0 ? (
                <div className="lab-bookings-empty">
                    <div>🧪</div>
                    <h3>No lab bookings yet</h3>
                    <p>Book a lab test to see it tracked here.</p>
                    <Link to="/lab-tests" className="lab-browse-btn">Browse Lab Tests</Link>
                </div>
            ) : (
                <div className="lab-bookings-list">
                    {bookings.map((b) => (
                        <Link to={`/lab-bookings/${b._id}`} className="lab-booking-card" key={b._id}>
                            <div className="lab-booking-top">
                                <strong>{b.testName}</strong>
                                <span className={`lab-status-badge status-${b.bookingStatus.toLowerCase()}`}>
                                    {STATUS_LABELS[b.bookingStatus] || b.bookingStatus}
                                </span>
                            </div>
                            <p className="lab-booking-id">Booking ID: {b.bookingId}</p>
                            <div className="lab-booking-meta">
                                <span>📅 {new Date(b.bookingDate).toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" })}</span>
                                <span>⏰ {b.timeSlot}</span>
                                <span>{b.collectionType === "Home" ? "🏠 Home Collection" : `🏥 ${b.centerId?.name || "Center Visit"}`}</span>
                            </div>
                            <div className="lab-booking-price">₹{b.price}</div>
                        </Link>
                    ))}
                </div>
            )}
        </div>
    );
}

export default MyLabBookings;
