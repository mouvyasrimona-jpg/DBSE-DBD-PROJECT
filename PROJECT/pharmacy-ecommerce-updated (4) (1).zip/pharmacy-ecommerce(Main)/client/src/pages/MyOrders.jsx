import React, { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import { getMyOrders } from "../services/orderService";
import "./MyOrders.css";

const MEDICINE_API = "http://localhost:5000/api/medicines";

function MyOrders() {
    const navigate = useNavigate();
    const { token, isAuthenticated } = useAuth();

    const [orders, setOrders] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState("");
    const [reorderingId, setReorderingId] = useState(null);
    const [reorderMsg, setReorderMsg] = useState("");

    useEffect(() => {
        if (!isAuthenticated) {
            navigate("/login", { state: { from: "/orders" } });
            return;
        }

        const fetchOrders = async () => {
            try {
                setLoading(true);
                setError("");
                const data = await getMyOrders(token);

                if (data && data.success) {
                    setOrders(data.orders || []);
                } else {
                    setError("Unable to load orders.");
                }
            } catch (err) {
                console.error("Fetch orders error:", err);
                setError(err.message || "Failed to fetch order history.");
            } finally {
                setLoading(false);
            }
        };

        fetchOrders();
    }, [isAuthenticated, token, navigate]);

    const getStatusBadgeClass = (status) => {
        switch (status?.toLowerCase()) {
            case "delivered":
                return "badge-delivered";
            case "shipped":
                return "badge-shipped";
            case "processing":
                return "badge-processing";
            case "cancelled":
                return "badge-cancelled";
            default:
                return "badge-pending";
        }
    };

    // =====================================================
    // SMART MEDICINE CABINET — REORDER
    // Re-fetches each medicine's CURRENT price/stock instead of
    // trusting the old order snapshot, since both can change
    // between when the order was placed and now.
    // =====================================================
    const handleReorder = async (order) => {
        try {
            setReorderingId(order._id);
            setReorderMsg("");

            let currentCart = [];
            const storedCart = localStorage.getItem("cart");
            if (storedCart) {
                try { currentCart = JSON.parse(storedCart); } catch { currentCart = []; }
            }

            let addedCount = 0;
            let skippedCount = 0;

            for (const orderItem of order.items || []) {
                try {
                    const res = await fetch(`${MEDICINE_API}/${orderItem.medicineId}`);
                    const data = await res.json();

                    if (!res.ok || !data.success || !data.medicine) {
                        skippedCount++;
                        continue;
                    }

                    const medicine = data.medicine;

                    if (medicine.stock <= 0) {
                        skippedCount++;
                        continue;
                    }

                    const desiredQty = Math.min(orderItem.quantity, medicine.stock);
                    const existingIndex = currentCart.findIndex((c) => c._id === medicine._id);

                    if (existingIndex > -1) {
                        currentCart[existingIndex].cartQuantity = Math.min(
                            currentCart[existingIndex].cartQuantity + desiredQty,
                            medicine.stock
                        );
                    } else {
                        currentCart.push({
                            _id: medicine._id,
                            name: medicine.name,
                            price: medicine.price,
                            stock: medicine.stock,
                            image: medicine.image || "",
                            category: medicine.category || "",
                            genericName: medicine.genericName || "",
                            prescriptionRequired: !!medicine.prescriptionRequired,
                            selectedPharmacy: orderItem.selectedPharmacy || null,
                            cartQuantity: desiredQty
                        });
                    }

                    addedCount++;

                } catch {
                    skippedCount++;
                }
            }

            localStorage.setItem("cart", JSON.stringify(currentCart));
            window.dispatchEvent(new Event("cartUpdated"));

            if (addedCount > 0) {
                setReorderMsg(
                    skippedCount > 0
                        ? `🛒 ${addedCount} item(s) added to cart. ${skippedCount} item(s) unavailable and skipped.`
                        : `🛒 All ${addedCount} item(s) added to cart!`
                );
                setTimeout(() => navigate("/cart"), 1200);
            } else {
                setReorderMsg("⚠️ None of these items are currently available.");
            }

        } catch (err) {
            console.error("Reorder error:", err);
            setReorderMsg("Failed to reorder. Please try again.");
        } finally {
            setReorderingId(null);
            setTimeout(() => setReorderMsg(""), 4000);
        }
    };

    return (
        <div className="orders-page">
            <div className="orders-header">
                <div>
                    <span className="orders-badge">📦 My Account</span>
                    <h1>My <span>Order History</span></h1>
                    <p>Track your recent medicine purchases and delivery progress.</p>
                </div>
            </div>

            {loading && (
                <div className="orders-message">
                    <div className="loader"></div>
                    <p>Loading your orders...</p>
                </div>
            )}

            {!loading && error && (
                <div className="orders-message error-box">
                    <h3>⚠️ Error Loading Orders</h3>
                    <p>{error}</p>
                    <button onClick={() => window.location.reload()}>Try Again</button>
                </div>
            )}

            {!loading && !error && orders.length === 0 && (
                <div className="orders-empty-card">
                    <div className="empty-icon">🛍️</div>
                    <h2>No Orders Found</h2>
                    <p>You haven't placed any medicine orders yet.</p>
                    <Link to="/medicines" className="shop-now-btn">
                        Browse Medicines →
                    </Link>
                </div>
            )}

            {reorderMsg && (
                <div className="reorder-toast">{reorderMsg}</div>
            )}

            {!loading && !error && orders.length > 0 && (
                <div className="orders-list">
                    {orders.map((order) => (
                        <div className="order-card" key={order._id}>
                            <div className="order-card-header">
                                <div>
                                    <span className="order-id">Order #{order._id}</span>
                                    <span className="order-date">
                                        📅 {new Date(order.createdAt).toLocaleDateString("en-IN", {
                                            day: "numeric",
                                            month: "short",
                                            year: "numeric"
                                        })}
                                    </span>
                                </div>
                                <span className={`status-pill ${getStatusBadgeClass(order.status)}`}>
                                    {order.status}
                                </span>
                            </div>

                            <div className="order-card-body">
                                <div className="order-items-preview">
                                    {order.items?.map((item, idx) => (
                                        <div className="preview-item" key={idx}>
                                            <span className="item-name">💊 {item.name}</span>
                                            <span className="item-qty">× {item.quantity}</span>
                                        </div>
                                    ))}
                                </div>

                                <div className="order-meta">
                                    <div>
                                        <span className="meta-label">Payment</span>
                                        <strong>{order.paymentMethod} ({order.paymentStatus})</strong>
                                    </div>
                                    <div>
                                        <span className="meta-label">Total Amount</span>
                                        <strong className="total-highlight">₹{Number(order.totalAmount).toFixed(2)}</strong>
                                    </div>
                                </div>
                            </div>

                            <div className="order-card-footer">
                                <button
                                    className="reorder-btn"
                                    onClick={() => handleReorder(order)}
                                    disabled={reorderingId === order._id}
                                >
                                    {reorderingId === order._id ? "Adding..." : "🔁 Reorder"}
                                </button>
                                <Link to={`/orders/${order._id}`} className="view-details-btn">
                                    View Details & Tracking →
                                </Link>
                            </div>
                        </div>
                    ))}
                </div>
            )}
        </div>
    );
}

export default MyOrders;
