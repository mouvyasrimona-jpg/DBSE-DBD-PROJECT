import React, { useRef, useState, useEffect } from "react";
import { useAuth } from "../context/AuthContext";
import { useNavigate } from "react-router-dom";
import "./Prescription.css";

const API_URL = "http://localhost:5000/api/prescriptions";

const Prescription = () => {
    const fileInputRef = useRef(null);
    const navigate = useNavigate();
    const { token, isAuthenticated } = useAuth();

    const [selectedFile, setSelectedFile] = useState(null);
    const [uploading, setUploading] = useState(false);
    const [error, setError] = useState("");
    const [successMsg, setSuccessMsg] = useState("");
    const [prescriptions, setPrescriptions] = useState([]);
    const [loadingList, setLoadingList] = useState(true);

    const fetchMyPrescriptions = async () => {
        if (!isAuthenticated || !token) {
            setLoadingList(false);
            return;
        }

        try {
            setLoadingList(true);
            const res = await fetch(`${API_URL}/my-prescriptions`, {
                headers: {
                    Authorization: `Bearer ${token}`
                }
            });

            const data = await res.json();
            if (data && data.success) {
                setPrescriptions(data.prescriptions || []);
            }
        } catch (err) {
            console.error("Fetch prescriptions error:", err);
        } finally {
            setLoadingList(false);
        }
    };

    useEffect(() => {
        fetchMyPrescriptions();
    }, [isAuthenticated, token]);

    const handleChooseFile = () => {
        fileInputRef.current?.click();
    };

    const handleFileChange = (event) => {
        const file = event.target.files?.[0];

        setError("");
        setSuccessMsg("");

        if (!file) {
            setSelectedFile(null);
            return;
        }

        // Allowed file types
        const allowedTypes = ["application/pdf", "image/jpeg", "image/png"];

        if (!allowedTypes.includes(file.type)) {
            setError("Only PDF, JPG and PNG files are allowed.");
            event.target.value = "";
            setSelectedFile(null);
            return;
        }

        // Maximum 5MB
        if (file.size > 5 * 1024 * 1024) {
            setError("File size must be less than 5MB.");
            event.target.value = "";
            setSelectedFile(null);
            return;
        }

        setSelectedFile(file);
    };

    const handleRemoveFile = () => {
        setSelectedFile(null);
        setError("");
        setSuccessMsg("");

        if (fileInputRef.current) {
            fileInputRef.current.value = "";
        }
    };

    const handleUpload = async () => {
        if (!isAuthenticated) {
            navigate("/login", { state: { from: "/prescription" } });
            return;
        }

        if (!selectedFile) {
            setError("Please select a prescription first.");
            return;
        }

        try {
            setUploading(true);
            setError("");
            setSuccessMsg("");

            const formData = new FormData();
            formData.append("prescription", selectedFile);

            const res = await fetch(`${API_URL}/upload`, {
                method: "POST",
                headers: {
                    Authorization: `Bearer ${token}`
                },
                body: formData
            });

            const data = await res.json();

            if (res.ok && data.success) {
                setSuccessMsg("Prescription uploaded successfully!");
                setSelectedFile(null);
                if (fileInputRef.current) {
                    fileInputRef.current.value = "";
                }
                fetchMyPrescriptions();
            } else {
                setError(data.message || "Failed to upload prescription.");
            }
        } catch (err) {
            console.error("Upload error:", err);
            setError(err.message || "Server error while uploading prescription.");
        } finally {
            setUploading(false);
        }
    };

    return (
        <div className="prescription-page">
            {/* HEADER */}
            <section className="prescription-header">
                <div className="prescription-badge">
                    📄 Secure Prescription Management
                </div>

                <h1>
                    Upload Your <span>Prescription</span>
                </h1>

                <p>
                    Upload your prescription securely and let our pharmacy team review it before processing your medicine order.
                </p>
            </section>

            {/* MAIN */}
            <section className="prescription-container">
                <div className="prescription-card">
                    <div className="upload-icon">📄</div>

                    <h2>Upload Prescription</h2>

                    <p className="upload-description">
                        Upload a clear image or PDF of your prescription.
                    </p>

                    {/* UPLOAD AREA */}
                    <div className="upload-area" onClick={handleChooseFile}>
                        <div className="upload-cloud">☁️</div>

                        <h3>
                            {selectedFile
                                ? "Prescription Selected"
                                : "Choose your prescription"}
                        </h3>

                        <p>Click here to browse your device</p>

                        <span>PDF, JPG or PNG • Maximum 5MB</span>

                        <input
                            ref={fileInputRef}
                            type="file"
                            accept=".pdf,.jpg,.jpeg,.png"
                            onChange={handleFileChange}
                            hidden
                        />
                    </div>

                    {/* ERROR & SUCCESS ALERTS */}
                    {error && <div className="prescription-error">⚠️ {error}</div>}
                    {successMsg && <div className="prescription-success">✅ {successMsg}</div>}

                    {/* SELECTED FILE */}
                    {selectedFile && (
                        <div className="selected-file">
                            <div className="file-icon">
                                {selectedFile.type === "application/pdf" ? "📄" : "🖼️"}
                            </div>

                            <div className="file-details">
                                <strong>{selectedFile.name}</strong>
                                <span>{(selectedFile.size / 1024 / 1024).toFixed(2)} MB</span>
                            </div>

                            <button
                                type="button"
                                className="remove-file"
                                onClick={(event) => {
                                    event.stopPropagation();
                                    handleRemoveFile();
                                }}
                            >
                                ✕
                            </button>
                        </div>
                    )}

                    {/* BUTTON */}
                    <button
                        type="button"
                        className="upload-prescription-btn"
                        onClick={handleUpload}
                        disabled={!selectedFile || uploading}
                    >
                        {uploading ? "Uploading..." : "📤 Upload Prescription"}
                    </button>

                    <div className="prescription-security">
                        🔒 Your prescription information is handled securely.
                    </div>
                </div>

                {/* USER'S PRESCRIPTIONS HISTORY */}
                <div className="prescriptions-history-card">
                    <h2>My Uploaded Prescriptions</h2>
                    <p className="history-subtitle">Track status and review notes from our licensed pharmacists.</p>

                    {loadingList && <p className="loading-txt">Loading your prescriptions...</p>}

                    {!loadingList && prescriptions.length === 0 && (
                        <div className="empty-rx-box">
                            <p>No prescriptions uploaded yet.</p>
                        </div>
                    )}

                    {!loadingList && prescriptions.length > 0 && (
                        <div className="rx-list">
                            {prescriptions.map((rx) => {
                                const isPending = rx.status === "Pending";
                                const isProcessing = rx.status === "Processing";
                                const isApproved = rx.status === "Approved";
                                const isRejected = rx.status === "Rejected";

                                return (
                                    <div className="rx-item" key={rx._id}>
                                        <div className="rx-item-header">
                                            <div>
                                                <strong>📄 {rx.originalName}</strong>
                                                <span className="rx-date">
                                                    📅 {new Date(rx.createdAt).toLocaleDateString()}
                                                </span>
                                            </div>
                                            <span className={`status-pill ${rx.status?.toLowerCase()}`}>
                                                {rx.status}
                                            </span>
                                        </div>

                                        {/* STATUS TIMELINE */}
                                        <div className="rx-timeline">
                                            <div className="timeline-step completed">
                                                <span className="step-dot">✓</span>
                                                <span className="step-text">Uploaded</span>
                                            </div>
                                            <div className={`timeline-line ${!isPending ? "active" : ""}`}></div>
                                            <div className={`timeline-step ${!isPending ? "completed" : "current"}`}>
                                                <span className="step-dot">{!isPending ? "✓" : "●"}</span>
                                                <span className="step-text">Pharmacist Review</span>
                                            </div>
                                            <div className={`timeline-line ${isApproved || isRejected ? "active" : ""}`}></div>
                                            <div className={`timeline-step ${isApproved ? "completed approved" : isRejected ? "completed rejected" : ""}`}>
                                                <span className="step-dot">{isApproved ? "✓" : isRejected ? "✕" : "○"}</span>
                                                <span className="step-text">{isRejected ? "Rejected" : "Approved"}</span>
                                            </div>
                                        </div>

                                        {/* OCR SCAN RESULTS */}
                                        {(rx.ocrDetectedText || (rx.detectedMedicines && rx.detectedMedicines.length > 0)) && (
                                            <div className="ocr-results-box">
                                                <div className="ocr-box-header">
                                                    <span>🔍 OCR Scan &amp; Medicine Detection</span>
                                                    <span className="ocr-badge">Simulated Engine</span>
                                                </div>
                                                {rx.detectedMedicines && rx.detectedMedicines.length > 0 && (
                                                    <div className="detected-chips-row">
                                                        {rx.detectedMedicines.map((med, mIdx) => (
                                                            <span key={mIdx} className="detected-chip">
                                                                💊 {med}
                                                            </span>
                                                        ))}
                                                    </div>
                                                )}
                                                {rx.ocrDetectedText && (
                                                    <p className="ocr-text-preview">"{rx.ocrDetectedText}"</p>
                                                )}
                                            </div>
                                        )}

                                        {rx.rejectionReason && (
                                            <div className="rejection-note">
                                                ⚠️ Pharmacist Note: {rx.rejectionReason}
                                            </div>
                                        )}

                                        <div className="rx-item-footer">
                                            <a
                                                href={`http://localhost:5000${rx.filePath}`}
                                                target="_blank"
                                                rel="noopener noreferrer"
                                                className="view-rx-link"
                                            >
                                                View Uploaded File ↗
                                            </a>
                                            {isApproved && (
                                                <span className="rx-approved-notice">
                                                    ✅ Verified for Prescription Checkout
                                                </span>
                                            )}
                                        </div>
                                    </div>
                                );
                            })}
                        </div>
                    )}
                </div>
            </section>
        </div>
    );
};

export default Prescription;