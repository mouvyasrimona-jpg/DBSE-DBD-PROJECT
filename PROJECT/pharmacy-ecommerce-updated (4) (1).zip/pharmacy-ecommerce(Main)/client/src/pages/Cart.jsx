﻿import React, { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import { createOrder } from "../services/orderService";
import "./Cart.css";

const API_RX = "http://localhost:5000/api/prescriptions";

function Cart() {
    const navigate = useNavigate();
    const { user, token, isAuthenticated } = useAuth();

    const [cart, setCart] = useState([]);
    const [currentStep, setCurrentStep] = useState(1); // 1: Review, 2: Rx Verification, 3: Address & Payment
    const [approvedPrescriptions, setApprovedPrescriptions] = useState([]);
    const [rxLoaded, setRxLoaded] = useState(false);

    const [shippingAddress, setShippingAddress] = useState({
        name: "", phone: "", addressLine: "", city: "", state: "", pincode: ""
    });
    const [paymentMethod, setPaymentMethod] = useState("COD");
    const [submitting, setSubmitting] = useState(false);
    const [error, setError] = useState("");
    const [orderSuccess, setOrderSuccess] = useState(null);

    // Simulated online payment gateway (QR scan) — no real gateway
    // keys are configured, so this mimics a UPI-style "scan & pay"
    // flow purely on the client before the order is actually placed.
    const [paymentModalStage, setPaymentModalStage] = useState(null); // null | "scanning" | "success"

    useEffect(() => {
        if (user && user.name) {
            setShippingAddress(prev => ({ ...prev, name: prev.name || user.name }));
        }
    }, [user]);

    useEffect(() => {
        const storedCart = localStorage.getItem("cart");
        if (storedCart) {
            try { setCart(JSON.parse(storedCart)); } catch { localStorage.removeItem("cart"); }
        }
    }, []);

    // Fetch customer's approved prescriptions with detectedMedicines
    useEffect(() => {
        if (!isAuthenticated || !token) {
            setRxLoaded(true);
            return;
        }

        fetch(`${API_RX}/my-prescriptions`, {
            headers: { Authorization: `Bearer ${token}` }
        })
            .then(r => r.json())
            .then(data => {
                if (data.success) {
                    const approved = (data.prescriptions || []).filter(p => p.status === "Approved");
                    setApprovedPrescriptions(approved);
                }
            })
            .catch(console.error)
            .finally(() => setRxLoaded(true));
    }, [isAuthenticated, token]);

    // Medicine-specific approved prescription check
    const isItemRxApproved = (item) => {
        if (!item.prescriptionRequired) return true;
        if (!approvedPrescriptions || approvedPrescriptions.length === 0) return false;

        const names = [item.name, item.genericName]
            .filter(Boolean)
            .map(n => n.toLowerCase().trim());

        return approvedPrescriptions.some(rx => {
            if (!rx.detectedMedicines || !Array.isArray(rx.detectedMedicines)) return false;
            return rx.detectedMedicines.some(det => {
                if (!det) return false;
                const detLower = String(det).toLowerCase().trim();
                return names.some(n => detLower.includes(n) || n.includes(detLower));
            });
        });
    };

    const updateCart = (medicineId, quantity) => {
        const updated = cart.map(item =>
            item._id === medicineId
                ? { ...item, cartQuantity: Math.max(1, Math.min(quantity, item.stock)) }
                : item
        );
        setCart(updated);
        localStorage.setItem("cart", JSON.stringify(updated));
        window.dispatchEvent(new Event("cartUpdated"));
    };

    const removeItem = (medicineId) => {
        const updated = cart.filter(item => item._id !== medicineId);
        setCart(updated);
        localStorage.setItem("cart", JSON.stringify(updated));
        window.dispatchEvent(new Event("cartUpdated"));
    };

    const clearCart = () => {
        setCart([]);
        localStorage.removeItem("cart");
        window.dispatchEvent(new Event("cartUpdated"));
    };

    const totalAmount = cart.reduce((t, i) => t + Number(i.price) * Number(i.cartQuantity), 0);
    const totalItems = cart.reduce((t, i) => t + Number(i.cartQuantity), 0);

    // Drive the simulated "scan & pay" timeline: scanning -> success -> place order
    useEffect(() => {
        if (paymentModalStage !== "scanning") return;
        const timer = setTimeout(() => {
            setPaymentModalStage("success");
        }, 2800);
        return () => clearTimeout(timer);
    }, [paymentModalStage]);

    useEffect(() => {
        if (paymentModalStage !== "success") return;
        const timer = setTimeout(async () => {
            await placeOrder();
            setPaymentModalStage(null);
        }, 1300);
        return () => clearTimeout(timer);
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [paymentModalStage]);

    const cancelPaymentModal = () => {
        setPaymentModalStage(null);
    };

    // Any Rx-required items that lack matching approved prescriptions
    const unapprovedRxItems = cart.filter(item => item.prescriptionRequired && !isItemRxApproved(item));
    const hasUnapprovedRx = unapprovedRxItems.length > 0;
    const hasRxItems = cart.some(i => i.prescriptionRequired);

    const handleProceedToStep2 = () => {
        if (!isAuthenticated) {
            navigate("/login", { state: { from: "/cart" } });
            return;
        }
        setCurrentStep(2);
        window.scrollTo({ top: 0, behavior: "smooth" });
    };

    const handleProceedToStep3 = () => {
        if (hasUnapprovedRx) {
            setError("Cannot proceed. Prescription verification failed for one or more medicines.");
            return;
        }
        setError("");
        setCurrentStep(3);
        window.scrollTo({ top: 0, behavior: "smooth" });
    };

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setShippingAddress(prev => ({ ...prev, [name]: value }));
    };

    const handleCreateOrderSubmit = async (e) => {
        e.preventDefault();
        setError("");

        if (!isAuthenticated || !token) {
            navigate("/login", { state: { from: "/cart" } });
            return;
        }

        if (hasUnapprovedRx) {
            setError("Order blocked: You must have an approved prescription matching each prescription-required medicine.");
            return;
        }

        const { name, phone, addressLine, city, state, pincode } = shippingAddress;
        if (!name.trim() || !phone.trim() || !addressLine.trim() || !city.trim() || !state.trim() || !pincode.trim()) {
            setError("Please fill in all shipping address fields.");
            return;
        }

        if (cart.length === 0) {
            setError("Your cart is empty.");
            return;
        }

        // ONLINE payments go through a simulated "scan & pay" gateway
        // modal first; the order is only created once that reports
        // success. COD skips straight to placing the order.
        if (paymentMethod === "ONLINE") {
            setPaymentModalStage("scanning");
            return;
        }

        await placeOrder();
    };

    // Actually creates the order via the API. Called directly for COD,
    // or after the simulated payment modal reports success for ONLINE.
    const placeOrder = async () => {
        const { name, phone, addressLine, city, state, pincode } = shippingAddress;

        try {
            setSubmitting(true);
            const orderPayload = {
                items: cart.map(item => ({
                    medicineId: item._id,
                    quantity: Number(item.cartQuantity),
                    selectedPharmacy: item.selectedPharmacy || null
                })),
                shippingAddress: {
                    name: name.trim(), phone: phone.trim(), addressLine: addressLine.trim(),
                    city: city.trim(), state: state.trim(), pincode: pincode.trim()
                },
                paymentMethod
            };

            const data = await createOrder(orderPayload, token);

            if (data && data.success) {
                clearCart();
                setOrderSuccess(data.order);
            } else {
                if (data.prescriptionRequired) {
                    setError("⛔ Server rejection: Prescription required medicine not approved in your account.");
                } else {
                    setError(data.message || "Failed to create order. Please try again.");
                }
            }
        } catch (err) {
            setError(err.message || "Server error. Please try again.");
        } finally {

            setSubmitting(false);
        }
    };

    // ORDER SUCCESS
    if (orderSuccess) {
        return (
            <div className="cart-page">
                <div className="order-success-card">
                    <div className="success-icon">🎉</div>
                    <div className="success-title">Order Placed Successfully!</div>
                    <div className="success-detail">
                        Thank you for ordering with <strong>PharmaCare</strong>. Your order is confirmed and will be dispatched shortly.
                    </div>
                    <div className="success-info-grid">
                        <div className="info-box">
                            <label>Order ID</label>
                            <strong>#{String(orderSuccess.id || orderSuccess._id).slice(-8).toUpperCase()}</strong>
                        </div>
                        <div className="info-box">
                            <label>Total Amount</label>
                            <strong>₹{Number(orderSuccess.totalAmount).toFixed(2)}</strong>
                        </div>
                        <div className="info-box">
                            <label>Payment Mode</label>
                            <strong>{orderSuccess.paymentMethod} ({orderSuccess.paymentStatus || "Pending"})</strong>
                        </div>
                        <div className="info-box">
                            <label>Order Status</label>
                            <strong style={{ color: "#0f766e" }}>{orderSuccess.status}</strong>
                        </div>
                    </div>
                    <div className="success-actions">
                        <Link to={`/orders/${orderSuccess._id || orderSuccess.id}/tracking`} className="btn-primary" style={{ textDecoration: "none" }}>
                            📍 Track Live on Map →
                        </Link>
                        <Link to="/orders" className="btn-secondary" style={{ textDecoration: "none" }}>
                            View All Orders
                        </Link>
                    </div>
                </div>
            </div>
        );
    }

    // EMPTY CART
    if (cart.length === 0) {
        return (
            <div className="cart-page">
                <div className="empty-cart">
                    <div style={{ fontSize: 64, marginBottom: 16 }}>🛒</div>
                    <h2>Your Shopping Cart is Empty</h2>
                    <p>Search over 10,000+ medicines and health products to get started.</p>
                    <Link to="/medicines" className="btn-primary" style={{ textDecoration: "none", display: "inline-flex" }}>
                        Browse Medicines →
                    </Link>
                </div>
            </div>
        );
    }

    return (
        <div className="cart-page">
            {/* MULTI-STEP PROGRESS BAR */}
            <div className="cart-stepper">
                <div className={`step-item ${currentStep >= 1 ? "active" : ""}`} onClick={() => setCurrentStep(1)}>
                    <span className="step-num">1</span>
                    <span className="step-label">Cart Review</span>
                </div>
                <div className="step-divider"></div>
                <div className={`step-item ${currentStep >= 2 ? "active" : ""}`} onClick={() => isAuthenticated && setCurrentStep(2)}>
                    <span className="step-num">2</span>
                    <span className="step-label">Rx Verification</span>
                </div>
                <div className="step-divider"></div>
                <div className={`step-item ${currentStep >= 3 ? "active" : ""}`} onClick={() => !hasUnapprovedRx && isAuthenticated && setCurrentStep(3)}>
                    <span className="step-num">3</span>
                    <span className="step-label">Checkout & Pay</span>
                </div>
            </div>

            <div className="cart-header">
                <div className="cart-badge">🛒 Step {currentStep} of 3</div>
                <h1>
                    {currentStep === 1 && `Review Your Cart (${totalItems} items)`}
                    {currentStep === 2 && "Prescription Verification Gate"}
                    {currentStep === 3 && "Shipping & Payment Details"}
                </h1>
            </div>

            <div className="cart-layout">
                {/* LEFT CONTENT */}
                <div className="cart-main-col">
                    {/* STEP 1: CART REVIEW */}
                    {currentStep === 1 && (
                        <div className="cart-items-section">
                            {hasUnapprovedRx && (
                                <div className="rx-warning-box">
                                    ⛔ <strong>Prescription Required:</strong> One or more items in your cart require an approved prescription.
                                    You can proceed to Step 2 to verify your prescriptions or upload one now.
                                </div>
                            )}

                            {cart.map(item => {
                                const approved = isItemRxApproved(item);
                                return (
                                    <div className="cart-item-card" key={item._id}>
                                        <div className="item-img-box">
                                            {item.image ? <img src={item.image} alt={item.name} /> : "💊"}
                                        </div>
                                        <div className="item-details">
                                            <div className="item-name">{item.name}</div>
                                            <div className="item-brand">{item.genericName || item.category}</div>
                                            <div className="item-price-unit">₹{Number(item.price).toFixed(2)} per unit</div>

                                            {item.prescriptionRequired && (
                                                <span className={`item-rx-badge ${approved ? "item-rx-approved" : "item-rx-pending"}`}>
                                                    {approved ? "✅ Rx Approved" : "⛔ Prescription Required"}
                                                </span>
                                            )}

                                            {item.selectedPharmacy && (
                                                <div className="item-pharmacy-tag">
                                                    🏥 {item.selectedPharmacy.shopName}
                                                </div>
                                            )}

                                            <div className="qty-controls">
                                                <button className="qty-btn" onClick={() => updateCart(item._id, item.cartQuantity - 1)}>−</button>
                                                <span className="qty-value">{item.cartQuantity}</span>
                                                <button className="qty-btn" onClick={() => updateCart(item._id, item.cartQuantity + 1)}>+</button>
                                            </div>
                                        </div>
                                        <div className="item-subtotal">
                                            <strong>₹{(Number(item.price) * item.cartQuantity).toFixed(2)}</strong>
                                        </div>
                                        <button className="remove-item-btn" onClick={() => removeItem(item._id)} title="Remove item">✕</button>
                                    </div>
                                );
                            })}

                            <div className="cart-review-actions">
                                <Link to="/medicines" className="btn-secondary" style={{ textDecoration: "none" }}>
                                    ← Add More Medicines
                                </Link>
                                <button className="btn-primary" onClick={handleProceedToStep2}>
                                    Next: Verify Prescriptions →
                                </button>
                            </div>
                        </div>
                    )}

                    {/* STEP 2: PRESCRIPTION VERIFICATION */}
                    {currentStep === 2 && (
                        <div className="cart-rx-verification-section">
                            <div className="rx-verification-card">
                                <h3>📋 Automated Prescription Gate Check</h3>
                                <p className="section-desc">
                                    Our system checks your uploaded and approved prescriptions against the medicines in your cart.
                                </p>

                                {!hasRxItems ? (
                                    <div className="rx-all-good-box">
                                        <span className="all-good-icon">✅</span>
                                        <div>
                                            <strong>No Prescription Required for This Order</strong>
                                            <p>All items in your cart are Over-The-Counter (OTC) medicines. You can proceed directly to checkout.</p>
                                        </div>
                                    </div>
                                ) : (
                                    <div className="rx-items-checklist">
                                        {cart.map(item => {
                                            if (!item.prescriptionRequired) {
                                                return (
                                                    <div key={item._id} className="rx-check-row otc">
                                                        <span className="check-icon">✓</span>
                                                        <div className="check-info">
                                                            <strong>{item.name}</strong>
                                                            <span>Over-The-Counter (No Rx needed)</span>
                                                        </div>
                                                        <span className="status-pill status-green">OTC</span>
                                                    </div>
                                                );
                                            }

                                            const approved = isItemRxApproved(item);
                                            return (
                                                <div key={item._id} className={`rx-check-row ${approved ? "approved" : "rejected"}`}>
                                                    <span className="check-icon">{approved ? "✅" : "⚠️"}</span>
                                                    <div className="check-info">
                                                        <strong>{item.name}</strong>
                                                        <small>{item.genericName}</small>
                                                        <span className="rx-feedback">
                                                            {approved
                                                                ? "Prescription validated and approved by licensed pharmacist."
                                                                : "Not found in your approved prescriptions. Please upload a doctor's prescription."}
                                                        </span>
                                                    </div>
                                                    <span className={`status-pill ${approved ? "status-green" : "status-red"}`}>
                                                        {approved ? "Approved" : "Action Needed"}
                                                    </span>
                                                </div>
                                            );
                                        })}
                                    </div>
                                )}

                                {hasUnapprovedRx && (
                                    <div className="rx-block-alert">
                                        <h4>⛔ Checkout Blocked</h4>
                                        <p>
                                            You must have an approved prescription for all Rx medicines before you can place this order.
                                        </p>
                                        <div className="rx-block-actions">
                                            <Link to="/prescription" className="btn-primary" style={{ textDecoration: "none" }}>
                                                📤 Upload Prescription Now
                                            </Link>
                                            <button className="btn-secondary" onClick={() => setCurrentStep(1)}>
                                                Back to Cart
                                            </button>
                                        </div>
                                    </div>
                                )}

                                <div className="step-actions-row">
                                    <button className="btn-secondary" onClick={() => setCurrentStep(1)}>
                                        ← Back to Cart
                                    </button>
                                    <button
                                        className="btn-primary"
                                        onClick={handleProceedToStep3}
                                        disabled={hasUnapprovedRx}
                                    >
                                        Proceed to Shipping & Payment →
                                    </button>
                                </div>
                            </div>
                        </div>
                    )}

                    {/* STEP 3: SHIPPING ADDRESS & PAYMENT */}
                    {currentStep === 3 && (
                        <div className="checkout-step-card">
                            <h3>🚚 Shipping Address & Payment</h3>
                            {error && <div className="error-banner">⚠️ {error}</div>}

                            <form onSubmit={handleCreateOrderSubmit}>
                                <div className="form-grid-2">
                                    <div className="form-group">
                                        <label>Recipient Name *</label>
                                        <input
                                            name="name"
                                            placeholder="Full legal name"
                                            value={shippingAddress.name}
                                            onChange={handleInputChange}
                                            required
                                        />
                                    </div>
                                    <div className="form-group">
                                        <label>Contact Phone *</label>
                                        <input
                                            name="phone"
                                            placeholder="10-digit mobile number"
                                            value={shippingAddress.phone}
                                            onChange={handleInputChange}
                                            required
                                        />
                                    </div>
                                </div>

                                <div className="form-group">
                                    <label>Street Address / House No / Apartment *</label>
                                    <input
                                        name="addressLine"
                                        placeholder="Flat/House No, Building, Street, Area"
                                        value={shippingAddress.addressLine}
                                        onChange={handleInputChange}
                                        required
                                    />
                                </div>

                                <div className="form-grid-3">
                                    <div className="form-group">
                                        <label>City *</label>
                                        <input
                                            name="city"
                                            placeholder="City"
                                            value={shippingAddress.city}
                                            onChange={handleInputChange}
                                            required
                                        />
                                    </div>
                                    <div className="form-group">
                                        <label>State *</label>
                                        <input
                                            name="state"
                                            placeholder="State"
                                            value={shippingAddress.state}
                                            onChange={handleInputChange}
                                            required
                                        />
                                    </div>
                                    <div className="form-group">
                                        <label>Pincode *</label>
                                        <input
                                            name="pincode"
                                            placeholder="6-digit PIN"
                                            value={shippingAddress.pincode}
                                            onChange={handleInputChange}
                                            required
                                        />
                                    </div>
                                </div>

                                <div className="payment-method-block">
                                    <label className="section-label">Select Payment Method</label>
                                    <div className="payment-options-grid">
                                        <div
                                            className={`payment-option-card ${paymentMethod === "COD" ? "selected" : ""}`}
                                            onClick={() => setPaymentMethod("COD")}
                                        >
                                            <div className="payment-option-icon">💵</div>
                                            <div className="payment-option-text">
                                                <strong>Cash on Delivery (COD)</strong>
                                                <span>Pay in cash or UPI upon delivery</span>
                                            </div>
                                            <div className="payment-radio">{paymentMethod === "COD" ? "●" : "○"}</div>
                                        </div>

                                        <div
                                            className={`payment-option-card ${paymentMethod === "ONLINE" ? "selected" : ""}`}
                                            onClick={() => setPaymentMethod("ONLINE")}
                                        >
                                            <div className="payment-option-icon">💳</div>
                                            <div className="payment-option-text">
                                                <strong>Online Payment (Cards / UPI)</strong>
                                                <span>Instant gateway payment via Razorpay</span>
                                            </div>
                                            <div className="payment-radio">{paymentMethod === "ONLINE" ? "●" : "○"}</div>
                                        </div>
                                    </div>

                                    {paymentMethod === "ONLINE" && (
                                        <div className="online-pay-info">
                                            ℹ️ Online payment architecture is ready. If test keys are not configured in your environment, placing order will complete in simulation mode.
                                        </div>
                                    )}
                                </div>

                                <div className="step-actions-row">
                                    <button type="button" className="btn-secondary" onClick={() => setCurrentStep(2)}>
                                        ← Back to Rx Check
                                    </button>
                                    <button type="submit" className="btn-primary" disabled={submitting}>
                                        {submitting ? "Placing Order..." : `Confirm & Place Order (₹${totalAmount.toFixed(2)})`}
                                    </button>
                                </div>
                            </form>
                        </div>
                    )}
                </div>

                {/* RIGHT SUMMARY CARD */}
                <div className="cart-summary-col">
                    <div className="cart-summary-card">
                        <div className="summary-title">Order Summary</div>

                        {(() => {
                            const primaryPharmacy = cart.find(i => i.selectedPharmacy)?.selectedPharmacy;
                            if (!primaryPharmacy) return null;
                            return (
                                <div className="selected-pharmacy-card">
                                    <div className="sp-icon">🏥</div>
                                    <div>
                                        <strong>{primaryPharmacy.shopName}</strong>
                                        <p>{primaryPharmacy.location}</p>
                                    </div>
                                </div>
                            );
                        })()}

                        <div className="summary-row">
                            <span>Subtotal ({totalItems} items)</span>
                            <span>₹{totalAmount.toFixed(2)}</span>
                        </div>
                        <div className="summary-row">
                            <span>Express Delivery</span>
                            <span style={{ color: "#16a34a", fontWeight: 700 }}>FREE</span>
                        </div>
                        <div className="summary-row">
                            <span>GST / Platform Tax</span>
                            <span>₹0.00</span>
                        </div>

                        <hr className="summary-divider" />

                        <div className="summary-total">
                            <span>Total Payable</span>
                            <span className="total-val">₹{totalAmount.toFixed(2)}</span>
                        </div>

                        <div className="summary-badges">
                            <div className="badge-line">🔒 256-Bit SSL Encrypted</div>
                            <div className="badge-line">💊 100% Genuine Pharmacy Stock</div>
                            <div className="badge-line">📄 Pharmacist Verification</div>
                        </div>
                    </div>
                </div>
            </div>

            {/* SIMULATED ONLINE PAYMENT GATEWAY MODAL */}
            {paymentModalStage && (
                <div className="payment-gateway-overlay">
                    <div className="payment-gateway-modal">
                        {paymentModalStage === "scanning" && (
                            <>
                                <div className="pg-header">
                                    <span>🔒 Secure UPI Payment</span>
                                    <button type="button" className="pg-close" onClick={cancelPaymentModal}>✕</button>
                                </div>
                                <div className="pg-qr-box">
                                    <div className="pg-qr-code" aria-hidden="true">
                                        {Array.from({ length: 49 }).map((_, i) => (
                                            <span
                                                key={i}
                                                className={((i * 7 + Math.floor(i / 7) * 3) % 3 === 0) ? "pg-qr-dark" : ""}
                                            />
                                        ))}
                                    </div>
                                </div>
                                <p className="pg-amount">₹{totalAmount.toFixed(2)}</p>
                                <p className="pg-status-text">
                                    <span className="pg-spinner"></span>
                                    Scan with any UPI app to pay… waiting for confirmation
                                </p>
                                <p className="pg-note">This is a simulated test-mode gateway. Payment confirms automatically.</p>
                                <button type="button" className="btn-secondary pg-cancel-btn" onClick={cancelPaymentModal}>
                                    Cancel Payment
                                </button>
                            </>
                        )}

                        {paymentModalStage === "success" && (
                            <div className="pg-success">
                                <div className="pg-success-tick">✓</div>
                                <h3>Payment Successful</h3>
                                <p>₹{totalAmount.toFixed(2)} paid via ONLINE</p>
                                <p className="pg-note">Placing your order…</p>
                            </div>
                        )}
                    </div>
                </div>
            )}
        </div>
    );
}

export default Cart;
