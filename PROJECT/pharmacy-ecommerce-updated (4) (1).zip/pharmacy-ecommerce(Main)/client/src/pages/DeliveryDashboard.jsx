import React, { useEffect, useState } from "react";
import { useAuth } from "../context/AuthContext";
import "./DeliveryDashboard.css";

const API_BASE = "http://localhost:5000/api";

function DeliveryDashboard() {
    const { token, user } = useAuth();
    const [tab, setTab] = useState("assigned");
    const [assigned, setAssigned] = useState([]);
    const [history, setHistory] = useState([]);
    const [loading, setLoading] = useState(true);
    const [otpInputs, setOtpInputs] = useState({});
    const [message, setMessage] = useState({ type: "", text: "" });

    const fetchData = async () => {
        try {
            setLoading(true);
            const [assignedRes, historyRes] = await Promise.all([
                fetch(`${API_BASE}/delivery/assigned`, { headers: { Authorization: `Bearer ${token}` } }),
                fetch(`${API_BASE}/delivery/history`, { headers: { Authorization: `Bearer ${token}` } })
            ]);
            const assignedData = await assignedRes.json();
            const historyData = await historyRes.json();
            if (assignedData.success) setAssigned(assignedData.orders);
            if (historyData.success) setHistory(historyData.orders);
        } catch (err) {
            console.error(err);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        if (token) fetchData();
    }, [token]);

    const updateStatus = async (orderId, status) => {
        try {
            const res = await fetch(`${API_BASE}/delivery/${orderId}/status`, {
                method: "PUT",
                headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
                body: JSON.stringify({ status })
            });
            const data = await res.json();
            if (data.success) {
                setMessage({ type: "success", text: `Order marked as ${status}` });
                fetchData();
            } else {
                setMessage({ type: "error", text: data.message });
            }
        } catch (err) {
            setMessage({ type: "error", text: "Failed to update status" });
        }
        setTimeout(() => setMessage({ type: "", text: "" }), 3000);
    };

    const submitOtp = async (orderId) => {
        const otp = otpInputs[orderId];
        if (!otp) return;
        try {
            const res = await fetch(`${API_BASE}/delivery/${orderId}/verify-otp`, {
                method: "PUT",
                headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
                body: JSON.stringify({ otp })
            });
            const data = await res.json();
            if (data.success) {
                setMessage({ type: "success", text: "Delivery confirmed! 🎉" });
                setOtpInputs({ ...otpInputs, [orderId]: "" });
                fetchData();
            } else {
                setMessage({ type: "error", text: `${data.message}${data.attemptsRemaining !== undefined ? ` (${data.attemptsRemaining} attempts left)` : ""}` });
            }
        } catch (err) {
            setMessage({ type: "error", text: "Failed to verify OTP" });
        }
        setTimeout(() => setMessage({ type: "", text: "" }), 4000);
    };

    if (loading) return <div className="delivery-loading">Loading your deliveries...</div>;

    const displayOrders = tab === "assigned" ? assigned : history;

    return (
        <div className="delivery-dashboard">
            <div className="delivery-header">
                <h1>🚚 Delivery Dashboard</h1>
                <p>Welcome, {user?.name}</p>
            </div>

            {message.text && <div className={`delivery-alert ${message.type}`}>{message.text}</div>}

            <div className="delivery-tabs">
                <button className={tab === "assigned" ? "active" : ""} onClick={() => setTab("assigned")}>
                    Assigned ({assigned.length})
                </button>
                <button className={tab === "history" ? "active" : ""} onClick={() => setTab("history")}>
                    History ({history.length})
                </button>
            </div>

            {displayOrders.length === 0 ? (
                <div className="delivery-empty">No deliveries here yet.</div>
            ) : (
                <div className="delivery-list">
                    {displayOrders.map((order) => (
                        <div className="delivery-card" key={order._id}>
                            <div className="delivery-card-top">
                                <strong>Order #{order._id.slice(-6).toUpperCase()}</strong>
                                <span className={`delivery-status-badge status-${order.status.toLowerCase()}`}>
                                    {order.status}
                                </span>
                            </div>

                            <p className="delivery-customer">👤 {order.userId?.name || "Customer"}</p>
                            <p className="delivery-address">
                                📍 {order.shippingAddress.addressLine}, {order.shippingAddress.city}, {order.shippingAddress.state} - {order.shippingAddress.pincode}
                            </p>
                            <p className="delivery-phone">📞 {order.shippingAddress.phone}</p>
                            <p className="delivery-items">
                                {order.items.map((it) => `${it.name} x${it.quantity}`).join(", ")}
                            </p>

                            {tab === "assigned" && order.status === "Packed" && (
                                <button className="delivery-action-btn" onClick={() => updateStatus(order._id, "PickedUp")}>
                                    Mark as Picked Up
                                </button>
                            )}

                            {tab === "assigned" && order.status === "PickedUp" && (
                                <button className="delivery-action-btn" onClick={() => updateStatus(order._id, "OutForDelivery")}>
                                    Start Delivery (Generate OTP)
                                </button>
                            )}

                            {tab === "assigned" && order.status === "OutForDelivery" && (
                                <div className="otp-entry">
                                    <input
                                        type="text"
                                        placeholder="Enter customer's 6-digit OTP"
                                        maxLength={6}
                                        value={otpInputs[order._id] || ""}
                                        onChange={(e) => setOtpInputs({ ...otpInputs, [order._id]: e.target.value })}
                                    />
                                    <button className="otp-submit-btn" onClick={() => submitOtp(order._id)}>
                                        Confirm Delivery
                                    </button>
                                </div>
                            )}
                        </div>
                    ))}
                </div>
            )}
        </div>
    );
}

export default DeliveryDashboard;
