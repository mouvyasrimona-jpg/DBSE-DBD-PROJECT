import React, { useEffect, useMemo, useState } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import "./medicines.css";

const API_URL = "http://localhost:5000/api/medicines";

function Medicines() {
    const navigate = useNavigate();
    const [searchParams] = useSearchParams();

    const [medicines, setMedicines] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState("");

    // Initialize from the URL so a search from Home/TopSearchBar
    // (e.g. /medicines?q=Dolo) actually filters this page instead
    // of silently showing every medicine.
    const [search, setSearch] = useState(searchParams.get("q") || "");
    const [category, setCategory] = useState(searchParams.get("category") || "All");
    const [sort, setSort] = useState("relevance");
    const [rxOnly, setRxOnly] = useState(false);

    useEffect(() => {
        fetchMedicines();
    }, []);

    // Keep the search/category box in sync if the URL changes later
    // (e.g. user searches again from the Home page top bar while
    // already on the Medicines page).
    useEffect(() => {
        const q = searchParams.get("q") || "";
        const cat = searchParams.get("category") || "All";
        setSearch(q);
        setCategory(cat);
    }, [searchParams]);

    const fetchMedicines = async () => {
        try {
            setLoading(true);
            setError("");

            const response = await fetch(API_URL);
            const data = await response.json();

            if (!response.ok) {
                throw new Error(data.message || "Failed to fetch medicines");
            }

            if (data.success) {
                setMedicines(data.medicines || []);
            } else {
                setMedicines([]);
            }
        } catch (err) {
            console.error(err);
            setError("Unable to load medicines.");
        } finally {
            setLoading(false);
        }
    };

    const categories = useMemo(() => {
        const values = medicines
            .map((medicine) => medicine.category)
            .filter(Boolean);

        return ["All", ...new Set(values)];
    }, [medicines]);

    const filteredMedicines = useMemo(() => {
        let result = [...medicines];

        const query = search.trim().toLowerCase();

        if (query) {
            result = result.filter((medicine) => {
                return (
                    medicine.name?.toLowerCase().includes(query) ||
                    medicine.brand?.toLowerCase().includes(query) ||
                    medicine.genericName?.toLowerCase().includes(query) ||
                    medicine.category?.toLowerCase().includes(query) ||
                    medicine.condition?.toLowerCase().includes(query)
                );
            });
        }

        if (category !== "All") {
            result = result.filter(
                (medicine) => medicine.category === category
            );
        }

        if (rxOnly) {
            result = result.filter(
                (medicine) => medicine.prescriptionRequired === true
            );
        }

        if (sort === "price-low") {
            result.sort((a, b) => Number(a.price) - Number(b.price));
        }

        if (sort === "price-high") {
            result.sort((a, b) => Number(b.price) - Number(a.price));
        }

        if (sort === "name") {
            result.sort((a, b) =>
                (a.name || "").localeCompare(b.name || "")
            );
        }

        if (sort === "rating") {
            result.sort(
                (a, b) =>
                    Number(b.rating || 0) - Number(a.rating || 0)
            );
        }

        return result;
    }, [medicines, search, category, sort, rxOnly]);

    const addToCart = (medicine) => {
        if (!medicine || medicine.stock <= 0) {
            return;
        }

        let cart = [];

        try {
            cart = JSON.parse(localStorage.getItem("cart")) || [];
        } catch {
            cart = [];
        }

        const existing = cart.find(
            (item) => item._id === medicine._id
        );

        if (existing) {
            if (existing.cartQuantity < medicine.stock) {
                existing.cartQuantity += 1;
            }
        } else {
            cart.push({
                _id: medicine._id,
                name: medicine.name,
                price: medicine.price,
                stock: medicine.stock,
                image: medicine.image || "",
                category: medicine.category || "",
                genericName: medicine.genericName || "",
                brand: medicine.brand || "",
                prescriptionRequired:
                    medicine.prescriptionRequired || false,
                cartQuantity: 1
            });
        }

        localStorage.setItem("cart", JSON.stringify(cart));
        window.dispatchEvent(new Event("cartUpdated"));
    };

    if (loading) {
        return (
            <div className="medicines-page">
                <div className="medicine-loading">
                    <div className="loading-spinner"></div>
                    <h3>Loading medicines...</h3>
                    <p>Fetching medicines from PharmaCare</p>
                </div>
            </div>
        );
    }

    if (error) {
        return (
            <div className="medicines-page">
                <div className="medicine-error">
                    <h2>Unable to load medicines</h2>
                    <p>{error}</p>

                    <button onClick={fetchMedicines}>
                        Try Again
                    </button>
                </div>
            </div>
        );
    }

    return (
        <div className="medicines-page">

            {/* HEADER */}
            <section className="medicine-header">

                <div>
                    <div className="breadcrumb">
                        Home / Medicines
                    </div>

                    <h1>Medicines & Healthcare Products</h1>

                    <p>
                        Browse medicines, healthcare products and
                        wellness essentials from PharmaCare.
                    </p>
                </div>

                <div className="medicine-count">
                    <strong>{filteredMedicines.length}</strong>
                    <span>Products</span>
                </div>

            </section>

            {/* SEARCH */}
            <section className="medicine-search-section">

                <div className="search-box">

                    <span>🔍</span>

                    <input
                        type="text"
                        placeholder="Search medicines, brands, conditions..."
                        value={search}
                        onChange={(e) => setSearch(e.target.value)}
                    />

                    {search && (
                        <button
                            className="clear-search"
                            onClick={() => setSearch("")}
                        >
                            ×
                        </button>
                    )}

                </div>

            </section>

            {/* FILTERS */}
            <section className="medicine-filter-bar">

                <div className="category-scroll">

                    {categories.map((item) => (
                        <button
                            key={item}
                            className={
                                category === item
                                    ? "category-btn active"
                                    : "category-btn"
                            }
                            onClick={() => setCategory(item)}
                        >
                            {item}
                        </button>
                    ))}

                </div>

                <div className="filter-right">

                    <label className="rx-filter">

                        <input
                            type="checkbox"
                            checked={rxOnly}
                            onChange={(e) =>
                                setRxOnly(e.target.checked)
                            }
                        />

                        Prescription Required

                    </label>

                    <select
                        value={sort}
                        onChange={(e) =>
                            setSort(e.target.value)
                        }
                    >
                        <option value="relevance">
                            Sort: Relevance
                        </option>

                        <option value="price-low">
                            Price: Low to High
                        </option>

                        <option value="price-high">
                            Price: High to Low
                        </option>

                        <option value="rating">
                            Highest Rated
                        </option>

                        <option value="name">
                            Name
                        </option>
                    </select>

                </div>

            </section>

            {/* PRODUCTS */}
            <section className="medicine-products">

                {filteredMedicines.length === 0 ? (

                    <div className="no-products">

                        <div>🔎</div>

                        <h2>Medicine not found</h2>

                        <p>
                            Please check the medicine name or browse our catalogue.
                        </p>

                        <button
                            onClick={() => {
                                setSearch("");
                                setCategory("All");
                                setRxOnly(false);
                            }}
                        >
                            Clear Filters
                        </button>

                    </div>

                ) : (

                    <div className="medicine-grid">

                        {filteredMedicines.map((medicine) => {

                            const mrp =
                                Number(medicine.mrp) ||
                                Number(medicine.price) * 1.25;

                            const price =
                                Number(medicine.price) || 0;

                            const discount =
                                mrp > price
                                    ? Math.round(
                                          ((mrp - price) /
                                              mrp) *
                                              100
                                      )
                                    : 0;

                            return (

                                <article
                                    className="pharmacy-product-card"
                                    key={medicine._id}
                                >

                                    {/* IMAGE */}
                                    <div className="product-image-area">

                                        {medicine.prescriptionRequired && (
                                            <span className="rx-badge">
                                                Rx
                                            </span>
                                        )}

                                        {!medicine.prescriptionRequired && (
                                            <span className="otc-badge">
                                                OTC
                                            </span>
                                        )}

                                        {discount > 0 && (
                                            <span className="discount-badge">
                                                {discount}% OFF
                                            </span>
                                        )}

                                        {medicine.image ? (
    <img
        src={
        medicine.image?.startsWith("http")
            ? medicine.image
            : `http://localhost:5000${medicine.image}`
    }
    alt={medicine.name}
    onError={(e) => {
        console.log("Image failed:", medicine.image);
        e.currentTarget.style.display = "none";

        if (e.currentTarget.nextSibling) {
            e.currentTarget.nextSibling.style.display = "flex";
        }
    }}
        
    />
) : null}

                                        <div
                                            className="image-placeholder"
                                            style={{
                                                display: medicine.image
                                                    ? "none"
                                                    : "flex"
                                            }}
                                        >
                                            💊
                                        </div>

                                    </div>

                                    {/* INFORMATION */}
                                    <div className="product-information">

                                        <div className="product-brand">
                                            {medicine.brand ||
                                                "PharmaCare"}
                                        </div>

                                        <h2>
                                            {medicine.name}
                                        </h2>

                                        <p className="pack-size">
                                            {medicine.packSize ||
                                                medicine.form ||
                                                "1 Unit"}
                                        </p>

                                        {medicine.genericName && (
                                            <p className="generic-name">
                                                {medicine.genericName}
                                            </p>
                                        )}

                                        <div className="product-rating">

                                            <span>
                                                ⭐{" "}
                                                {medicine.rating ||
                                                    "4.5"}
                                            </span>

                                            <span>
                                                •
                                            </span>

                                            <span>
                                                Trusted Product
                                            </span>

                                        </div>

                                        <div className="price-section">

                                            <span className="mrp">
                                                MRP ₹
                                                {mrp.toFixed(2)}
                                            </span>

                                            <div>

                                                <strong>
                                                    ₹
                                                    {price.toFixed(
                                                        2
                                                    )}
                                                </strong>

                                                {discount > 0 && (
                                                    <span className="discount-text">
                                                        {discount}%
                                                        OFF
                                                    </span>
                                                )}

                                            </div>

                                        </div>

                                        <p className="unit-price">
                                            ₹
                                            {(
                                                price /
                                                Math.max(
                                                    1,
                                                    medicine.units ||
                                                        1
                                                )
                                            ).toFixed(2)}
                                            / unit
                                        </p>

                                        <div className="delivery">

                                            🚚
                                            <span>
                                                Delivery available
                                            </span>

                                        </div>

                                        <div
                                            className={
                                                medicine.stock > 0
                                                    ? "stock available"
                                                    : "stock unavailable"
                                            }
                                        >
                                            {medicine.stock > 0
                                                ? "✓ In Stock"
                                                : "✕ Out of Stock"}
                                        </div>

                                        {medicine.prescriptionRequired && (
                                            <div className="prescription-note">
                                                📄 Prescription required
                                            </div>
                                        )}

                                        {/* ACTIONS */}
                                        <div className="product-actions">

                                            <button
                                                className="details-button"
                                                onClick={() =>
                                                    navigate(
                                                        `/medicines/${medicine._id}`
                                                    )
                                                }
                                            >
                                                Details
                                            </button>

                                            <button
                                                className="cart-button"
                                                disabled={
                                                    medicine.stock <=
                                                    0
                                                }
                                                onClick={() =>
                                                    addToCart(
                                                        medicine
                                                    )
                                                }
                                            >
                                                🛒 Add to Cart
                                            </button>

                                        </div>

                                    </div>

                                </article>

                            );
                        })}

                    </div>

                )}

            </section>

        </div>
    );
}

export default Medicines;