import React from "react";
import "./StaticPage.css";

function TermsAndConditions() {
    return (
        <div className="static-page">
            <h1>Terms &amp; Conditions</h1>
            <p className="static-subtitle">Please read before using PharmaCare.</p>

            <h2>Prescription medicines</h2>
            <p>
                Medicines marked "Prescription Required" can only be ordered after you upload a
                valid prescription and it is approved by a licensed pharmacist. We reserve the
                right to reject any prescription that appears incomplete, expired, or does not
                clearly correspond to the medicine being ordered.
            </p>

            <h2>Orders and delivery</h2>
            <p>
                Order status, delivery estimates, and tracking information shown on the platform
                reflect the actual state of your order in our system. Delivery timelines are
                estimates and may vary.
            </p>

            <h2>Account responsibility</h2>
            <p>
                You are responsible for keeping your account credentials secure. Notify us
                immediately of any unauthorized use of your account.
            </p>

            <h2>Limitation</h2>
            <p>
                PharmaCare provides a platform for ordering medicines; it does not provide
                medical advice, diagnosis, or treatment. Always consult a licensed healthcare
                professional for medical decisions.
            </p>
        </div>
    );
}

export default TermsAndConditions;
