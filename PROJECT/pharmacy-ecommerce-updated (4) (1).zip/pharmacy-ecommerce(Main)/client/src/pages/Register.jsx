import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import "./Register.css";

function Register() {
  const navigate = useNavigate();

  const [formData, setFormData] = useState({
    name: "",
    email: "",
    password: "",
    role: "customer",
  });

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    setError("");
    setSuccess("");

    // Basic validation
    if (!formData.name || !formData.email || !formData.password) {
      setError("Please fill all fields");
      return;
    }

    if (formData.password.length < 6) {
      setError("Password must be at least 6 characters");
      return;
    }

    try {
      setLoading(true);

      const response = await fetch(
        "http://localhost:5000/api/auth/register",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(formData),
        }
      );

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.message || "Registration failed");
      }
      // STEP 3 - Store JWT Token
localStorage.setItem("token", data.token);

// Store user
localStorage.setItem(
    "user",
    JSON.stringify(data.user)
);

      console.log("Register Response:", data);

      setSuccess("Registration successful!");

      // Clear form
      setFormData({
        name: "",
        email: "",
        password: "",
        role: "customer",
      });

      // Move to login page after 1 second
      setTimeout(() => {
        navigate("/login");
      }, 1000);

    } catch (err) {
      console.error("Registration Error:", err);
      setError(err.message || "Something went wrong");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="register-page">

      <div className="register-card">

        <div className="register-header">
          <div className="register-icon">💊</div>

          <h2>Create Account</h2>

          <p>
            Register to access your pharmacy account
          </p>
        </div>

        {error && (
          <div className="register-error">
            ❌ {error}
          </div>
        )}

        {success && (
          <div className="register-success">
            ✅ {success}
          </div>
        )}

        <form onSubmit={handleSubmit}>

          {/* NAME */}
          <div className="form-group">
            <label>Name</label>

            <div className="input-wrapper">
              <span>👤</span>

              <input
                type="text"
                name="name"
                placeholder="Enter your name"
                value={formData.name}
                onChange={handleChange}
              />
            </div>
          </div>

          {/* EMAIL */}
          <div className="form-group">
            <label>Email</label>

            <div className="input-wrapper">
              <span>📧</span>

              <input
                type="email"
                name="email"
                placeholder="Enter your email"
                value={formData.email}
                onChange={handleChange}
              />
            </div>
          </div>

          {/* PASSWORD */}
          <div className="form-group">
            <label>Password</label>

            <div className="input-wrapper">
              <span>🔒</span>

              <input
                type="password"
                name="password"
                placeholder="Create a password"
                value={formData.password}
                onChange={handleChange}
              />
            </div>
          </div>

          {/* ACCOUNT TYPE */}
          <div className="form-group">
            <label>Account Type</label>

            <div className="input-wrapper">
              <span>🩺</span>

              <select
                name="role"
                value={formData.role}
                onChange={handleChange}
              >
                <option value="customer">Customer</option>
                <option value="pharmacist">Pharmacist</option>
              </select>
            </div>
          </div>

          {/* REGISTER BUTTON */}
          <button
            type="submit"
            className="register-button"
            disabled={loading}
          >
            {loading ? "Creating Account..." : "Create Account"}
          </button>

        </form>

        <div className="login-divider">
          <span>OR</span>
        </div>

        <Link to="/login" className="login-link">
          Already have an account? Login
        </Link>

      </div>

    </div>
  );
}

export default Register;