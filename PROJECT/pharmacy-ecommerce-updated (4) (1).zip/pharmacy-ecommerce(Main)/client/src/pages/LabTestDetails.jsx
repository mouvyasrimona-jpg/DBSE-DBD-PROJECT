import React, { useEffect, useState } from "react";
import { useParams, useNavigate, Link } from "react-router-dom";
import "./LabTestDetails.css";

const API_BASE = "http://localhost:5000/api/lab-tests";

function LabTestDetails() {
    const { id } = useParams();
    const navigate = useNavigate();
    const [test, setTest] = useState(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState("");

    useEffect(() => {
        setLoading(true);
        fetch(`${API_BASE}/${id}`)
            .then((r) => r.json())
            .then((d) => {
                if (d.success) setTest(d.test);
                else setError("Test not found");
            })
            .catch(() => setError("Failed to load test"))
            .finally(() => setLoading(false));
    }, [id]);

    if (loading) return <div className="labtest-details-loading">Loading...</div>;
    if (error || !test) return <div className="labtest-details-loading">{error || "Test not found"}</div>;

    const finalPrice = Math.round(test.price * (1 - (test.discountPercent || 0) / 100));

    return (
        <div className="labtest-details-page">

            <Link to="/lab-tests" className="labtest-back-link">← Back to Lab Tests</Link>

            <div className="labtest-details-grid">

                <div className="labtest-details-main">
                    <span className="labtest-card-category">{test.category}</span>
                    <h1>{test.name}</h1>

                    {test.description && <p className="labtest-details-desc">{test.description}</p>}

                    {test.parameters?.length > 0 && (
                        <div className="labtest-parameters">
                            <h3>Parameters Included</h3>
                            <ul>
                                {test.parameters.map((p, i) => <li key={i}>{p}</li>)}
                            </ul>
                        </div>
                    )}

                    <div className="labtest-info-row">
                        <div>
                            <strong>Sample Type</strong>
                            <span>{test.sampleType}</span>
                        </div>
                        <div>
                            <strong>Collection</strong>
                            <span>{test.homeCollection ? "Home & Center" : "Center Only"}</span>
                        </div>
                    </div>

                    {test.preparationInfo && (
                        <div className="labtest-prep-box">
                            <strong>Before your test</strong>
                            <p>{test.preparationInfo}</p>
                        </div>
                    )}
                </div>

                <div className="labtest-details-sidebar">
                    <div className="labtest-price-row">
                        <span className="labtest-final-price">₹{finalPrice}</span>
                        {test.discountPercent > 0 && (
                            <>
                                <span className="labtest-mrp">MRP ₹{test.mrp}</span>
                                <span className="labtest-discount">{test.discountPercent}% OFF</span>
                            </>
                        )}
                    </div>

                    <button className="labtest-book-btn" onClick={() => navigate(`/lab-tests/${test._id}/book`)}>
                        Book This Test →
                    </button>

                    <p className="labtest-sidebar-note">Sample collection scheduled at a time you choose.</p>
                </div>

            </div>

        </div>
    );
}

export default LabTestDetails;
