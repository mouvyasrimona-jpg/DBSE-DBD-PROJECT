import React, { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import "./Invoice.css";

function Invoice() {
    const { id } = useParams();
    const { token } = useAuth();
    const [invoice, setInvoice] = useState(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState("");

    useEffect(() => {
        const fetchInvoice = async () => {
            try {
                const res = await fetch(`http://localhost:5000/api/orders/${id}/invoice`, {
                    headers: { Authorization: `Bearer ${token}` }
                });
                const data = await res.json();
                if (data.success) {
                    setInvoice(data.invoice);
                } else {
                    setError(data.message || "Invoice not available");
                }
            } catch (err) {
                setError("Failed to load invoice");
            } finally {
                setLoading(false);
            }
        };
        if (token) fetchInvoice();
    }, [id, token]);

    if (loading) return <div className="invoice-loading">Loading invoice...</div>;
    if (error || !invoice) return <div className="invoice-loading">{error || "Invoice not found"}</div>;

    return (
        <div className="invoice-page">
            <div className="invoice-actions no-print">
                <Link to={`/orders/${id}`} className="invoice-back-link">← Back to Order</Link>
                <button className="invoice-print-btn" onClick={() => window.print()}>🖨️ Print / Save as PDF</button>
            </div>

            <div className="invoice-sheet">
                <div className="invoice-header">
                    <div>
                        <h1>PharmaCare</h1>
                        <p>Pharmacy E-Commerce Platform</p>
                    </div>
                    <div className="invoice-meta">
                        <p><strong>Invoice #:</strong> {invoice.invoiceNumber}</p>
                        <p><strong>Order ID:</strong> {invoice.orderId}</p>
                        <p><strong>Date:</strong> {new Date(invoice.orderDate).toLocaleDateString("en-IN", { day: "numeric", month: "long", year: "numeric" })}</p>
                    </div>
                </div>

                <div className="invoice-parties">
                    <div>
                        <h4>Billed To</h4>
                        <p>{invoice.customer.name}</p>
                        <p>{invoice.shippingAddress.addressLine}</p>
                        <p>{invoice.shippingAddress.city}, {invoice.shippingAddress.state} - {invoice.shippingAddress.pincode}</p>
                        <p>{invoice.shippingAddress.phone}</p>
                    </div>
                    {invoice.pharmacy && (
                        <div>
                            <h4>Fulfilled By</h4>
                            <p>{invoice.pharmacy.shopName}</p>
                            <p>{invoice.pharmacy.location}</p>
                        </div>
                    )}
                </div>

                <table className="invoice-table">
                    <thead>
                        <tr>
                            <th>Medicine</th>
                            <th>Qty</th>
                            <th>Price</th>
                            <th>Subtotal</th>
                        </tr>
                    </thead>
                    <tbody>
                        {invoice.items.map((item, idx) => (
                            <tr key={idx}>
                                <td>{item.name}</td>
                                <td>{item.quantity}</td>
                                <td>₹{item.price.toFixed(2)}</td>
                                <td>₹{item.subtotal.toFixed(2)}</td>
                            </tr>
                        ))}
                    </tbody>
                </table>

                <div className="invoice-totals">
                    <div className="invoice-total-row"><span>Subtotal</span><span>₹{invoice.subtotal.toFixed(2)}</span></div>
                    <div className="invoice-total-row"><span>Delivery Fee</span><span>₹{invoice.deliveryFee.toFixed(2)}</span></div>
                    {invoice.discount > 0 && (
                        <div className="invoice-total-row"><span>Discount</span><span>-₹{invoice.discount.toFixed(2)}</span></div>
                    )}
                    {invoice.taxAmount > 0 && (
                        <div className="invoice-total-row"><span>Tax</span><span>₹{invoice.taxAmount.toFixed(2)}</span></div>
                    )}
                    <div className="invoice-total-row grand"><span>Grand Total</span><span>₹{invoice.grandTotal.toFixed(2)}</span></div>
                </div>

                <div className="invoice-footer">
                    <p><strong>Payment Method:</strong> {invoice.paymentMethod} ({invoice.paymentStatus})</p>
                    <p><strong>Order Status:</strong> {invoice.orderStatus}</p>
                    <p className="invoice-thanks">Thank you for choosing PharmaCare.</p>
                </div>
            </div>
        </div>
    );
}

export default Invoice;
