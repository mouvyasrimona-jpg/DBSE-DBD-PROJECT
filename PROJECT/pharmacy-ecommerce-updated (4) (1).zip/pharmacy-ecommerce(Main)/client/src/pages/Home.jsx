import React, { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import MedicineCard from "../components/MedicineCard";
import "./Home.css";

const API_URL = "http://localhost:5000/api/medicines";

// A small lookup for friendlier icons on real category names —
// falls back to a generic icon for anything not in this list, so
// it never blocks a real category from displaying.
const CATEGORY_ICONS = {
    "Pain Relief": "💊",
    "Diabetes Care": "🩺",
    "Cardiac Care": "❤️",
    "Fever & Cold": "🤒",
    "Antibiotic": "🧫",
    "Skin Care": "🧴",
    "Vitamins": "🍊",
    "Digestive Health": "🍽️",
    "Respiratory Care": "🫁",
    "Baby Care": "👶",
    "Women's Health": "👩",
    "General": "🩹"
};

const whyFeatures = [
    { icon: "✅", title: "Verified Medicines", desc: "All medicines are sourced from licensed manufacturers and verified for authenticity." },
    { icon: "📄", title: "Prescription Validation", desc: "OCR-assisted prescription verification reviewed by licensed pharmacists." },
    { icon: "🔒", title: "Secure Platform", desc: "JWT-secured accounts with strict customer data isolation." },
    { icon: "🚚", title: "Real-Time Tracking", desc: "Live order status from placement to doorstep delivery." },
    { icon: "🔔", title: "Refill Reminders", desc: "Never miss a dose with smart medication refill reminders." }
];

const prescriptionFlow = [
    { icon: "📤", label: "Upload Prescription" },
    { icon: "🔍", label: "OCR Processing" },
    { icon: "💊", label: "Medicine Detection" },
    { icon: "✔️", label: "Validation" },
    { icon: "👨‍⚕️", label: "Pharmacist Review" },
    { icon: "🛒", label: "Order" }
];

const Home = () => {
    const navigate = useNavigate();
    const [categories, setCategories] = useState([]);
    const [featured, setFeatured] = useState([]);
    const [popular, setPopular] = useState([]);
    const [medicineCount, setMedicineCount] = useState(null);

    useEffect(() => {
        // Real category list from the database
        fetch(`${API_URL}/categories`)
            .then((r) => r.json())
            .then((d) => { if (d.success) setCategories(d.categories); })
            .catch(() => {});

        // Real featured medicines (in-stock, most recently added first)
        fetch(`${API_URL}`)
            .then((r) => r.json())
            .then((d) => {
                if (d.success) {
                    setMedicineCount(d.medicines.length);
                    const inStock = d.medicines.filter((m) => m.stock > 0);
                    setFeatured(inStock.slice(0, 8));
                } else {
                    setMedicineCount(0);
                }
            })
            .catch(() => setMedicineCount(0));

        // Real popularity — order-derived, or top-rated fallback
        fetch(`${API_URL}/popular`)
            .then((r) => r.json())
            .then((d) => { if (d.success) setPopular(d.medicines); })
            .catch(() => {});
    }, []);

    return (
        <div className="home-page">

            {/* ── HERO ── */}
            <section className="hero-section">
                <div className="hero-content">
                    <div className="trusted-badge">
                        ✦ Digital Pharmacy &amp; Prescription Verification Platform
                    </div>

                    <h1>
                        Your Health,<br />
                        <span>Our Priority.</span>
                    </h1>

                    <p>
                        Order medicines online with pharmacist-verified prescription uploads,
                        OCR text extraction, substitute suggestions, and real-time order tracking.
                    </p>

                    <ul className="hero-checklist">
                        <li>✓ Verified medicines</li>
                        <li>✓ Prescription validation</li>
                        <li>✓ Secure checkout</li>
                        <li>✓ Reliable delivery</li>
                    </ul>

                    <div className="hero-buttons">
                        <Link to="/medicines" className="primary-btn">Shop Medicines →</Link>
                        <Link to="/prescription" className="secondary-btn">Upload Prescription</Link>
                    </div>
                </div>

                <div className="hero-visual">
                    <div className="health-card">
                        <div className="health-card-top">
                            <span>PHARMACARE</span>
                            <span className="secure-badge">🔒 Secure</span>
                        </div>
                        <div className="medicine-visual">
                            <div className="capsule">💊</div>
                        </div>
                        <h2>Prescription Validation</h2>
                        <p>Safe medicines. Verified prescriptions.<br />Trusted platform.</p>
                    </div>
                </div>
            </section>

            {/* ── TRUST STRIP (real data + honest qualitative claims only) ── */}
            <div className="stats-bar">
                <div className="stat-item">
                    <div className="stat-number">{medicineCount !== null ? `${medicineCount}+` : "…"}</div>
                    <div className="stat-label">Medicines Available</div>
                </div>
                <div className="stat-item">
                    <div className="stat-number">Live</div>
                    <div className="stat-label">Order Tracking</div>
                </div>
                <div className="stat-item">
                    <div className="stat-number">Rx</div>
                    <div className="stat-label">Pharmacist Verified</div>
                </div>
                <div className="stat-item">
                    <div className="stat-number">JWT</div>
                    <div className="stat-label">Secure Accounts</div>
                </div>
            </div>

            {/* ── QUICK ACTIONS ── */}
            <section className="quick-actions">
                <Link to="/medicines" className="action-card">
                    <div className="action-icon">💊</div>
                    <div>
                        <h3>Buy Medicines</h3>
                        <p>Browse our full healthcare catalogue</p>
                    </div>
                    <span className="arrow">→</span>
                </Link>

                <Link to="/prescription" className="action-card">
                    <div className="action-icon">📄</div>
                    <div>
                        <h3>Upload Prescription</h3>
                        <p>OCR-assisted pharmacist verification</p>
                    </div>
                    <span className="arrow">→</span>
                </Link>

                <Link to="/lab-tests" className="action-card">
                    <div className="action-icon">🧪</div>
                    <div>
                        <h3>Book Lab Test</h3>
                        <p>Home collection or visit a nearby center</p>
                    </div>
                    <span className="arrow">→</span>
                </Link>

                <Link to="/orders" className="action-card">
                    <div className="action-icon">🚚</div>
                    <div>
                        <h3>Track Your Order</h3>
                        <p>Real-time delivery status updates</p>
                    </div>
                    <span className="arrow">→</span>
                </Link>

                <Link to="/refill-reminders" className="action-card">
                    <div className="action-icon">🔔</div>
                    <div>
                        <h3>Refill Reminders</h3>
                        <p>Never miss your medication dose</p>
                    </div>
                    <span className="arrow">→</span>
                </Link>
            </section>

            {/* ── SHOP BY CATEGORY (real DB categories) ── */}
            {categories.length > 0 && (
                <section className="category-scroll-section">
                    <div className="section-heading">
                        <div className="section-tag">BROWSE</div>
                        <h2>Shop by Category</h2>
                    </div>
                    <div className="category-scroll-row">
                        {categories.map((cat, i) => (
                            <div
                                className="category-scroll-card"
                                key={i}
                                onClick={() => navigate(`/medicines?category=${encodeURIComponent(cat)}`)}
                            >
                                <div className="category-scroll-icon">{CATEGORY_ICONS[cat] || "🩹"}</div>
                                <span>{cat}</span>
                            </div>
                        ))}
                    </div>
                </section>
            )}

            {/* ── FEATURED MEDICINES (real data) ── */}
            {featured.length > 0 && (
                <section className="product-carousel-section">
                    <div className="section-heading">
                        <div className="section-tag">FEATURED</div>
                        <h2>Featured Medicines</h2>
                    </div>
                    <div className="product-carousel-row">
                        {featured.map((m) => <MedicineCard medicine={m} key={m._id} />)}
                    </div>
                </section>
            )}

            {/* ── PROMOTIONAL BANNERS (original, CSS-only) ── */}
            <section className="promo-banner-row">
                <Link to="/prescription" className="promo-banner promo-teal">
                    <span className="promo-tag">SMART PRESCRIPTION</span>
                    <h3>Upload Prescription, Order Easily</h3>
                    <p>OCR extraction + pharmacist review →</p>
                </Link>
                <Link to="/orders" className="promo-banner promo-navy">
                    <span className="promo-tag">LIVE TRACKING</span>
                    <h3>Track Your Delivery in Real Time</h3>
                    <p>From pharmacy to your doorstep →</p>
                </Link>
                <Link to="/refill-reminders" className="promo-banner promo-amber">
                    <span className="promo-tag">NEVER MISS A DOSE</span>
                    <h3>Smart Refill Reminders</h3>
                    <p>Based on your own order history →</p>
                </Link>
            </section>

            {/* ── POPULAR MEDICINES (real, order-derived) ── */}
            {popular.length > 0 && (
                <section className="product-carousel-section">
                    <div className="section-heading">
                        <div className="section-tag">TRENDING</div>
                        <h2>Popular on PharmaCare</h2>
                    </div>
                    <div className="product-carousel-row">
                        {popular.map((m) => <MedicineCard medicine={m} key={m._id} />)}
                    </div>
                </section>
            )}

            {/* ── SMART PRESCRIPTION VERIFICATION FLOW ── */}
            <section className="prescription-flow-section">
                <div className="section-heading">
                    <div className="section-tag">OUR DIFFERENTIATOR</div>
                    <h2>Smart Prescription Verification</h2>
                    <p>Every prescription-required order goes through this exact process — no shortcuts.</p>
                </div>
                <div className="flow-steps-row">
                    {prescriptionFlow.map((step, i) => (
                        <React.Fragment key={i}>
                            <div className="flow-step">
                                <div className="flow-step-icon">{step.icon}</div>
                                <span>{step.label}</span>
                            </div>
                            {i < prescriptionFlow.length - 1 && <div className="flow-arrow">→</div>}
                        </React.Fragment>
                    ))}
                </div>
                <Link to="/prescription" className="cta-button" style={{ marginTop: 28 }}>Upload Prescription →</Link>
            </section>

            {/* ── WHY PHARMACARE ── */}
            <section className="why-section">
                <div className="section-heading">
                    <div className="section-tag">WHY CHOOSE US</div>
                    <h2>Why PharmaCare?</h2>
                    <p>A trusted digital pharmacy platform built for patients and healthcare professionals.</p>
                </div>
                <div className="why-grid">
                    {whyFeatures.map((f, i) => (
                        <div className="why-card" key={i}>
                            <div className="why-icon">{f.icon}</div>
                            <h3>{f.title}</h3>
                            <p>{f.desc}</p>
                        </div>
                    ))}
                </div>
            </section>

            {/* ── FINAL CTA ── */}
            <section className="home-cta" style={{ margin: "0 5% 70px" }}>
                <div>
                    <div className="section-tag" style={{ marginBottom: 10 }}>GET STARTED</div>
                    <h2>Start Your Healthcare Journey Today</h2>
                    <p>Register now, browse medicines, upload prescriptions, and place orders securely.</p>
                </div>
                <Link to="/medicines" className="cta-button">Shop Medicines →</Link>
            </section>

        </div>
    );
};

export default Home;
