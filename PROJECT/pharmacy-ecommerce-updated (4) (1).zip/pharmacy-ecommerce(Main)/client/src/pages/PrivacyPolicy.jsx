import React from "react";
import "./StaticPage.css";

function PrivacyPolicy() {
    return (
        <div className="static-page">
            <h1>Privacy Policy</h1>
            <p className="static-subtitle">Last updated: 2026</p>

            <h2>Information we collect</h2>
            <p>
                We collect the information you provide when creating an account (name, email),
                placing an order (shipping address, phone), and uploading a prescription (the
                file itself and any information our OCR system extracts from it).
            </p>

            <h2>How we use it</h2>
            <ul>
                <li>To process and deliver your orders</li>
                <li>To let a licensed pharmacist review prescriptions you upload</li>
                <li>To send order and prescription status notifications</li>
                <li>To secure your account via authentication</li>
            </ul>

            <h2>Prescription data</h2>
            <p>
                Prescription files and any medical information extracted from them are only
                accessible to you, the reviewing pharmacist, and platform administrators. They
                are never shared with third parties or used for advertising.
            </p>

            <h2>Data security</h2>
            <p>
                Passwords are hashed, never stored in plain text. Access to protected data is
                controlled through role-based authorization, enforced on our backend — not just
                hidden in the interface.
            </p>

            <h2>Your choices</h2>
            <p>
                You can review, update, or request deletion of your account information at any
                time by contacting support.
            </p>
        </div>
    );
}

export default PrivacyPolicy;
