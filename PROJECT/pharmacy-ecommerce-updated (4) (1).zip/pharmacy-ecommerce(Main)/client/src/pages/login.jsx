import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import "./login.css";

function Login() {
  const navigate = useNavigate();
  const { login } = useAuth();

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const handleLogin = async (e) => {
    e.preventDefault();

    setError("");
    setLoading(true);

    try {
      const response = await fetch(
        "http://localhost:5000/api/auth/login",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            email,
            password,
          }),
        }
      );

      const data = await response.json();

      if (!response.ok || !data.success) {
        setError(data.message || "Login failed");
        setLoading(false);
        return;
      }

      // =====================================
      // UPDATE AUTHENTICATION CONTEXT
      // =====================================

      login(data.token, data.user);

      console.log("JWT Token Stored Successfully");
      console.log("Token:", data.token);
      console.log("User:", data.user);

      // Go to home page
      navigate("/");

    } catch (error) {
      console.error("Login Error:", error);
      setError("Unable to connect to server");
    }

    setLoading(false);
  };

  return (
    <div className="login-page">

      <div className="login-background">
        <div className="login-shape shape-one"></div>
        <div className="login-shape shape-two"></div>
        <div className="login-shape shape-three"></div>
      </div>

      <div className="login-container">

        {/* LEFT SIDE */}

        <div className="login-info">

          <div className="brand-logo">
            💊
          </div>

          <h1>
            Welcome
            <span>Back PharmaCare</span>
          </h1>

          <p>
            Login to your pharmacy account and manage
            medicines, prescriptions and orders easily.
          </p>

          <div className="login-features">

            <div className="feature">
              <span>🔐</span>

              <div>
                <strong>Secure Login</strong>
                <small>Your account is protected</small>
              </div>
            </div>

            <div className="feature">
              <span>💊</span>

              <div>
                <strong>Easy Medicine Access</strong>
                <small>Find your medicines quickly</small>
              </div>
            </div>

            <div className="feature">
              <span>🚚</span>

              <div>
                <strong>Track Orders</strong>
                <small>Monitor your medicine orders</small>
              </div>
            </div>

          </div>

        </div>

        {/* LOGIN CARD */}

        <div className="login-card">

          <div className="login-header">

            <div className="login-icon">
              🔑
            </div>

            <h2>Login</h2>

            <p>
              Sign in to continue to your account
            </p>

          </div>

          {error && (
            <div className="login-error">
              {error}
            </div>
          )}

          <form onSubmit={handleLogin}>

            {/* EMAIL */}

            <div className="form-group">

              <label>Email</label>

              <div className="input-wrapper">

                <span>📧</span>

                <input
                  type="email"
                  placeholder="Enter your email"
                  value={email}
                  onChange={(e) =>
                    setEmail(e.target.value)
                  }
                  required
                />

              </div>

            </div>

            {/* PASSWORD */}

            <div className="form-group">

              <label>Password</label>

              <div className="input-wrapper">

                <span>🔒</span>

                <input
                  type="password"
                  placeholder="Enter your password"
                  value={password}
                  onChange={(e) =>
                    setPassword(e.target.value)
                  }
                  required
                />

              </div>

            </div>

            {/* LOGIN BUTTON */}

            <button
              type="submit"
              className="login-button"
              disabled={loading}
            >
              {loading ? "Logging in..." : "Login"}
            </button>

          </form>

          <div className="login-divider">
            OR
          </div>

          <Link
            to="/register"
            className="register-link"
          >
            Create New Account
          </Link>

          <p className="security-note">
            🔒 Your credentials are securely protected
          </p>

        </div>

      </div>

    </div>
  );
}

export default Login;