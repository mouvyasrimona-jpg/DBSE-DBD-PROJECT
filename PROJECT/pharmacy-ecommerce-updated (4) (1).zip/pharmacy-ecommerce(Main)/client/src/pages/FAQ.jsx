import React from "react";
import { Link } from "react-router-dom";
import "./StaticPage.css";

const faqs = [
    { q: "How do I upload a prescription?", a: "Go to the Prescription page from the navbar, click Upload, and choose a clear photo or PDF. Our system scans it automatically." },
    { q: "How long does prescription approval take?", a: "A licensed pharmacist reviews every upload manually — most are reviewed within a short time, and you'll get a notification the moment it's Approved or Rejected." },
    { q: "Can I order a prescription medicine before it's approved?", a: "No. Checkout is blocked for any prescription-required medicine until you have a specifically matching approved prescription." },
    { q: "How do I track my order?", a: "Open My Orders and click any order to see its live status and tracking map once it's out for delivery." },
    { q: "What is the delivery OTP for?", a: "Once your order is out for delivery, you'll receive a one-time code. Share it with the delivery partner only when they arrive, to confirm the handover." },
    { q: "Can I reorder a previous purchase?", a: "Yes — open My Orders and click Reorder on any past order. We check current stock and prices before adding items to your cart." },
    { q: "How does pharmacy comparison work?", a: "On a medicine's details page, scroll to 'Available at Nearby Pharmacies' to compare price, discount and delivery time across pharmacies." }
];

function FAQ() {
    return (
        <div className="static-page">
            <h1>Frequently Asked Questions</h1>
            <p className="static-subtitle">Common questions about using PharmaCare.</p>

            {faqs.map((item, i) => (
                <div className="faq-item" key={i}>
                    <strong>{item.q}</strong>
                    <p>{item.a}</p>
                </div>
            ))}

            <div className="contact-box">
                <strong>Still have a question?</strong>
                <p>Use the support chat in the bottom-right corner, or visit the <Link to="/about">About page</Link>.</p>
            </div>
        </div>
    );
}

export default FAQ;
