import React, { useEffect, useState } from "react";
import { useParams, Link, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import "./MedicineDetails.css";

const API_URL = "http://localhost:5000/api/medicines";
const API_RX = "http://localhost:5000/api/prescriptions";

function MedicineDetails() {
    const { id } = useParams();
    const navigate = useNavigate();

    const { token, isAuthenticated } = useAuth();

    const [medicine, setMedicine] = useState(null);
    const [substitutes, setSubstitutes] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState("");
    const [toast, setToast] = useState("");

    // Prescription states
    const [checkingPrescription, setCheckingPrescription] = useState(false);
    const [showPrescriptionModal, setShowPrescriptionModal] = useState(false);
    const [selectedShop, setSelectedShop] = useState(null);
    const [shopError, setShopError] = useState("");


    // =====================================================
    // FETCH MEDICINE
    // =====================================================

    useEffect(() => {

        const fetchMedicine = async () => {

            try {

                setLoading(true);
                setError("");

                const res =
                    await fetch(`${API_URL}/${id}`);

                if (!res.ok) {
                    throw new Error("Medicine not found");
                }

                const data = await res.json();

                if (data && data.success) {
                    setMedicine(data.medicine);

                    // Default to the first available pharmacy so a
                    // customer who doesn't care can still add to cart
                    // immediately; they can still change it.
                    if (data.medicine.availableShops?.length > 0) {
                        setSelectedShop(data.medicine.availableShops[0]);
                    } else {
                        setSelectedShop(null);
                    }
                    setShopError("");

                    // Fetch substitutes in parallel
                    try {
                        const subRes = await fetch(`${API_URL}/${id}/substitutes`);
                        if (subRes.ok) {
                            const subData = await subRes.json();
                            if (subData.success) {
                                setSubstitutes(subData.substitutes || []);
                            }
                        }
                    } catch (subErr) {
                        console.error("Substitutes fetch error:", subErr);
                    }
                } else {
                    setError(
                        "Medicine details not available."
                    );
                }

            } catch (err) {

                console.error(
                    "Fetch medicine error:",
                    err
                );

                setError(
                    err.message ||
                    "Failed to load medicine details."
                );

            } finally {

                setLoading(false);

            }

        };

        fetchMedicine();

    }, [id]);


    // =====================================================
    // CHECK WHETHER MEDICINE EXISTS IN APPROVED PRESCRIPTION
    // =====================================================

    const checkPrescription = async () => {

        try {

            setCheckingPrescription(true);

            const res = await fetch(
                `${API_RX}/my-prescriptions`,
                {
                    headers: {
                        Authorization:
                            `Bearer ${token}`
                    }
                }
            );

            const data = await res.json();

            if (!res.ok || !data.success) {

                throw new Error(
                    data.message ||
                    "Unable to check prescription"
                );

            }


            const approvedPrescriptions =
                (data.prescriptions || [])
                    .filter(
                        (p) =>
                            p.status === "Approved"
                    );


            // No approved prescription at all
            if (
                approvedPrescriptions.length === 0
            ) {

                return false;

            }


            // Medicine names from database
            const medicineNames = [
                medicine.name,
                medicine.genericName
            ]
                .filter(Boolean)
                .map(
                    (name) =>
                        name
                            .toLowerCase()
                            .trim()
                );


            // Search ALL approved prescriptions
            const medicineFound =
                approvedPrescriptions.some(
                    (prescription) => {

                        if (
                            !prescription
                                .detectedMedicines ||
                            !Array.isArray(
                                prescription.detectedMedicines
                            )
                        ) {
                            return false;
                        }


                        return prescription
                            .detectedMedicines
                            .some(
                                (detected) => {

                                    if (!detected) {
                                        return false;
                                    }

                                    const detectedText =
                                        String(
                                            detected
                                        )
                                            .toLowerCase()
                                            .trim();


                                    return medicineNames.some(
                                        (name) =>
                                            detectedText.includes(
                                                name
                                            ) ||
                                            name.includes(
                                                detectedText
                                            )
                                    );

                                }
                            );

                    }
                );


            return medicineFound;

        } catch (err) {

            console.error(
                "Prescription check error:",
                err
            );

            return false;

        } finally {

            setCheckingPrescription(false);

        }

    };


    // =====================================================
    // ADD TO CART
    // =====================================================

    const handleAddToCart = async () => {

        if (!medicine || medicine.stock <= 0) {
            return;
        }

        // -------------------------------------------------
        // PHARMACY SELECTION CHECK
        // -------------------------------------------------

        if (medicine.availableShops?.length > 0 && !selectedShop) {
            setShopError("Please select a pharmacy before adding to cart.");
            return;
        }
        setShopError("");


        // -------------------------------------------------
        // LOGIN CHECK
        // -------------------------------------------------

        if (!isAuthenticated || !token) {

            navigate("/login", {
                state: {
                    from:
                        `/medicines/${medicine._id}`
                }
            });

            return;

        }


        // -------------------------------------------------
        // PRESCRIPTION CHECK
        // -------------------------------------------------

        if (medicine.prescriptionRequired) {

            const hasValidPrescription =
                await checkPrescription();


            if (!hasValidPrescription) {

                setShowPrescriptionModal(true);

                return;

            }

        }


        // -------------------------------------------------
        // EXISTING CART
        // -------------------------------------------------

        let currentCart = [];

        const storedCart =
            localStorage.getItem("cart");


        if (storedCart) {

            try {

                currentCart =
                    JSON.parse(storedCart);

            } catch (e) {

                currentCart = [];

            }

        }


        // -------------------------------------------------
        // CHECK EXISTING ITEM
        // -------------------------------------------------

        const existingIndex =
            currentCart.findIndex(
                (item) =>
                    item._id === medicine._id
            );


        if (existingIndex > -1) {

            if (
                currentCart[existingIndex]
                    .cartQuantity <
                medicine.stock
            ) {

                currentCart[
                    existingIndex
                ].cartQuantity += 1;

            } else {

                setToast(
                    `Maximum stock limit (${medicine.stock}) reached.`
                );

                setTimeout(
                    () => setToast(""),
                    3000
                );

                return;

            }

        } else {

            currentCart.push({

                _id:
                    medicine._id,

                name:
                    medicine.name,

                price:
                    medicine.price,

                stock:
                    medicine.stock,

                image:
                    medicine.image || "",

                category:
                    medicine.category || "",

                genericName:
                    medicine.genericName || "",

                // IMPORTANT
                prescriptionRequired:
                    !!medicine.prescriptionRequired,

                selectedPharmacy:
                    selectedShop || null,

                cartQuantity:
                    1

            });

        }


        // -------------------------------------------------
        // SAVE CART
        // -------------------------------------------------

        localStorage.setItem(
            "cart",
            JSON.stringify(currentCart)
        );

        window.dispatchEvent(
            new Event("cartUpdated")
        );


        setToast(
            `🛒 ${medicine.name} added to cart!`
        );

        setTimeout(
            () => setToast(""),
            3000
        );

    };


    // =====================================================
    // BUY NOW
    // =====================================================

    const handleBuyNow = async () => {

        if (!medicine || medicine.stock <= 0) {
            return;
        }

        await handleAddToCart();

    };


    // =====================================================
    // LOADING
    // =====================================================

    if (loading) {

        return (

            <div className="medicine-details-page">

                <div className="details-message">

                    <div className="loader"></div>

                    <p>
                        Loading medicine details...
                    </p>

                </div>

            </div>

        );

    }


    // =====================================================
    // ERROR
    // =====================================================

    if (error || !medicine) {

        return (

            <div className="medicine-details-page">

                <div className="details-error-card">

                    <div className="error-icon">
                        🔍
                    </div>

                    <h2>
                        Medicine Not Found
                    </h2>

                    <p>
                        {error ||
                            "The requested medicine is not available."}
                    </p>

                    <Link
                        to="/medicines"
                        className="back-btn"
                    >
                        ← Back to Medicines
                    </Link>

                </div>

            </div>

        );

    }


    // =====================================================
    // PAGE
    // =====================================================

    return (

        <div className="medicine-details-page">

            <div className="details-container">

                <Link
                    to="/medicines"
                    className="back-btn"
                >
                    ← Back to All Medicines
                </Link>


                <div className="medicine-main-grid">

                    {/* IMAGE */}

                    <div className="details-image-box">

                        {medicine.image ? (

                            <img
                                src={medicine.image}
                                alt={medicine.name}
                            />

                        ) : (

                            <span className="fallback-icon">
                                💊
                            </span>

                        )}


                        {medicine.prescriptionRequired && (

                            <span className="rx-badge">
                                📄 Prescription Required
                            </span>

                        )}

                    </div>


                    {/* INFO */}

                    <div className="details-content-box">

                        <span className="details-category">
                            {medicine.category ||
                                "General"}
                        </span>


                        <h1>
                            {medicine.name}
                        </h1>


                        <p className="generic-title">
                            {medicine.genericName}
                        </p>


                        <div className="details-meta-row">

                            <span className="meta-badge">
                                Brand:
                                <strong>
                                    {medicine.brand ||
                                        "PharmaCare"}
                                </strong>
                            </span>


                            <span className="meta-badge">
                                Form:
                                <strong>
                                    {medicine.form ||
                                        "Tablet"}
                                </strong>
                            </span>


                            <span className="meta-badge">
                                Dosage:
                                <strong>
                                    {medicine.dosage ||
                                        "N/A"}
                                </strong>
                            </span>

                        </div>


                        <div className="details-condition">

                            Recommended for:
                            <strong>
                                {medicine.condition ||
                                    "General Healthcare"}
                            </strong>

                        </div>


                        <div className="details-price-row">

                            <div>

                                <span className="price-tag">
                                    ₹
                                    {Number(
                                        medicine.price
                                    ).toFixed(2)}
                                </span>


                                <span className="rating-tag">
                                    ⭐
                                    {medicine.rating ||
                                        "4.5"}
                                </span>

                            </div>


                            <span
                                className={`stock-tag ${
                                    medicine.stock > 0
                                        ? "in-stock"
                                        : "out-stock"
                                }`}
                            >

                                {medicine.stock > 0
                                    ? `In Stock (${medicine.stock} units)`
                                    : "Out of Stock"}

                            </span>

                        </div>


                        {/* AVAILABLE PHARMACIES */}

                        {medicine.availableShops?.length > 0 && (

                            <div className="pharmacy-availability-section">

                                <h3>Available at Nearby Pharmacies</h3>

                                <div className="pharmacy-shop-list">

                                    {[...medicine.availableShops]
                                        .sort((a, b) => {
                                            const priceA = a.price != null ? a.price * (1 - (a.discountPercent || 0) / 100) : medicine.price;
                                            const priceB = b.price != null ? b.price * (1 - (b.discountPercent || 0) / 100) : medicine.price;
                                            return priceA - priceB;
                                        })
                                        .map((shop, idx) => {
                                        const isSelected =
                                            selectedShop?.shopName === shop.shopName;

                                        const effectivePrice = shop.price != null ? shop.price : medicine.price;
                                        const discountedPrice = effectivePrice * (1 - (shop.discountPercent || 0) / 100);

                                        return (
                                            <div
                                                key={idx}
                                                className={`pharmacy-shop-card ${isSelected ? "selected" : ""}`}
                                            >
                                                <div className="pharmacy-shop-icon">🏥</div>

                                                <div className="pharmacy-shop-info">
                                                    <div className="pharmacy-shop-name-row">
                                                        <strong>{shop.shopName}</strong>
                                                        {idx === 0 && <span className="best-price-badge">Best Price</span>}
                                                    </div>
                                                    <p className="pharmacy-shop-address">
                                                        {shop.location}
                                                    </p>

                                                    <div className="pharmacy-price-row">
                                                        <span className="pharmacy-price">₹{discountedPrice.toFixed(2)}</span>
                                                        {shop.discountPercent > 0 && (
                                                            <>
                                                                <span className="pharmacy-price-original">₹{effectivePrice.toFixed(2)}</span>
                                                                <span className="pharmacy-discount-tag">{shop.discountPercent}% off</span>
                                                            </>
                                                        )}
                                                    </div>

                                                    <div className="pharmacy-shop-meta">
                                                        <span>📍 {shop.distance}</span>
                                                        <span>
                                                            {shop.stock > 0
                                                                ? "✅ In Stock"
                                                                : "❌ Out of Stock"}
                                                        </span>
                                                        <span>🚚 {shop.deliveryTime}</span>
                                                        <span>⭐ {shop.rating}</span>
                                                    </div>

                                                    <p className="pharmacy-shop-hours">
                                                        🕐 {shop.openHours}
                                                    </p>
                                                </div>

                                                <button
                                                    type="button"
                                                    className={`select-pharmacy-btn ${isSelected ? "selected" : ""}`}
                                                    onClick={() => {
                                                        setSelectedShop(shop);
                                                        setShopError("");
                                                    }}
                                                >
                                                    {isSelected ? "✓ Selected" : "Select Pharmacy"}
                                                </button>
                                            </div>
                                        );
                                    })}

                                </div>

                                {shopError && (
                                    <p className="pharmacy-select-error">{shopError}</p>
                                )}

                            </div>
                        )}


                        <div className="details-description">

                            <h3>
                                Description & Usage Instructions
                            </h3>

                            <p>

                                {medicine.description ||
                                    `${medicine.name} is a high-quality pharmaceutical formulation suitable for managing ${medicine.condition}. Please follow dosage recommendations provided by your physician.`}

                            </p>

                        </div>


                        {/* PRESCRIPTION WARNING */}

                        {medicine.prescriptionRequired && (

                            <div className="prescription-warning-box">

                                ⚠️

                                <strong>
                                    Prescription Needed:
                                </strong>

                                {" "}
                                This medicine requires an
                                approved doctor's prescription
                                before it can be purchased.

                            </div>

                        )}


                        {/* ACTIONS */}

                        <div className="details-actions">

                            <button
                                className="add-cart-large-btn"
                                onClick={
                                    handleAddToCart
                                }
                                disabled={
                                    medicine.stock <= 0 ||
                                    checkingPrescription
                                }
                            >

                                {checkingPrescription
                                    ? "Checking Prescription..."
                                    : medicine.stock > 0
                                        ? "Add to Cart 🛒"
                                        : "Out of Stock"}

                            </button>


                            <button
                                className="buy-now-btn"
                                onClick={
                                    handleBuyNow
                                }
                                disabled={
                                    medicine.stock <= 0 ||
                                    checkingPrescription
                                }
                            >

                                🛍️ Buy Now

                            </button>

                        </div>

                    </div>

                </div>


                {/* =====================================================
                    SUBSTITUTE MEDICINE RECOMMENDATIONS
                ===================================================== */}
                {substitutes && substitutes.length > 0 && (
                    <div className="substitutes-section">
                        <div className="substitutes-header">
                            <div>
                                <span className="substitutes-badge">💡 Smart Alternative Suggestions</span>
                                <h2>Substitute Medicines with Same Purpose</h2>
                                <p>Formulations in <strong>{medicine.therapeuticCategory || medicine.category}</strong> with equivalent therapeutic effect.</p>
                            </div>
                        </div>

                        <div className="substitutes-grid">
                            {substitutes.map(sub => (
                                <div key={sub._id} className="substitute-card">
                                    <div className="sub-img-box">
                                        {sub.image ? <img src={sub.image} alt={sub.name} /> : "💊"}
                                    </div>
                                    <div className="sub-info">
                                        <span className="sub-cat">{sub.category}</span>
                                        <h4>{sub.name}</h4>
                                        <p className="sub-generic">{sub.genericName}</p>
                                        <div className="sub-price-row">
                                            <span className="sub-price">₹{Number(sub.price).toFixed(2)}</span>
                                            {sub.price < medicine.price && (
                                                <span className="sub-savings">Save ₹{(medicine.price - sub.price).toFixed(2)}</span>
                                            )}
                                        </div>
                                    </div>
                                    <Link to={`/medicines/${sub._id}`} className="view-sub-btn">
                                        View Alternative →
                                    </Link>
                                </div>
                            ))}
                        </div>
                    </div>
                )}

            </div>


            {/* =====================================================
                PRESCRIPTION MODAL
            ===================================================== */}

            {showPrescriptionModal && (

                <div className="rx-modal-overlay">

                    <div className="rx-modal">

                        <div className="rx-modal-icon">
                            📄
                        </div>

                        <h2>
                            Prescription Required
                        </h2>

                        <p>

                            <strong>
                                {medicine.name}
                            </strong>

                            {" "}
                            requires an approved prescription.

                        </p>

                        <p className="rx-modal-small">

                            Upload your prescription and
                            wait for pharmacist/admin approval
                            before adding this medicine to cart.

                        </p>


                        <div className="rx-modal-actions">

                            <button
                                className="rx-upload-btn"
                                onClick={() =>
                                    navigate(
                                        "/prescription"
                                    )
                                }
                            >
                                📤 Upload Prescription
                            </button>


                            <button
                                className="rx-cancel-btn"
                                onClick={() =>
                                    setShowPrescriptionModal(
                                        false
                                    )
                                }
                            >
                                Cancel
                            </button>

                        </div>

                    </div>

                </div>

            )}


            {/* TOAST */}

            {toast && (

                <div className="cart-toast">
                    {toast}
                </div>

            )}

        </div>

    );

}

export default MedicineDetails;