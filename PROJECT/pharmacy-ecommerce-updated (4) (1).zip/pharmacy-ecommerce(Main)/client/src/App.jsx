﻿import { BrowserRouter, Routes, Route } from "react-router-dom";

import Navbar from "./components/Navbar";
import TopSearchBar from "./components/TopSearchBar";
import ProtectedRoute from "./routes/ProtectedRoute";
import RoleBasedRoute from "./routes/RoleBasedRoute";

import Home from "./pages/Home";
import Login from "./pages/login";
import Register from "./pages/Register";
import Medicines from "./pages/Medicines";
import MedicineDetails from "./pages/MedicineDetails";
import Cart from "./pages/Cart";
import Prescription from "./pages/Prescription";
import MyOrders from "./pages/MyOrders";
import OrderDetails from "./pages/OrderDetails";
import AdminDashboard from "./pages/AdminDashboard";
import PharmacistDashboard from "./pages/PharmacistDashboard";
import DeliveryDashboard from "./pages/DeliveryDashboard";
import LabTests from "./pages/LabTests";
import LabTestDetails from "./pages/LabTestDetails";
import LabTestBooking from "./pages/LabTestBooking";
import MyLabBookings from "./pages/MyLabBookings";
import LabBookingDetails from "./pages/LabBookingDetails";
import CustomerDashboard from "./pages/CustomerDashboard";
import RefillReminders from "./pages/RefillReminders";
import About from "./pages/About";
import PrivacyPolicy from "./pages/PrivacyPolicy";
import TermsAndConditions from "./pages/TermsAndConditions";
import FAQ from "./pages/FAQ";
import Footer from "./components/Footer";
import OrderTracking from "./pages/OrderTracking";
import Invoice from "./pages/Invoice";
import SupportAssistant from "./components/SupportAssistant";


function App() {
    return (
        <BrowserRouter>

            <Navbar />
            <TopSearchBar />

            <Routes>

                {/* =========================
                    PUBLIC ROUTES
                ========================= */}

                <Route
                    path="/"
                    element={<Home />}
                />

                <Route
                    path="/login"
                    element={<Login />}
                />

                <Route
                    path="/register"
                    element={<Register />}
                />

                <Route
                    path="/about"
                    element={<About />}
                />

                <Route
                    path="/privacy-policy"
                    element={<PrivacyPolicy />}
                />

                <Route
                    path="/terms"
                    element={<TermsAndConditions />}
                />

                <Route
                    path="/faq"
                    element={<FAQ />}
                />

                <Route
                    path="/cart"
                    element={<Cart />}
                />

                <Route
                    path="/lab-tests"
                    element={<LabTests />}
                />

                <Route
                    path="/lab-tests/:id"
                    element={<LabTestDetails />}
                />


                {/* =========================
                    PROTECTED ROUTES
                ========================= */}

                <Route element={<ProtectedRoute />}>

                    <Route
                        path="/lab-tests/:id/book"
                        element={<LabTestBooking />}
                    />

                    <Route
                        path="/lab-bookings"
                        element={<MyLabBookings />}
                    />

                    <Route
                        path="/lab-bookings/:id"
                        element={<LabBookingDetails />}
                    />

                    <Route
                        path="/dashboard"
                        element={<CustomerDashboard />}
                    />

                    <Route
                        path="/medicines"
                        element={<Medicines />}
                    />

                    <Route
                        path="/medicines/:id"
                        element={<MedicineDetails />}
                    />

                    <Route
                        path="/orders"
                        element={<MyOrders />}
                    />

                    <Route
                        path="/orders/:id"
                        element={<OrderDetails />}
                    />

                    <Route
                        path="/orders/:id/tracking"
                        element={<OrderTracking />}
                    />

                    <Route
                        path="/orders/:id/invoice"
                        element={<Invoice />}
                    />

                    <Route
                        path="/prescription"
                        element={<Prescription />}
                    />

                    <Route
                        path="/refill-reminders"
                        element={<RefillReminders />}
                    />

                    <Route
                        path="/admin"
                        element={
                            <RoleBasedRoute allowedRoles={["admin", "pharmacist"]}>
                                <AdminDashboard />
                            </RoleBasedRoute>
                        }
                    />

                    <Route
                        path="/pharmacist"
                        element={
                            <RoleBasedRoute allowedRoles={["pharmacist", "admin"]}>
                                <PharmacistDashboard />
                            </RoleBasedRoute>
                        }
                    />

                    <Route
                        path="/delivery"
                        element={
                            <RoleBasedRoute allowedRoles={["delivery"]}>
                                <DeliveryDashboard />
                            </RoleBasedRoute>
                        }
                    />

                </Route>

            </Routes>

            <Footer />

            <SupportAssistant />

        </BrowserRouter>
    );
}

export default App;
