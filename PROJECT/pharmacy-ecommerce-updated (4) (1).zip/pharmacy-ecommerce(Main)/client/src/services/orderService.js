const API_URL = "http://localhost:5000/api/orders";

// Create new order
export const createOrder = async (orderData, token) => {
    const response = await fetch(`${API_URL}`, {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`
        },
        body: JSON.stringify(orderData)
    });

    const data = await response.json();

    if (!response.ok) {
        throw new Error(data.message || "Failed to create order");
    }

    return data;
};


// Get logged-in user's orders
export const getMyOrders = async (token) => {
    const response = await fetch(`${API_URL}/my-orders`, {
        method: "GET",
        headers: {
            Authorization: `Bearer ${token}`
        }
    });

    const data = await response.json();

    if (!response.ok) {
        throw new Error(data.message || "Failed to fetch orders");
    }

    return data;
};


// Get single order
export const getOrderById = async (orderId, token) => {
    const response = await fetch(`${API_URL}/${orderId}`, {
        method: "GET",
        headers: {
            Authorization: `Bearer ${token}`
        }
    });

    const data = await response.json();

    if (!response.ok) {
        throw new Error(data.message || "Failed to fetch order");
    }

    return data;
};


// Get live map tracking data for a single order
export const getOrderTracking = async (orderId, token) => {
    const response = await fetch(`${API_URL}/${orderId}/tracking`, {
        method: "GET",
        headers: {
            Authorization: `Bearer ${token}`
        }
    });

    const data = await response.json();

    if (!response.ok) {
        throw new Error(data.message || "Failed to fetch order tracking");
    }

    return data;
};