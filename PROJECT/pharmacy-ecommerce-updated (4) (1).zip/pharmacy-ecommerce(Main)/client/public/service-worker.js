// PharmaCare service worker — deliberately conservative.
// It ONLY caches the static app shell so the app can install and
// open offline. It NEVER caches /api/ responses — medicine stock,
// prices, order status and prescription status must always be
// fetched fresh, never served stale from cache.

const CACHE_NAME = "pharmacare-shell-v1";
const SHELL_ASSETS = ["/", "/manifest.json", "/favicon.svg"];

self.addEventListener("install", (event) => {
    event.waitUntil(
        caches.open(CACHE_NAME).then((cache) => cache.addAll(SHELL_ASSETS))
    );
    self.skipWaiting();
});

self.addEventListener("activate", (event) => {
    event.waitUntil(
        caches.keys().then((keys) =>
            Promise.all(keys.filter((k) => k !== CACHE_NAME).map((k) => caches.delete(k)))
        )
    );
    self.clients.claim();
});

self.addEventListener("fetch", (event) => {
    const url = new URL(event.request.url);

    // Never intercept API calls — always go to the network so data
    // is always current.
    if (url.pathname.startsWith("/api/") || url.pathname.startsWith("/uploads/")) {
        return;
    }

    // Network-first for everything else, falling back to cache only
    // when genuinely offline.
    event.respondWith(
        fetch(event.request)
            .then((response) => {
                const clone = response.clone();
                caches.open(CACHE_NAME).then((cache) => cache.put(event.request, clone));
                return response;
            })
            .catch(() => caches.match(event.request))
    );
});
