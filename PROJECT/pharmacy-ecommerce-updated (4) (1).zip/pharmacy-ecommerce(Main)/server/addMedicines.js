import dotenv from "dotenv";
import mongoose from "mongoose";
import dns from "node:dns";
import connectDB from "./config/db.js";
import Medicine from "./models/Medicine.js";

dns.setServers(["8.8.8.8", "1.1.1.1"]);


dotenv.config();

const medicines = [
    // =====================================================
    // PRESCRIPTION REQUIRED MEDICINES
    // =====================================================

    {
        name: "Atorvastatin 10mg Tablet",
        genericName: "Atorvastatin",
        brand: "Atorva",
        condition: "High Cholesterol",
        category: "Statin",
        therapeuticCategory: "Cholesterol Management",
        dosage: "10mg",
        form: "Tablet",
        price: 95,
        stock: 100,
        prescriptionRequired: true,
        manufacturer: "Sun Pharma",
        rating: 4.6,
        image: "https://images.unsplash.com/photo-1584308666744-24d5c474f2ae",
        description:
            "Prescription medicine used to help lower cholesterol and reduce cardiovascular risk."
    },

    {
        name: "Rosuvastatin 10mg Tablet",
        genericName: "Rosuvastatin",
        brand: "Rosuvas",
        condition: "High Cholesterol",
        category: "Statin",
        therapeuticCategory: "Cholesterol Management",
        dosage: "10mg",
        form: "Tablet",
        price: 125,
        stock: 100,
        prescriptionRequired: true,
        manufacturer: "AstraZeneca",
        rating: 4.7,
        image: "https://images.unsplash.com/photo-1471864190281-a93a3070b6de",
        description:
            "Prescription statin medicine used to manage high cholesterol."
    },

    {
        name: "Amlodipine 5mg Tablet",
        genericName: "Amlodipine",
        brand: "Amlong",
        condition: "High Blood Pressure",
        category: "Antihypertensive",
        therapeuticCategory: "Blood Pressure",
        dosage: "5mg",
        form: "Tablet",
        price: 35,
        stock: 150,
        prescriptionRequired: true,
        manufacturer: "Micro Labs",
        rating: 4.5,
        image: "https://images.unsplash.com/photo-1550572017-edd951aa8ca9",
        description:
            "Prescription medicine used to control high blood pressure."
    },

    {
        name: "Lisinopril 10mg Tablet",
        genericName: "Lisinopril",
        brand: "Listril",
        condition: "High Blood Pressure",
        category: "Antihypertensive",
        therapeuticCategory: "Blood Pressure",
        dosage: "10mg",
        form: "Tablet",
        price: 60,
        stock: 100,
        prescriptionRequired: true,
        manufacturer: "Lupin",
        rating: 4.5,
        image: "https://images.unsplash.com/photo-1584308666744-24d5c474f2ae",
        description:
            "Prescription ACE inhibitor used for blood pressure management."
    },

    {
        name: "Levothyroxine 50mcg Tablet",
        genericName: "Levothyroxine",
        brand: "Thyronorm",
        condition: "Hypothyroidism",
        category: "Thyroid Hormone",
        therapeuticCategory: "Thyroid",
        dosage: "50mcg",
        form: "Tablet",
        price: 115,
        stock: 120,
        prescriptionRequired: true,
        manufacturer: "Abbott",
        rating: 4.8,
        image: "https://images.unsplash.com/photo-1585435557343-3b092031a831",
        description:
            "Prescription thyroid hormone replacement medicine."
    },

    {
        name: "Metformin 500mg Tablet",
        genericName: "Metformin",
        brand: "Glycomet",
        condition: "Type 2 Diabetes",
        category: "Antidiabetic",
        therapeuticCategory: "Diabetes",
        dosage: "500mg",
        form: "Tablet",
        price: 30,
        stock: 200,
        prescriptionRequired: true,
        manufacturer: "USV",
        rating: 4.7,
        image: "https://images.unsplash.com/photo-1471864190281-a93a3070b6de",
        description:
            "Prescription medicine commonly used to help control blood glucose in Type 2 diabetes."
    },

    {
        name: "Omeprazole 20mg Capsule",
        genericName: "Omeprazole",
        brand: "Omez",
        condition: "Acid Reflux / GERD",
        category: "PPI",
        therapeuticCategory: "Acid Reflux",
        dosage: "20mg",
        form: "Capsule",
        price: 65,
        stock: 150,
        prescriptionRequired: true,
        manufacturer: "Dr. Reddy's",
        rating: 4.6,
        image: "https://images.unsplash.com/photo-1550572017-edd951aa8ca9",
        description:
            "Medicine used to reduce stomach acid and manage acid reflux and GERD."
    },

    {
        name: "Pantoprazole 40mg Tablet",
        genericName: "Pantoprazole",
        brand: "Pantocid",
        condition: "Acid Reflux / GERD",
        category: "PPI",
        therapeuticCategory: "Acid Reflux",
        dosage: "40mg",
        form: "Tablet",
        price: 85,
        stock: 150,
        prescriptionRequired: true,
        manufacturer: "Sun Pharma",
        rating: 4.6,
        image: "https://images.unsplash.com/photo-1585435557343-3b092031a831",
        description:
            "Proton pump inhibitor used to reduce stomach acid."
    },

    {
        name: "Amoxicillin 500mg Capsule",
        genericName: "Amoxicillin",
        brand: "Mox",
        condition: "Bacterial Infection",
        category: "Antibiotic",
        therapeuticCategory: "Antibiotic",
        dosage: "500mg",
        form: "Capsule",
        price: 85,
        stock: 100,
        prescriptionRequired: true,
        manufacturer: "Sun Pharma",
        rating: 4.5,
        image: "https://images.unsplash.com/photo-1584308666744-24d5c474f2ae",
        description:
            "Prescription antibiotic used to treat susceptible bacterial infections."
    },

    {
        name: "Azithromycin 500mg Tablet",
        genericName: "Azithromycin",
        brand: "Azithral",
        condition: "Bacterial Infection",
        category: "Antibiotic",
        therapeuticCategory: "Antibiotic",
        dosage: "500mg",
        form: "Tablet",
        price: 110,
        stock: 100,
        prescriptionRequired: true,
        manufacturer: "Alembic",
        rating: 4.5,
        image: "https://images.unsplash.com/photo-1471864190281-a93a3070b6de",
        description:
            "Prescription antibiotic used for certain bacterial infections."
    },

    {
        name: "Sertraline 50mg Tablet",
        genericName: "Sertraline",
        brand: "Serta",
        condition: "Depression and Anxiety",
        category: "SSRI",
        therapeuticCategory: "Mental Health",
        dosage: "50mg",
        form: "Tablet",
        price: 120,
        stock: 80,
        prescriptionRequired: true,
        manufacturer: "Sun Pharma",
        rating: 4.4,
        image: "https://images.unsplash.com/photo-1584308666744-24d5c474f2ae",
        description:
            "Prescription SSRI medicine used for certain depressive and anxiety disorders."
    },

    {
        name: "Escitalopram 10mg Tablet",
        genericName: "Escitalopram",
        brand: "Nexito",
        condition: "Depression and Anxiety",
        category: "SSRI",
        therapeuticCategory: "Mental Health",
        dosage: "10mg",
        form: "Tablet",
        price: 135,
        stock: 80,
        prescriptionRequired: true,
        manufacturer: "Sun Pharma",
        rating: 4.5,
        image: "https://images.unsplash.com/photo-1550572017-edd951aa8ca9",
        description:
            "Prescription SSRI medicine used for certain anxiety and depressive disorders."
    },

    {
        name: "Gabapentin 300mg Capsule",
        genericName: "Gabapentin",
        brand: "Gabapin",
        condition: "Neuropathic Pain",
        category: "Anticonvulsant",
        therapeuticCategory: "Nerve Pain",
        dosage: "300mg",
        form: "Capsule",
        price: 95,
        stock: 100,
        prescriptionRequired: true,
        manufacturer: "Intas",
        rating: 4.4,
        image: "https://images.unsplash.com/photo-1585435557343-3b092031a831",
        description:
            "Prescription medicine used for certain types of nerve pain and seizures."
    },

    {
        name: "Albuterol Inhaler",
        genericName: "Albuterol",
        brand: "Asthalin",
        condition: "Asthma / Wheezing",
        category: "Bronchodilator",
        therapeuticCategory: "Respiratory",
        dosage: "100mcg",
        form: "Inhaler",
        price: 145,
        stock: 75,
        prescriptionRequired: true,
        manufacturer: "Cipla",
        rating: 4.7,
        image: "/uploads/medicine-images/Albuterol_Sulfate_Inhalation_Aerosol_90_mcg_2_b92a71a413.webp",
        description:
            "Prescription bronchodilator used to relieve bronchospasm and wheezing."
    },

    {
        name: "Insulin Injection",
        genericName: "Insulin",
        brand: "Human Mixtard",
        condition: "Diabetes",
        category: "Antidiabetic",
        therapeuticCategory: "Diabetes",
        dosage: "40 IU/ml",
        form: "Injection",
        price: 185,
        stock: 50,
        prescriptionRequired: true,
        manufacturer: "Novo Nordisk",
        rating: 4.8,
        image: "https://images.unsplash.com/photo-1584308666744-24d5c474f2ae",
        description:
            "Prescription insulin product used to manage blood glucose levels."
    },

    {
        name: "Prednisolone 10mg Tablet",
        genericName: "Prednisolone",
        brand: "Wysolone",
        condition: "Inflammatory Conditions",
        category: "Corticosteroid",
        therapeuticCategory: "Corticosteroid",
        dosage: "10mg",
        form: "Tablet",
        price: 45,
        stock: 100,
        prescriptionRequired: true,
        manufacturer: "GSK",
        rating: 4.4,
        image: "/uploads/medicine-images/prednisolone-10mg-tablets.jpg",
        description:
            "Prescription corticosteroid used for selected inflammatory and immune-related conditions."
    },

    // =====================================================
    // OTC MEDICINES
    // =====================================================

    {
        name: "Ibuprofen 400mg Tablet",
        genericName: "Ibuprofen",
        brand: "Brufen",
        condition: "Pain and Fever",
        category: "Painkiller / NSAID",
        therapeuticCategory: "Pain Relief",
        dosage: "400mg",
        form: "Tablet",
        price: 40,
        stock: 200,
        prescriptionRequired: false,
        manufacturer: "Abbott",
        rating: 4.5,
        image: "https://images.unsplash.com/photo-1550572017-edd951aa8ca9",
        description:
            "Over-the-counter medicine used for temporary relief of pain and fever."
    },

    {
        name: "Acetaminophen 500mg Tablet",
        genericName: "Acetaminophen",
        brand: "Paracetamol",
        condition: "Pain and Fever",
        category: "Painkiller",
        therapeuticCategory: "Pain Relief",
        dosage: "500mg",
        form: "Tablet",
        price: 25,
        stock: 250,
        prescriptionRequired: false,
        manufacturer: "Various",
        rating: 4.7,
        image: "/uploads/medicine-images/acetaminophen-tablets-usp-500-mg.jpg",
        description:
            "Over-the-counter medicine used for temporary relief of mild pain and fever."
    }
];

const addMedicines = async () => {
    try {
        await connectDB();

        console.log("\n========================================");
        console.log("Adding medicines to existing catalogue...");
        console.log("========================================\n");

        let added = 0;
        let updated = 0;

        for (const medicineData of medicines) {
            const existingMedicine = await Medicine.findOne({
                genericName: medicineData.genericName
            });
            if (existingMedicine) {
    const updatedMedicine = await Medicine.findByIdAndUpdate(
        existingMedicine._id,
        {
            $set: medicineData
        },
        {
            returnDocument: "after",
            runValidators: true
        }
    );

    console.log(`UPDATED: ${medicineData.name}`);
    console.log(`IMAGE: ${updatedMedicine.image}`);

    updated++;
}

            
            else {
                await Medicine.create(medicineData);

                console.log(`ADDED:   ${medicineData.name}`);
                added++;
            }
        }

        console.log("\n========================================");
        console.log("Medicine catalogue update completed!");
        console.log(`New medicines added: ${added}`);
        console.log(`Existing medicines updated: ${updated}`);
        console.log(`Total processed: ${medicines.length}`);
        console.log("========================================\n");

        await mongoose.connection.close();

        process.exit(0);

    } catch (error) {
        console.error("\nMedicine import failed:");
        console.error(error);

        await mongoose.connection.close();

        process.exit(1);
    }
};

addMedicines();