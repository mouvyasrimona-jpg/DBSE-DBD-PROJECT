import dns from "node:dns";
dns.setServers(["8.8.8.8", "1.1.1.1"]);

import dotenv from "dotenv";
dotenv.config();

import mongoose from "mongoose";
import Medicine from "../models/Medicine.js";

const DEFAULT_SHOPS = [
    {
        shopName: "Apollo Pharmacy - Metro Express Hub",
        location: "100ft Ring Road, Central Plaza",
        distance: "0.6 km away",
        stock: 35,
        rating: 4.9,
        deliveryTime: "25 mins Express",
        openHours: "24/7 Open"
    },
    {
        shopName: "MedPlus Chemist & Superstore",
        location: "Crossroads Avenue, Block B",
        distance: "1.2 km away",
        stock: 22,
        rating: 4.7,
        deliveryTime: "40 mins",
        openHours: "8:00 AM - 11:30 PM"
    },
    {
        shopName: "PharmaCare Flagship Dispensary",
        location: "Health City Boulevard, Ground Floor",
        distance: "1.8 km away",
        stock: 50,
        rating: 5.0,
        deliveryTime: "30 mins Express",
        openHours: "24/7 Open"
    },
    {
        shopName: "Wellness Forever 24x7 Chemist",
        location: "Commercial Square Sector 4",
        distance: "2.5 km away",
        stock: 18,
        rating: 4.8,
        deliveryTime: "1 hour",
        openHours: "24/7 Open"
    }
];

const MEDICAL_SHOP_ITEMS = [
    {
        name: "Accu-Chek Instant Blood Glucose Meter",
        genericName: "Blood Glucose Monitoring System with 10 Test Strips",
        brand: "Accu-Chek",
        category: "Healthcare Devices",
        therapeuticCategory: "Diagnostic Devices",
        condition: "Diabetes Monitoring",
        dosage: "N/A",
        form: "Kit",
        price: 1299,
        stock: 45,
        prescriptionRequired: false,
        manufacturer: "Roche Diabetes Care",
        rating: 4.8,
        image: "https://images.unsplash.com/photo-1615485290382-441e4d049cb5?w=500&q=80",
        description: "Accurate blood sugar monitoring at home with instant target range indicator and bluetooth sync.",
        availableShops: DEFAULT_SHOPS
    },
    {
        name: "Omron HEM 7120 Digital Blood Pressure Monitor",
        genericName: "Automatic Upper Arm BP Monitor with Intellisense",
        brand: "Omron",
        category: "Healthcare Devices",
        therapeuticCategory: "Diagnostic Devices",
        condition: "Hypertension & Heart Health",
        dosage: "N/A",
        form: "Device",
        price: 1899,
        stock: 30,
        prescriptionRequired: false,
        manufacturer: "Omron Healthcare",
        rating: 4.9,
        image: "https://images.unsplash.com/photo-1579684385127-1ef15d508118?w=500&q=80",
        description: "Clinically validated upper arm digital blood pressure monitor with hypertension indicator.",
        availableShops: DEFAULT_SHOPS
    },
    {
        name: "Dr. Morepen Digital Rigid Tip Thermometer",
        genericName: "Oral, Rectal & Underarm Digital Body Thermometer",
        brand: "Dr. Morepen",
        category: "Healthcare Devices",
        therapeuticCategory: "Diagnostic Devices",
        condition: "Fever & Temperature Tracking",
        dosage: "N/A",
        form: "Device",
        price: 180,
        stock: 90,
        prescriptionRequired: false,
        manufacturer: "Morepen Laboratories Ltd",
        rating: 4.7,
        image: "https://images.unsplash.com/photo-1584017911766-d451b3d0e843?w=500&q=80",
        description: "Fast 60-second fever reading with high temperature beep alert and water-resistant probe.",
        availableShops: DEFAULT_SHOPS
    },
    {
        name: "Beurer PO30 Finger Pulse Oximeter",
        genericName: "SpO2 Oxygen Saturation & Pulse Rate Monitor",
        brand: "Beurer",
        category: "Healthcare Devices",
        therapeuticCategory: "Diagnostic Devices",
        condition: "Respiratory Health",
        dosage: "N/A",
        form: "Device",
        price: 1450,
        stock: 35,
        prescriptionRequired: false,
        manufacturer: "Beurer Germany",
        rating: 4.8,
        image: "https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?w=500&q=80",
        description: "Accurate measurement of arterial oxygen saturation (SpO2) and heart rate (pulse).",
        availableShops: DEFAULT_SHOPS
    },
    {
        name: "Dettol Antiseptic Disinfectant Liquid 500ml",
        genericName: "Chloroxylenol Antiseptic Solution IP",
        brand: "Dettol",
        category: "First Aid",
        therapeuticCategory: "Antiseptic & Wound Care",
        condition: "Wounds, Cuts & Hygiene",
        dosage: "500ml",
        form: "Liquid",
        price: 215,
        stock: 120,
        prescriptionRequired: false,
        manufacturer: "Reckitt Benckiser",
        rating: 4.9,
        image: "https://images.unsplash.com/photo-1584744982491-665216d95f8b?w=500&q=80",
        description: "Trusted germ protection for cuts, wounds, bites, and medical grade personal disinfection.",
        availableShops: DEFAULT_SHOPS
    },
    {
        name: "Savlon Antiseptic Liquid 200ml",
        genericName: "Chlorhexidine Gluconate + Cetrimide Solution",
        brand: "Savlon",
        category: "First Aid",
        therapeuticCategory: "Antiseptic & Wound Care",
        condition: "Minor Cuts & Bruises",
        dosage: "200ml",
        form: "Liquid",
        price: 95,
        stock: 80,
        prescriptionRequired: false,
        manufacturer: "ITC Limited",
        rating: 4.8,
        image: "https://images.unsplash.com/photo-1584515933487-779824d29309?w=500&q=80",
        description: "Effective antiseptic formula that cleanses wounds and does not sting on minor cuts.",
        availableShops: DEFAULT_SHOPS
    },
    {
        name: "Betadine 10% Antiseptic Microbicidal Ointment 20g",
        genericName: "Povidone Iodine Ointment 10% w/w",
        brand: "Betadine",
        category: "First Aid",
        therapeuticCategory: "Antiseptic & Wound Care",
        condition: "Infection Prevention & Wounds",
        dosage: "20g",
        form: "Ointment",
        price: 130,
        stock: 65,
        prescriptionRequired: false,
        manufacturer: "Win-Medicare Pvt Ltd",
        rating: 4.9,
        image: "https://images.unsplash.com/photo-1583912267670-6575ad472688?w=500&q=80",
        description: "Broad spectrum antiseptic microbicide for minor burns, lacerations and wound healing.",
        availableShops: DEFAULT_SHOPS
    },
    {
        name: "Hansaplast Washproof Medicated Bandages (20 Pcs)",
        genericName: "Medicated Adhesive Bandages",
        brand: "Hansaplast",
        category: "First Aid",
        therapeuticCategory: "Wound Care",
        condition: "Minor Cuts & Scrapes",
        dosage: "20 Strips",
        form: "Strip",
        price: 75,
        stock: 150,
        prescriptionRequired: false,
        manufacturer: "Beiersdorf AG",
        rating: 4.7,
        image: "https://images.unsplash.com/photo-1588776814546-1ffcf47267a5?w=500&q=80",
        description: "Waterproof breathable adhesive bandages with antiseptic wound pad.",
        availableShops: DEFAULT_SHOPS
    },
    {
        name: "Dyna Medicated Crepe Bandage (7.5cm x 4m)",
        genericName: "Elastic Cotton Crepe Support Bandage",
        brand: "Dyna",
        category: "First Aid",
        therapeuticCategory: "Orthopedic & First Aid",
        condition: "Sprains & Joint Support",
        dosage: "7.5cm",
        form: "Bandage",
        price: 160,
        stock: 50,
        prescriptionRequired: false,
        manufacturer: "Dynamic Techno Medicals",
        rating: 4.6,
        image: "https://images.unsplash.com/photo-1598440947619-2c35fc9aa908?w=500&q=80",
        description: "Elastic support bandage for sprains, muscle strains, and post-fracture joint compression.",
        availableShops: DEFAULT_SHOPS
    },
    {
        name: "Volini 24-Hour Pain Relief Spray 100g",
        genericName: "Diclofenac Diethylamine + Methyl Salicylate Spray",
        brand: "Volini",
        category: "Pain Relief",
        therapeuticCategory: "Pain Relief",
        condition: "Back Pain, Sprain & Muscle Soreness",
        dosage: "100g",
        form: "Spray",
        price: 245,
        stock: 85,
        prescriptionRequired: false,
        manufacturer: "Sun Pharma",
        rating: 4.8,
        image: "https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?w=500&q=80",
        description: "Quick absorbing pain relief spray for instant action on backache, neck pain, and sports sprains.",
        availableShops: DEFAULT_SHOPS
    },
    {
        name: "Moov Rapid Pain Relief Ointment 50g",
        genericName: "Nilgiri Oil + Wintergreen Oil Herbal Formula",
        brand: "Moov",
        category: "Pain Relief",
        therapeuticCategory: "Pain Relief",
        condition: "Joint Pain & Lower Back Ache",
        dosage: "50g",
        form: "Ointment",
        price: 185,
        stock: 110,
        prescriptionRequired: false,
        manufacturer: "Reckitt Benckiser",
        rating: 4.9,
        image: "https://images.unsplash.com/photo-1583912267670-6575ad472688?w=500&q=80",
        description: "100% natural ayurvedic ingredients penetrating deep to produce warming pain relief.",
        availableShops: DEFAULT_SHOPS
    },
    {
        name: "Iodex Multi-Action Fast Pain Balm 40g",
        genericName: "Ayurvedic Pain Relieving Ointment",
        brand: "Iodex",
        category: "Pain Relief",
        therapeuticCategory: "Pain Relief",
        condition: "Headache, Neck & Back Stiffness",
        dosage: "40g",
        form: "Balm",
        price: 145,
        stock: 95,
        prescriptionRequired: false,
        manufacturer: "GSK Consumer Healthcare",
        rating: 4.7,
        image: "https://images.unsplash.com/photo-1584017911766-d451b3d0e843?w=500&q=80",
        description: "Power of 5 natural herbal extracts for targeted relief from inflammation and ache.",
        availableShops: DEFAULT_SHOPS
    },
    {
        name: "Limcee Chewable Vitamin C 500mg",
        genericName: "Ascorbic Acid + Sodium Ascorbate",
        brand: "Limcee",
        category: "Health & Nutrition",
        therapeuticCategory: "Vitamins & Supplements",
        condition: "Immunity & Antioxidant Care",
        dosage: "500mg",
        form: "Chewable Tablet",
        price: 32,
        stock: 200,
        prescriptionRequired: false,
        manufacturer: "Abbott Healthcare",
        rating: 4.9,
        image: "https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?w=500&q=80",
        description: "Delicious orange chewable vitamin C for cellular health and strong immune defence.",
        availableShops: DEFAULT_SHOPS
    },
    {
        name: "Becosules Z Performance Multivitamin",
        genericName: "Vitamin B-Complex + Vitamin C + Zinc",
        brand: "Becosules",
        category: "Health & Nutrition",
        therapeuticCategory: "Vitamins & Supplements",
        condition: "Energy, Metabolism & Stamina",
        dosage: "Capsule",
        form: "Capsule",
        price: 52,
        stock: 140,
        prescriptionRequired: false,
        manufacturer: "Pfizer India Ltd",
        rating: 4.8,
        image: "https://images.unsplash.com/photo-1550572017-edd951aa8f72?w=500&q=80",
        description: "Essential B-complex vitamins with Zinc to combat fatigue and support vital organ function.",
        availableShops: DEFAULT_SHOPS
    },
    {
        name: "Shelcal 500mg Calcium & Vitamin D3 (15 Tabs)",
        genericName: "Elemental Calcium 500mg + Cholecalciferol 250 IU",
        brand: "Shelcal",
        category: "Health & Nutrition",
        therapeuticCategory: "Vitamins & Supplements",
        condition: "Bone Density & Joint Strength",
        dosage: "500mg",
        form: "Tablet",
        price: 135,
        stock: 95,
        prescriptionRequired: false,
        manufacturer: "Torrent Pharmaceuticals",
        rating: 4.9,
        image: "https://images.unsplash.com/photo-1584017911766-d451b3d0e843?w=500&q=80",
        description: "Doctor recommended calcium and vitamin D3 for bone mineral density and joint nourishment.",
        availableShops: DEFAULT_SHOPS
    },
    {
        name: "Seven Seas Pure Cod Liver Oil (100 Capsules)",
        genericName: "Omega-3 Fatty Acids with Vitamin A & D",
        brand: "Seven Seas",
        category: "Health & Nutrition",
        therapeuticCategory: "Vitamins & Supplements",
        condition: "Heart, Brain & Eye Health",
        dosage: "Softgel",
        form: "Capsule",
        price: 360,
        stock: 60,
        prescriptionRequired: false,
        manufacturer: "Procter & Gamble",
        rating: 4.8,
        image: "https://images.unsplash.com/photo-1550572017-edd951aa8f72?w=500&q=80",
        description: "Rich in EPA and DHA omega-3 essential fatty acids for cardiovascular and cognitive wellness.",
        availableShops: DEFAULT_SHOPS
    },
    {
        name: "Electral ORS WHO Formula Powder (5 Sachets)",
        genericName: "Oral Rehydration Salts IP (WHO Recommended)",
        brand: "Electral",
        category: "Health & Nutrition",
        therapeuticCategory: "Electrolytes & Hydration",
        condition: "Dehydration, Diarrhea & Fatigue",
        dosage: "21.8g x 5",
        form: "Powder",
        price: 110,
        stock: 180,
        prescriptionRequired: false,
        manufacturer: "FDC Limited",
        rating: 4.9,
        image: "https://images.unsplash.com/photo-1576091160550-2173dba999ef?w=500&q=80",
        description: "Restores vital electrolyte balance and fluids rapidly during illness, vomiting or sports fatigue.",
        availableShops: DEFAULT_SHOPS
    },
    {
        name: "Digene Antacid Liquid Gel 200ml (Mint)",
        genericName: "Magnesium Hydroxide + Simethicone Oral Gel",
        brand: "Digene",
        category: "Digestive Care",
        therapeuticCategory: "Digestive Care",
        condition: "Acidity, Heartburn & Gas Relief",
        dosage: "200ml",
        form: "Syrup",
        price: 165,
        stock: 120,
        prescriptionRequired: false,
        manufacturer: "Abbott Healthcare",
        rating: 4.9,
        image: "https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?w=500&q=80",
        description: "Fast soothing relief from stomach acid, gastric discomfort, bloating and heartburn.",
        availableShops: DEFAULT_SHOPS
    },
    {
        name: "Eno Fast Relief Fruit Salt (Lemon - 6 Sachets)",
        genericName: "Sodium Bicarbonate + Citric Acid",
        brand: "Eno",
        category: "Digestive Care",
        therapeuticCategory: "Digestive Care",
        condition: "Instant Acidity & Indigestion",
        dosage: "5g x 6",
        form: "Powder",
        price: 60,
        stock: 200,
        prescriptionRequired: false,
        manufacturer: "GSK Consumer Healthcare",
        rating: 4.8,
        image: "https://images.unsplash.com/photo-1584017911766-d451b3d0e843?w=500&q=80",
        description: "Gets to work in 6 seconds to neutralize harsh stomach acid upon drinking.",
        availableShops: DEFAULT_SHOPS
    },
    {
        name: "Dabur Pudin Hara Active Pearls (10 Pearls)",
        genericName: "Pudina Satva (Mentha Piperita Oil)",
        brand: "Pudin Hara",
        category: "Digestive Care",
        therapeuticCategory: "Digestive Care",
        condition: "Stomach Ache, Gas & Indigestion",
        dosage: "Pearls",
        form: "Capsule",
        price: 35,
        stock: 160,
        prescriptionRequired: false,
        manufacturer: "Dabur India Ltd",
        rating: 4.8,
        image: "https://images.unsplash.com/photo-1550572017-edd951aa8f72?w=500&q=80",
        description: "Natural herbal cooling relief for immediate ease from stomach heaviness and gas.",
        availableShops: DEFAULT_SHOPS
    },
    {
        name: "Dettol Germ Protection Liquid Handwash 200ml",
        genericName: "Antibacterial pH-Balanced Handwash",
        brand: "Dettol",
        category: "Personal Care",
        therapeuticCategory: "Personal Hygiene",
        condition: "Hand Hygiene & Infection Control",
        dosage: "200ml",
        form: "Liquid",
        price: 99,
        stock: 110,
        prescriptionRequired: false,
        manufacturer: "Reckitt Benckiser",
        rating: 4.8,
        image: "https://images.unsplash.com/photo-1584744982491-665216d95f8b?w=500&q=80",
        description: "Kills 99.9% of illness causing germs while keeping hands soft and moisturized.",
        availableShops: DEFAULT_SHOPS
    },
    {
        name: "Lifebuoy Total 10 Alcohol Hand Sanitizer 500ml",
        genericName: "70% Isopropyl Alcohol Hand Disinfectant",
        brand: "Lifebuoy",
        category: "Personal Care",
        therapeuticCategory: "Personal Hygiene",
        condition: "Instant Waterless Hand Hygiene",
        dosage: "500ml",
        form: "Gel",
        price: 240,
        stock: 75,
        prescriptionRequired: false,
        manufacturer: "Hindustan Unilever Ltd",
        rating: 4.7,
        image: "https://images.unsplash.com/photo-1584515933487-779824d29309?w=500&q=80",
        description: "Quick drying 70% alcohol antiseptic hand sanitizer for hospital and home use.",
        availableShops: DEFAULT_SHOPS
    },
    {
        name: "Sensodyne Rapid Relief Toothpaste 80g",
        genericName: "Strontium Acetate Sensitivity Protection Toothpaste",
        brand: "Sensodyne",
        category: "Personal Care",
        therapeuticCategory: "Oral Care",
        condition: "Tooth Sensitivity & Enamel Protection",
        dosage: "80g",
        form: "Paste",
        price: 195,
        stock: 85,
        prescriptionRequired: false,
        manufacturer: "GSK Consumer Healthcare",
        rating: 4.9,
        image: "https://images.unsplash.com/photo-1559591937-e10321a50b73?w=500&q=80",
        description: "Clinically proven formula that builds rapid mineral protection over sensitive teeth within 60s.",
        availableShops: DEFAULT_SHOPS
    },
    {
        name: "Selsun Daily Medicated Anti-Dandruff Shampoo 120ml",
        genericName: "Selenium Sulfide Suspension USP",
        brand: "Selsun",
        category: "Personal Care",
        therapeuticCategory: "Medicated Hair Care",
        condition: "Dandruff & Scalp Itch Relief",
        dosage: "120ml",
        form: "Liquid",
        price: 295,
        stock: 45,
        prescriptionRequired: false,
        manufacturer: "Abbott Healthcare",
        rating: 4.8,
        image: "https://images.unsplash.com/photo-1535585209827-a15fcdbc4c2d?w=500&q=80",
        description: "Dermatologist recommended selenium sulfide formula targeting stubborn dandruff and itching.",
        availableShops: DEFAULT_SHOPS
    },
    {
        name: "Himalaya Happy Baby Calming Lotion 200ml",
        genericName: "Almond Oil + Olive Oil Pediatric Lotion",
        brand: "Himalaya",
        category: "Baby Care",
        therapeuticCategory: "Pediatric Care",
        condition: "Baby Skin Moisture & Nourishment",
        dosage: "200ml",
        form: "Lotion",
        price: 175,
        stock: 70,
        prescriptionRequired: false,
        manufacturer: "Himalaya Wellness",
        rating: 4.8,
        image: "https://images.unsplash.com/photo-1515488042361-ee00e0ddd4e4?w=500&q=80",
        description: "Hypoallergenic, clinically tested daily nourishing lotion for baby's delicate sensitive skin.",
        availableShops: DEFAULT_SHOPS
    },
    {
        name: "Sebamed Baby Diaper Rash Medicated Cream 100ml",
        genericName: "Titanium Dioxide + Panthenol + Squalane pH 5.5",
        brand: "Sebamed",
        category: "Baby Care",
        therapeuticCategory: "Pediatric Care",
        condition: "Diaper Rash Prevention & Healing",
        dosage: "100ml",
        form: "Cream",
        price: 499,
        stock: 40,
        prescriptionRequired: false,
        manufacturer: "Sebapharma Germany",
        rating: 4.9,
        image: "https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?w=500&q=80",
        description: "Provides effective barrier protection against wetness and soothes irritated infant skin.",
        availableShops: DEFAULT_SHOPS
    },
    {
        name: "Woodwards Celebrated Gripe Water 130ml",
        genericName: "Dill Seed Oil + Sarjikakshara",
        brand: "Woodwards",
        category: "Baby Care",
        therapeuticCategory: "Pediatric Care",
        condition: "Baby Colic, Teething & Gas",
        dosage: "130ml",
        form: "Syrup",
        price: 65,
        stock: 90,
        prescriptionRequired: false,
        manufacturer: "TTK Healthcare",
        rating: 4.8,
        image: "https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?w=500&q=80",
        description: "Time tested remedy for infant stomach cramps, teething pain, and gas discomfort.",
        availableShops: DEFAULT_SHOPS
    },
    {
        name: "Candid Clotrimazole Antifungal Dusting Powder 100g",
        genericName: "Clotrimazole 1% w/w Dusting Powder",
        brand: "Candid",
        category: "Skin Care",
        therapeuticCategory: "Antifungal",
        condition: "Fungal Infections, Heat Rash & Itching",
        dosage: "100g",
        form: "Powder",
        price: 155,
        stock: 85,
        prescriptionRequired: false,
        manufacturer: "Glenmark Pharmaceuticals",
        rating: 4.8,
        image: "https://images.unsplash.com/photo-1584017911766-d451b3d0e843?w=500&q=80",
        description: "Effective clinical treatment for prickly heat, ringworm, sweat rash and fungal skin irritation.",
        availableShops: DEFAULT_SHOPS
    },
    {
        name: "Caladryl Calamine Anti-Itch Skin Lotion 120ml",
        genericName: "Calamine + Diphenhydramine Hydrochloride",
        brand: "Caladryl",
        category: "Skin Care",
        therapeuticCategory: "Dermatology",
        condition: "Skin Allergies, Sunburn & Itching",
        dosage: "120ml",
        form: "Lotion",
        price: 125,
        stock: 75,
        prescriptionRequired: false,
        manufacturer: "Piramal Healthcare",
        rating: 4.8,
        image: "https://images.unsplash.com/photo-1556228720-195a672e8a03?w=500&q=80",
        description: "Fast soothing relief from insect bites, sunburn, hives and allergic skin flare-ups.",
        availableShops: DEFAULT_SHOPS
    },
    {
        name: "Boroline Antiseptic Ayurvedic Cream 20g",
        genericName: "Boric Acid + Zinc Oxide + Anhydrous Lanolin",
        brand: "Boroline",
        category: "Skin Care",
        therapeuticCategory: "Antiseptic & Wound Care",
        condition: "Dry Cracked Skin & Minor Cuts",
        dosage: "20g",
        form: "Cream",
        price: 45,
        stock: 140,
        prescriptionRequired: false,
        manufacturer: "GD Pharmaceuticals",
        rating: 4.9,
        image: "https://images.unsplash.com/photo-1583912267670-6575ad472688?w=500&q=80",
        description: "Legendary night repair cream for cracked lips, cracked heels, rough elbows, and post-wound skin repair.",
        availableShops: DEFAULT_SHOPS
    }
];

const CATEGORY_IMAGE_MAP = {
    "Pain Relief": "https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?w=500&q=80",
    "Fever & Pain Relief": "https://images.unsplash.com/photo-1584017911766-d451b3d0e843?w=500&q=80",
    "Antibiotics": "https://images.unsplash.com/photo-1471864190281-a93a3070b6de?w=500&q=80",
    "Diabetes Care": "https://images.unsplash.com/photo-1615485290382-441e4d049cb5?w=500&q=80",
    "Heart & Blood Pressure": "https://images.unsplash.com/photo-1579684385127-1ef15d508118?w=500&q=80",
    "Cholesterol & Heart": "https://images.unsplash.com/photo-1550572017-edd951aa8f72?w=500&q=80",
    "Digestive Care": "https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?w=500&q=80",
    "Cough & Cold": "https://images.unsplash.com/photo-1584017911766-d451b3d0e843?w=500&q=80",
    "First Aid": "https://images.unsplash.com/photo-1584744982491-665216d95f8b?w=500&q=80",
    "Healthcare Devices": "https://images.unsplash.com/photo-1579684385127-1ef15d508118?w=500&q=80",
    "Baby Care": "https://images.unsplash.com/photo-1515488042361-ee00e0ddd4e4?w=500&q=80",
    "Skin Care": "https://images.unsplash.com/photo-1556228720-195a672e8a03?w=500&q=80",
    "Personal Care": "https://images.unsplash.com/photo-1584515933487-779824d29309?w=500&q=80",
    "Health & Nutrition": "https://images.unsplash.com/photo-1550572017-edd951aa8f72?w=500&q=80",
    "General": "https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?w=500&q=80"
};

async function seed() {
    try {
        console.log("Connecting to MongoDB...");
        await mongoose.connect(process.env.MONGO_URI);
        console.log("MongoDB Connected Successfully!");

        const existingMeds = await Medicine.find();
        console.log(`Auditing ${existingMeds.length} existing medicines in MongoDB...`);

        let updatedCount = 0;
        for (const med of existingMeds) {
            const updates = {};

            if (!med.image || med.image.trim() === "" || med.image.startsWith("/medicines/")) {
                updates.image = CATEGORY_IMAGE_MAP[med.category] || CATEGORY_IMAGE_MAP[med.therapeuticCategory] || CATEGORY_IMAGE_MAP["General"];
            }

            if (!med.therapeuticCategory || med.therapeuticCategory.trim() === "") {
                updates.therapeuticCategory = med.category || "General Health";
            }

            if (!med.genericName || med.genericName.trim() === "") {
                updates.genericName = med.name || "General Formulations";
            }

            if (!med.condition || med.condition.trim() === "") {
                updates.condition = med.category || "General Health";
            }

            if (!med.dosage || med.dosage.trim() === "") {
                updates.dosage = "As directed by physician";
            }

            if (!med.form || med.form.trim() === "") {
                updates.form = "Tablet";
            }

            if (!med.brand || med.brand.trim() === "") {
                updates.brand = "PharmaCare Quality";
            }

            if (!med.availableShops || med.availableShops.length === 0) {
                updates.availableShops = DEFAULT_SHOPS;
            }

            if (Object.keys(updates).length > 0) {
                await Medicine.updateOne({ _id: med._id }, { $set: updates });
                updatedCount++;
            }
        }
        console.log(`Updated ${updatedCount} existing items with verified product images and partner shop listings.`);

        let insertedCount = 0;
        for (const item of MEDICAL_SHOP_ITEMS) {
            const exists = await Medicine.findOne({ name: item.name });
            if (!exists) {
                await Medicine.create(item);
                insertedCount++;
            } else {
                exists.image = item.image;
                exists.availableShops = DEFAULT_SHOPS;
                exists.category = item.category;
                exists.therapeuticCategory = item.therapeuticCategory;
                await exists.save();
            }
        }
        console.log(`Added ${insertedCount} new medical shop inventory items!`);

        const finalTotal = await Medicine.countDocuments();
        console.log(`TOTAL ACTIVE PRODUCTS IN PHARMACARE CATALOG: ${finalTotal}`);
        console.log("Seeding and image enhancement complete!");

        process.exit(0);
    } catch (err) {
        console.error("Seeding Error:", err);
        process.exit(1);
    }
}

seed();
