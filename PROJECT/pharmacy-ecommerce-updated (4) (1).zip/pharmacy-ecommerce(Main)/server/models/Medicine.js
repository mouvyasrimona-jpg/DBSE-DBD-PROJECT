import mongoose from "mongoose";

const medicineSchema = new mongoose.Schema(
    {
        name: {
            type: String,
            required: true,
            trim: true
        },

        genericName: {
            type: String,
            required: true,
            trim: true
        },

        brand: {
            type: String,
            required: true,
            trim: true
        },

        condition: {
            type: String,
            required: true,
            trim: true
        },

        category: {
            type: String,
            required: true,
            trim: true
        },

        // NEW FIELD — used for substitute medicine matching
        // (groups medicines by medical purpose, e.g. "Pain Relief", "Antibiotic")
        therapeuticCategory: {
            type: String,
            required: true,
            trim: true,
            index: true
        },

        dosage: {
            type: String,
            required: true,
            trim: true
        },

        form: {
            type: String,
            required: true,
            trim: true
        },

        price: {
            type: Number,
            required: true,
            min: 0
        },

        stock: {
            type: Number,
            required: true,
            min: 0
        },

        prescriptionRequired: {
            type: Boolean,
            default: false
        },

        manufacturer: {
            type: String,
            required: true,
            trim: true
        },

        rating: {
            type: Number,
            default: 0,
            min: 0,
            max: 5
        },

        image: {
            type: String,
            default: ""
        },

        description: {
            type: String,
            default: ""
        },

        // Used by Advanced Search (feature 13) — free-text active
        // ingredient/composition, e.g. "Paracetamol 500mg + Caffeine 30mg"
        composition: {
            type: String,
            default: ""
        },

        reviewCount: {
            type: Number,
            default: 0
        },

        availableShops: [
            {
                shopName: { type: String, required: true },
                location: { type: String, required: true },
                distance: { type: String, default: "1.0 km away" },
                stock: { type: Number, default: 20 },
                rating: { type: Number, default: 4.8 },
                deliveryTime: { type: String, default: "30 mins Express" },
                openHours: { type: String, default: "24/7 Open" },

                // Multi-Pharmacy Comparison (feature 3) — each
                // pharmacy can price the same medicine differently.
                // Falls back to the medicine's base `price` above
                // when not set, so existing data keeps working.
                price: { type: Number, default: null },
                discountPercent: { type: Number, default: 0 }
            }
        ]
    },
    {
        timestamps: true
    }
);

const Medicine = mongoose.model("Medicine", medicineSchema);

export default Medicine;