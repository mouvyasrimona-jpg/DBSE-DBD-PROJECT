import mongoose from "mongoose";

// Batch-level inventory tracking for feature 4. A single Medicine
// can have multiple batches (different expiry dates, suppliers,
// purchase prices) — this is standard real-world pharmacy practice
// (FEFO: First-Expired-First-Out).
const inventoryBatchSchema = new mongoose.Schema(
    {
        medicineId: {
            type: mongoose.Schema.Types.ObjectId,
            ref: "Medicine",
            required: true,
            index: true
        },

        batchNumber: {
            type: String,
            required: true,
            trim: true
        },

        manufacturingDate: {
            type: Date,
            required: true
        },

        expiryDate: {
            type: Date,
            required: true,
            index: true
        },

        quantity: {
            type: Number,
            required: true,
            min: 0
        },

        purchasePrice: {
            type: Number,
            required: true,
            min: 0
        },

        sellingPrice: {
            type: Number,
            required: true,
            min: 0
        },

        supplier: {
            type: String,
            default: ""
        },

        pharmacyName: {
            type: String,
            default: ""
        },

        // Derived on read, not stored redundantly — kept here only
        // as a manually-set override for edge cases (e.g. recalled batch)
        status: {
            type: String,
            enum: ["Active", "Recalled", "Depleted"],
            default: "Active"
        }
    },
    {
        timestamps: true
    }
);

const InventoryBatch = mongoose.model("InventoryBatch", inventoryBatchSchema);

export default InventoryBatch;
