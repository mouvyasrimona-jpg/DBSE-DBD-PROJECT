import mongoose from "mongoose";

// Records every event in a prescription's lifecycle so the full
// history can be reconstructed later — required for feature 2
// (Prescription Audit Trail). This is append-only: entries are
// never edited or deleted, only added.
const prescriptionAuditSchema = new mongoose.Schema(
    {
        prescriptionId: {
            type: mongoose.Schema.Types.ObjectId,
            ref: "Prescription",
            required: true,
            index: true
        },

        action: {
            type: String,
            enum: [
                "Uploaded",
                "OCR_Completed",
                "Medicines_Detected",
                "Validation_Result",
                "Pharmacist_Assigned",
                "Pharmacist_Reviewed",
                "Approved",
                "Rejected",
                "Clarification_Requested",
                "Modified"
            ],
            required: true
        },

        performedBy: {
            type: mongoose.Schema.Types.ObjectId,
            ref: "User",
            default: null // null for system-generated events like OCR
        },

        performedByRole: {
            type: String,
            default: "system"
        },

        reason: {
            type: String,
            default: ""
        },

        metadata: {
            type: mongoose.Schema.Types.Mixed,
            default: {}
        }
    },
    {
        timestamps: true
    }
);

const PrescriptionAudit = mongoose.model("PrescriptionAudit", prescriptionAuditSchema);

export default PrescriptionAudit;
