import mongoose from "mongoose";

const userSchema = new mongoose.Schema(
    {
        name: {
            type: String,
            required: true,
            trim: true
        },

        email: {
            type: String,
            required: true,
            unique: true,
            lowercase: true,
            trim: true
        },

        password: {
            type: String,
            required: true
        },

        role: {
            type: String,
            enum: ["customer", "pharmacist", "admin", "delivery"],
            default: "customer"
        },

        // Only populated for role: "delivery"
        deliveryProfile: {
            vehicleNumber: { type: String, default: "" },
            phone: { type: String, default: "" },
            isAvailable: { type: Boolean, default: true }
        }
    },
    {
        timestamps: true
    }
);

const User = mongoose.model("User", userSchema);

export default User;