import mongoose from "mongoose";

const labCenterSchema = new mongoose.Schema(
    {
        name: {
            type: String,
            required: true,
            trim: true
        },

        address: {
            type: String,
            required: true
        },

        phone: {
            type: String,
            default: ""
        },

        openHours: {
            type: String,
            default: "7:00 AM - 8:00 PM"
        },

        rating: {
            type: Number,
            default: 0,
            min: 0,
            max: 5
        },

        active: {
            type: Boolean,
            default: true
        }
    },
    {
        timestamps: true
    }
);

const LabCenter = mongoose.model("LabCenter", labCenterSchema);

export default LabCenter;
