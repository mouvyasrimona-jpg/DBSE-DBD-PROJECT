import mongoose from "mongoose";

const reminderSchema = new mongoose.Schema(
    {
        userId: {
            type: mongoose.Schema.Types.ObjectId,
            ref: "User",
            required: true
        },
        medicineId: {
            type: mongoose.Schema.Types.ObjectId,
            ref: "Medicine",
            default: null
        },
        medicineName: {
            type: String,
            required: true,
            trim: true
        },
        refillDate: {
            type: Date,
            required: true
        },
        quantity: {
            type: Number,
            default: 1,
            min: 1
        },
        note: {
            type: String,
            default: "",
            trim: true
        },
        isActive: {
            type: Boolean,
            default: true
        }
    },
    {
        timestamps: true
    }
);

const Reminder = mongoose.model("Reminder", reminderSchema);
export default Reminder;
