import mongoose from "mongoose";

const prescriptionSchema = new mongoose.Schema(
    {
        userId: {
            type: mongoose.Schema.Types.ObjectId,
            ref: "User",
            required: true
        },

        originalName: {
            type: String,
            required: true
        },

        fileName: {
            type: String,
            required: true
        },

        filePath: {
            type: String,
            required: true
        },

        status: {
            type: String,
            enum: ["Pending", "Approved", "Rejected"],
            default: "Pending"
        },

        rejectionReason: {
            type: String,
            default: ""
        },

        ocrDetectedText: {
            type: String,
            default: ""
        },

        detectedMedicines: {
            type: [String],
            default: []
        },

        // =====================================================
        // ADVANCED PRESCRIPTION INTELLIGENCE (feature 1)
        // =====================================================
        extractedInfo: {
            patientName: { type: String, default: "" },
            doctorName: { type: String, default: "" },
            prescriptionDate: { type: Date, default: null },
            medicines: [
                {
                    name: { type: String },
                    dosage: { type: String, default: "" },
                    frequency: { type: String, default: "" },
                    duration: { type: String, default: "" },
                    confidence: { type: Number, default: 0 } // 0-100
                }
            ]
        },

        // Result of matching extractedInfo.medicines against the
        // real Medicine collection.
        medicineMatchResults: [
            {
                detectedName: { type: String },
                matchType: {
                    type: String,
                    enum: ["exact", "partial", "unknown", "unavailable"],
                    default: "unknown"
                },
                matchedMedicineId: {
                    type: mongoose.Schema.Types.ObjectId,
                    ref: "Medicine",
                    default: null
                },
                matchedMedicineName: { type: String, default: "" }
            }
        ],

        // True if prescriptionDate is more than 30 days old at
        // upload time, or missing entirely.
        isExpired: {
            type: Boolean,
            default: false
        },

        // True if extraction confidence is low, fields are missing,
        // or an unknown medicine was detected — surfaces a warning
        // to the pharmacist rather than silently approving.
        needsManualReview: {
            type: Boolean,
            default: true
        },

        overallConfidence: {
            type: Number,
            default: 0 // 0-100
        }
    },
    {
        timestamps: true
    }
);

const Prescription = mongoose.model("Prescription", prescriptionSchema);

export default Prescription;