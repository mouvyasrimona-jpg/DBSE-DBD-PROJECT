import mongoose from "mongoose";

const notificationSchema = new mongoose.Schema(
    {
        userId: {
            type: mongoose.Schema.Types.ObjectId,
            ref: "User",
            required: true,
            index: true
        },

        type: {
            type: String,
            enum: [
                "prescription_uploaded",
                "prescription_approved",
                "prescription_rejected",
                "prescription_clarification",
                "order_confirmed",
                "order_preparing",
                "order_packed",
                "order_picked_up",
                "order_out_for_delivery",
                "order_delivered",
                "order_cancelled",
                "refill_reminder"
            ],
            required: true
        },

        title: {
            type: String,
            required: true
        },

        message: {
            type: String,
            required: true
        },

        relatedId: {
            // Loose reference (could point to an Order or Prescription id)
            type: mongoose.Schema.Types.ObjectId,
            default: null
        },

        isRead: {
            type: Boolean,
            default: false
        }
    },
    {
        timestamps: true
    }
);

const Notification = mongoose.model("Notification", notificationSchema);

export default Notification;
