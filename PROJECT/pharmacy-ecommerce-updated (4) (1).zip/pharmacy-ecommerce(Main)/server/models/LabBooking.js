import mongoose from "mongoose";

const labBookingSchema = new mongoose.Schema(
    {
        bookingId: {
            type: String,
            required: true,
            unique: true
        },

        userId: {
            type: mongoose.Schema.Types.ObjectId,
            ref: "User",
            required: true,
            index: true
        },

        testId: {
            type: mongoose.Schema.Types.ObjectId,
            ref: "LabTest",
            required: true
        },

        testName: {
            type: String,
            required: true
        },

        price: {
            type: Number,
            required: true
        },

        // Patient the test is actually for — may not be the account
        // holder (e.g. booking for a family member).
        patient: {
            name: { type: String, required: true },
            age: { type: Number, required: true },
            gender: { type: String, enum: ["Male", "Female", "Other"], required: true },
            phone: { type: String, default: "" }
        },

        collectionType: {
            type: String,
            enum: ["Home", "Center"],
            required: true
        },

        centerId: {
            type: mongoose.Schema.Types.ObjectId,
            ref: "LabCenter",
            default: null
        },

        homeAddress: {
            type: String,
            default: ""
        },

        bookingDate: {
            type: Date,
            required: true
        },

        timeSlot: {
            type: String,
            required: true
        },

        paymentStatus: {
            type: String,
            enum: ["Pending", "Paid"],
            default: "Pending"
        },

        // Real lifecycle — matches the doc's requested flow exactly.
        // "Report Ready" is only ever set by an explicit admin action,
        // never inferred, so we never claim a result exists that doesn't.
        bookingStatus: {
            type: String,
            enum: [
                "Confirmed",
                "Scheduled",
                "SampleCollected",
                "SampleReceived",
                "Testing",
                "ReportReady",
                "Cancelled"
            ],
            default: "Confirmed"
        }
    },
    {
        timestamps: true
    }
);

const LabBooking = mongoose.model("LabBooking", labBookingSchema);

export default LabBooking;
