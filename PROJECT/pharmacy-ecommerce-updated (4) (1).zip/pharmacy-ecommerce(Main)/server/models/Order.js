import mongoose from "mongoose";

const selectedPharmacySchema = new mongoose.Schema(
    {
        shopName: { type: String },
        location: { type: String },
        distance: { type: String },
        rating: { type: Number },
        deliveryTime: { type: String },
        openHours: { type: String }
    },
    { _id: false }
);

const orderItemSchema = new mongoose.Schema(
    {
        medicineId: {
            type: mongoose.Schema.Types.ObjectId,
            ref: "Medicine",
            required: true
        },

        name: {
            type: String,
            required: true
        },

        price: {
            type: Number,
            required: true,
            min: 0
        },

        quantity: {
            type: Number,
            required: true,
            min: 1
        },

        subtotal: {
            type: Number,
            required: true,
            min: 0
        },

        image: {
            type: String,
            default: ""
        },

        // Which pharmacy (from Medicine.availableShops) the customer
        // chose to fulfill this specific item. Optional — not every
        // medicine has availableShops populated.
        selectedPharmacy: {
            type: selectedPharmacySchema,
            default: null
        }
    },
    {
        _id: false
    }
);

const orderSchema = new mongoose.Schema(
    {
        // Customer who placed the order
        userId: {
            type: mongoose.Schema.Types.ObjectId,
            ref: "User",
            required: true
        },

        // Products inside the order
        items: {
            type: [orderItemSchema],
            required: true,
            validate: {
                validator: function (items) {
                    return items.length > 0;
                },
                message: "Order must contain at least one item"
            }
        },

        // Final order amount
        totalAmount: {
            type: Number,
            required: true,
            min: 0
        },

        // Order status — extended for real-time state tracking
        // (feature 5). "Shipped" is kept as a deprecated alias so
        // any historical data written before this migration still
        // validates, but new orders use the new granular states.
        status: {
            type: String,
            enum: [
                "Pending",
                "Confirmed",
                "Preparing",
                "Packed",
                "PickedUp",
                "OutForDelivery",
                "Delivered",
                "Cancelled",
                "Failed",
                "Returned",
                // legacy values kept valid, not used for new orders
                "Processing",
                "Shipped"
            ],
            default: "Pending"
        },

        // Payment status
        paymentStatus: {
            type: String,
            enum: [
                "Pending",
                "Paid",
                "Failed",
                "Refunded"
            ],
            default: "Pending"
        },

        // Payment method
        paymentMethod: {
            type: String,
            enum: [
                "COD",
                "ONLINE"
            ],
            default: "COD"
        },

        // The pharmacy chosen for this order overall — mirrors the
        // first item's selectedPharmacy at creation time, so the
        // Checkout summary and Order Tracking page can show a single
        // "Selected Pharmacy" card without having to inspect every item.
        selectedPharmacy: {
            type: selectedPharmacySchema,
            default: null
        },

        // Delivery address
        shippingAddress: {
            name: {
                type: String,
                required: true
            },

            phone: {
                type: String,
                required: true
            },

            addressLine: {
                type: String,
                required: true
            },

            city: {
                type: String,
                required: true
            },

            state: {
                type: String,
                required: true
            },

            pincode: {
                type: String,
                required: true
            }
        },

        // =====================================================
        // LIVE DELIVERY TRACKING (simulated GPS engine)
        // Coordinates are generated deterministically at order
        // creation time so the same order always maps to the
        // same simulated pharmacy/courier/destination route.
        // =====================================================
        tracking: {
            pharmacyLocation: {
                lat: { type: Number, default: 17.4126 },
                lng: { type: Number, default: 78.4483 }
            },
            deliveryLocation: {
                lat: { type: Number, default: 17.4126 },
                lng: { type: Number, default: 78.4483 }
            },
            courierName: {
                type: String,
                default: "Delivery Partner"
            },
            courierPhone: {
                type: String,
                default: "+91 90000 00000"
            },
            etaMinutes: {
                type: Number,
                default: 25
            }
        },

        // Timestamp set the moment the order enters "Shipped"
        // status — the live map animates the courier from this
        // point onward, arriving at deliveryLocation at
        // shippedAt + tracking.etaMinutes.
        shippedAt: {
            type: Date,
            default: null
        },

        deliveredAt: {
            type: Date,
            default: null
        },

        // =====================================================
        // DELIVERY PARTNER ASSIGNMENT (feature 6)
        // =====================================================
        deliveryPartnerId: {
            type: mongoose.Schema.Types.ObjectId,
            ref: "User",
            default: null
        },

        // =====================================================
        // DELIVERY OTP (feature 7)
        // otpCodeHash is never sent to the delivery partner — only
        // the customer sees the plain OTP (via getOrderById, only
        // when they are the order's own customer). The delivery
        // partner submits a guess, which is compared server-side
        // against the hash. This is the same principle as password
        // hashing: the secret is never trusted from the client.
        // =====================================================
        deliveryOtp: {
            codeHash: { type: String, default: null },
            expiresAt: { type: Date, default: null },
            attemptsRemaining: { type: Number, default: 5 },
            verifiedAt: { type: Date, default: null }
        },

        // =====================================================
        // INVOICE FIELDS (feature 12)
        // =====================================================
        invoiceNumber: {
            type: String,
            default: null
        },
        deliveryFee: {
            type: Number,
            default: 0
        },
        discount: {
            type: Number,
            default: 0
        },
        taxAmount: {
            type: Number,
            default: 0
        }
    },
    {
        timestamps: true
    }
);

const Order = mongoose.model(
    "Order",
    orderSchema
);

export default Order;