import mongoose from "mongoose";

// Append-only log of every status change an order goes through —
// this is what makes Order Tracking (feature 5) a real history
// instead of just "here is the current status".
const orderStatusHistorySchema = new mongoose.Schema(
    {
        orderId: {
            type: mongoose.Schema.Types.ObjectId,
            ref: "Order",
            required: true,
            index: true
        },

        status: {
            type: String,
            required: true
        },

        changedBy: {
            type: mongoose.Schema.Types.ObjectId,
            ref: "User",
            default: null
        },

        note: {
            type: String,
            default: ""
        }
    },
    {
        timestamps: true
    }
);

const OrderStatusHistory = mongoose.model("OrderStatusHistory", orderStatusHistorySchema);

export default OrderStatusHistory;
