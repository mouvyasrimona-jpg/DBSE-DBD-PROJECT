import mongoose from "mongoose";

const labTestSchema = new mongoose.Schema(
    {
        name: {
            type: String,
            required: true,
            trim: true
        },

        description: {
            type: String,
            default: ""
        },

        category: {
            type: String,
            required: true,
            trim: true,
            index: true
        },

        // What this test/package actually measures — shown on the
        // details page, never invented on the frontend.
        parameters: {
            type: [String],
            default: []
        },

        price: {
            type: Number,
            required: true,
            min: 0
        },

        mrp: {
            type: Number,
            required: true,
            min: 0
        },

        discountPercent: {
            type: Number,
            default: 0,
            min: 0,
            max: 100
        },

        sampleType: {
            type: String,
            default: "Blood"
        },

        homeCollection: {
            type: Boolean,
            default: true
        },

        // Only real, factual preparation info (e.g. "Fasting required
        // for 8-10 hours") — never medical advice. Optional, blank
        // by default rather than inventing generic instructions.
        preparationInfo: {
            type: String,
            default: ""
        },

        active: {
            type: Boolean,
            default: true
        }
    },
    {
        timestamps: true
    }
);

const LabTest = mongoose.model("LabTest", labTestSchema);

export default LabTest;
