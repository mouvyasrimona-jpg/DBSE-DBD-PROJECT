// =====================================================
// SIMULATED LIVE-TRACKING / GPS ENGINE
//
// This project has no paid geocoding/maps API key, so
// exactly like the "Simulated OCR Engine" already used for
// prescriptions, delivery coordinates are generated with a
// deterministic pseudo-random function seeded from the
// order's own address text. The SAME order always produces
// the SAME pharmacy/destination pair, and the courier is
// animated between them in real time on the frontend.
// =====================================================

// Default pharmacy / warehouse location (Hyderabad, India)
const PHARMACY_LOCATION = { lat: 17.4126, lng: 78.4483 };

const COURIER_NAMES = [
    "Ravi Kumar",
    "Suresh Reddy",
    "Anil Sharma",
    "Vikram Singh",
    "Manoj Verma"
];

// Simple deterministic string hash (djb2)
const hashString = (str) => {
    let hash = 5381;
    for (let i = 0; i < str.length; i++) {
        hash = (hash * 33) ^ str.charCodeAt(i);
    }
    return Math.abs(hash);
};

// Turns a hash into a pseudo-random float between min and max
const seededFloat = (seed, min, max) => {
    const x = Math.sin(seed) * 10000;
    const frac = x - Math.floor(x);
    return min + frac * (max - min);
};

/**
 * Generate a simulated tracking payload for a freshly created order.
 * The delivery point is placed 2-8 km away from the pharmacy in a
 * random direction, derived deterministically from the shipping
 * address so re-computing it later always gives the same result.
 */
export const generateTracking = (shippingAddress = {}, seedKey = "") => {
    const seedSource =
        `${seedKey}-${shippingAddress.addressLine || ""}-${shippingAddress.pincode || ""}-${shippingAddress.city || ""}`;

    const seed = hashString(seedSource);

    // Distance 2km - 8km away, random bearing 0-360deg
    const distanceKm = seededFloat(seed, 2, 8);
    const bearingDeg = seededFloat(seed + 1, 0, 360);
    const bearingRad = (bearingDeg * Math.PI) / 180;

    // ~111km per degree latitude; longitude scaled by latitude
    const deltaLat = (distanceKm / 111) * Math.cos(bearingRad);
    const deltaLng =
        (distanceKm / (111 * Math.cos((PHARMACY_LOCATION.lat * Math.PI) / 180))) *
        Math.sin(bearingRad);

    const deliveryLocation = {
        lat: Number((PHARMACY_LOCATION.lat + deltaLat).toFixed(6)),
        lng: Number((PHARMACY_LOCATION.lng + deltaLng).toFixed(6))
    };

    const courierName = COURIER_NAMES[seed % COURIER_NAMES.length];
    const courierPhone = `+91 9${String(seed).slice(0, 9).padEnd(9, "0")}`;

    // ETA scales gently with distance (roughly 4 min/km + base prep time)
    const etaMinutes = Math.round(12 + distanceKm * 4);

    return {
        pharmacyLocation: PHARMACY_LOCATION,
        deliveryLocation,
        courierName,
        courierPhone,
        etaMinutes
    };
};

/**
 * Compute the courier's current simulated position + delivery phase
 * for an order that has already been shipped.
 */
export const computeLiveCourierPosition = (order) => {
    const tracking = order.tracking || {};
    const pharmacy = tracking.pharmacyLocation || PHARMACY_LOCATION;
    const destination = tracking.deliveryLocation || PHARMACY_LOCATION;
    const etaMinutes = tracking.etaMinutes || 25;

    // Not out for delivery yet — courier hasn't left the pharmacy.
    // Covers Pending, Confirmed, Preparing, Packed, PickedUp.
    if (!order.shippedAt || ["Pending", "Confirmed", "Preparing", "Packed", "PickedUp"].includes(order.status)) {
        const phaseLabel =
            order.status === "Pending" ? "Order Confirmed" :
            order.status === "PickedUp" ? "Picked Up — Preparing to Depart" :
            "Preparing Order";
        return {
            phase: phaseLabel,
            progress: 0,
            courierLocation: pharmacy,
            etaMinutesRemaining: etaMinutes
        };
    }

    if (order.status === "Delivered") {
        return {
            phase: "Delivered",
            progress: 1,
            courierLocation: destination,
            etaMinutesRemaining: 0
        };
    }

    if (["Cancelled", "Failed", "Returned"].includes(order.status)) {
        return {
            phase: order.status,
            progress: 0,
            courierLocation: pharmacy,
            etaMinutesRemaining: 0
        };
    }

    // Status is "OutForDelivery" -> animate courier along the route
    const elapsedMs = Date.now() - new Date(order.shippedAt).getTime();
    const totalMs = etaMinutes * 60 * 1000;
    let progress = totalMs > 0 ? elapsedMs / totalMs : 1;
    progress = Math.max(0, Math.min(1, progress));

    // Slight curved path instead of a straight line: offset the
    // midpoint perpendicular to the direct route.
    const midLat = pharmacy.lat + (destination.lat - pharmacy.lat) * progress;
    const midLng = pharmacy.lng + (destination.lng - pharmacy.lng) * progress;

    const curveStrength = Math.sin(progress * Math.PI) * 0.0015;
    const dx = destination.lng - pharmacy.lng;
    const dy = destination.lat - pharmacy.lat;
    const norm = Math.sqrt(dx * dx + dy * dy) || 1;
    const perpLat = -(dx / norm) * curveStrength;
    const perpLng = (dy / norm) * curveStrength;

    const courierLocation = {
        lat: Number((midLat + perpLat).toFixed(6)),
        lng: Number((midLng + perpLng).toFixed(6))
    };

    const etaMinutesRemaining = Math.max(0, Math.round(etaMinutes * (1 - progress)));

    return {
        phase: progress >= 1 ? "Arriving" : "Out for Delivery",
        progress,
        courierLocation,
        etaMinutesRemaining
    };
};
