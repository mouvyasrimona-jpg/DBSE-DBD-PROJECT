import express from "express";
import {
    getLabTests, getLabTestCategories, getLabTestById,
    createLabTest, updateLabTest, deleteLabTest
} from "../controllers/labTestController.js";
import { protect, authorizeRoles } from "../middleware/authMiddleware.js";

const router = express.Router();

router.get("/", getLabTests);
router.get("/categories", getLabTestCategories);
router.get("/:id", getLabTestById);

router.post("/", protect, authorizeRoles("admin", "pharmacist"), createLabTest);
router.put("/:id", protect, authorizeRoles("admin", "pharmacist"), updateLabTest);
router.delete("/:id", protect, authorizeRoles("admin", "pharmacist"), deleteLabTest);

export default router;
