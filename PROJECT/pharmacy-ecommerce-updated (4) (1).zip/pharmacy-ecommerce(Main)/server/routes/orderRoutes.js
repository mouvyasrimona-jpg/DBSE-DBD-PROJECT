import express from "express";

import {
    createOrder,
    getMyOrders,
    getOrderById,
    getAllOrders,
    updateOrderStatus,
    getOrderTracking,
    getOrderInvoice,
    getOrderStatusHistory
} from "../controllers/orderController.js";

import { protect, authorizeRoles } from "../middleware/authMiddleware.js";

const router = express.Router();

// Customer routes
router.post(
    "/",
    protect,
    createOrder
);

router.get(
    "/my-orders",
    protect,
    getMyOrders
);

// Live map tracking for a single order (customer or admin/pharmacist)
router.get(
    "/:id/tracking",
    protect,
    getOrderTracking
);

router.get(
    "/:id/invoice",
    protect,
    getOrderInvoice
);

router.get(
    "/:id/history",
    protect,
    getOrderStatusHistory
);

// Single order route (handles customer vs admin internally)
router.get(
    "/:id",
    protect,
    getOrderById
);

// Admin routes
router.get(
    "/",
    protect,
    authorizeRoles("admin", "pharmacist"),
    getAllOrders
);

router.put(
    "/:id/status",
    protect,
    authorizeRoles("admin", "pharmacist"),
    updateOrderStatus
);

export default router;