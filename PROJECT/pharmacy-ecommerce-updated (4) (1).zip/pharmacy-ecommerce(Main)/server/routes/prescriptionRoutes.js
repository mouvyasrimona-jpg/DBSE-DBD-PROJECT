import express from "express";
import upload from "../middleware/upload.js";
import { protect, authorizeRoles } from "../middleware/authMiddleware.js";
import {
    uploadPrescription,
    getMyPrescriptions,
    getAllPrescriptions,
    updatePrescriptionStatus,
    getPrescriptionAudit
} from "../controllers/prescriptionController.js";

const router = express.Router();

// Customer upload
router.post(
    "/upload",
    protect,
    upload.single("prescription"),
    uploadPrescription
);

// Customer list
router.get(
    "/my-prescriptions",
    protect,
    getMyPrescriptions
);

// Admin list & review
router.get(
    "/",
    protect,
    authorizeRoles("admin", "pharmacist"),
    getAllPrescriptions
);

router.put(
    "/:id/status",
    protect,
    authorizeRoles("admin", "pharmacist"),
    updatePrescriptionStatus
);

router.get(
    "/:id/audit",
    protect,
    getPrescriptionAudit
);

export default router;