import express from "express";
import {
    createBatch, getBatchesForMedicine, getInventoryOverview, adjustStock
} from "../controllers/inventoryController.js";
import { protect, authorizeRoles } from "../middleware/authMiddleware.js";

const router = express.Router();

router.use(protect, authorizeRoles("admin", "pharmacist"));

router.post("/batches", createBatch);
router.get("/batches/:medicineId", getBatchesForMedicine);
router.get("/overview", getInventoryOverview);
router.put("/batches/:id/adjust", adjustStock);

export default router;
