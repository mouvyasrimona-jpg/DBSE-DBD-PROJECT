import express from "express";
import {
    getAvailableSlots, createBooking, getMyBookings,
    getBookingById, getAllBookings, updateBookingStatus
} from "../controllers/labBookingController.js";
import { protect, authorizeRoles } from "../middleware/authMiddleware.js";

const router = express.Router();

router.get("/available-slots", getAvailableSlots);
router.post("/", protect, createBooking);
router.get("/my", protect, getMyBookings);
router.get("/", protect, authorizeRoles("admin", "pharmacist"), getAllBookings);
router.get("/:id", protect, getBookingById);
router.put("/:id/status", protect, authorizeRoles("admin", "pharmacist"), updateBookingStatus);

export default router;
