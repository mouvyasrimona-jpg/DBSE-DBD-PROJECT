import express from "express";
import { createReview, getReviewsForMedicine, getEligibleReviewItems } from "../controllers/reviewController.js";
import { protect } from "../middleware/authMiddleware.js";

const router = express.Router();

router.get("/medicine/:medicineId", getReviewsForMedicine); // public
router.post("/", protect, createReview);
router.get("/eligible/:orderId", protect, getEligibleReviewItems);

export default router;
