import express from "express";
import {
    getMedicines,
    getMedicineById,
    searchMedicines,
    autocompleteMedicines,
    createMedicine,
    updateMedicine,
    deleteMedicine,
    getSubstituteMedicines,
    getPopularMedicines,
    getMedicineCategories
} from "../controllers/medicineController.js";
import { protect, authorizeRoles } from "../middleware/authMiddleware.js";

const router = express.Router();

// Public routes — specific paths before "/:id" so they aren't
// swallowed by the dynamic ID route.
router.get("/", getMedicines);
router.get("/search", searchMedicines);
router.get("/autocomplete", autocompleteMedicines);
router.get("/popular", getPopularMedicines);
router.get("/categories", getMedicineCategories);
router.get("/:id", getMedicineById);
router.get("/:id/substitutes", getSubstituteMedicines);

// Protected Admin routes
router.post(
    "/",
    protect,
    authorizeRoles("admin", "pharmacist"),
    createMedicine
);

router.put(
    "/:id",
    protect,
    authorizeRoles("admin", "pharmacist"),
    updateMedicine
);

router.delete(
    "/:id",
    protect,
    authorizeRoles("admin", "pharmacist"),
    deleteMedicine
);

export default router;