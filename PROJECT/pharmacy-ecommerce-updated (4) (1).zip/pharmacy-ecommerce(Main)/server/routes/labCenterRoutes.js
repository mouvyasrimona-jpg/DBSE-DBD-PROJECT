import express from "express";
import { getLabCenters, createLabCenter, updateLabCenter, deleteLabCenter } from "../controllers/labCenterController.js";
import { protect, authorizeRoles } from "../middleware/authMiddleware.js";

const router = express.Router();

router.get("/", getLabCenters);
router.post("/", protect, authorizeRoles("admin"), createLabCenter);
router.put("/:id", protect, authorizeRoles("admin"), updateLabCenter);
router.delete("/:id", protect, authorizeRoles("admin"), deleteLabCenter);

export default router;
