import express from "express";
import { getMyReminders, createReminder, updateReminder, deleteReminder, getPredictedRefills } from "../controllers/reminderController.js";
import { protect } from "../middleware/authMiddleware.js";

const router = express.Router();

router.get("/", protect, getMyReminders);
router.get("/predictions", protect, getPredictedRefills);
router.post("/", protect, createReminder);
router.put("/:id", protect, updateReminder);
router.delete("/:id", protect, deleteReminder);

export default router;
