import express from "express";
import {
    getAssignedDeliveries,
    getDeliveryHistory,
    acceptDelivery,
    updateDeliveryStatus,
    verifyDeliveryOtp,
    listDeliveryPartners,
    assignDeliveryPartner
} from "../controllers/deliveryController.js";
import { protect, authorizeRoles } from "../middleware/authMiddleware.js";

const router = express.Router();

// Delivery partner routes
router.get("/assigned", protect, authorizeRoles("delivery"), getAssignedDeliveries);
router.get("/history", protect, authorizeRoles("delivery"), getDeliveryHistory);
router.put("/:id/accept", protect, authorizeRoles("delivery"), acceptDelivery);
router.put("/:id/status", protect, authorizeRoles("delivery"), updateDeliveryStatus);
router.put("/:id/verify-otp", protect, authorizeRoles("delivery"), verifyDeliveryOtp);

// Admin routes
router.get("/partners", protect, authorizeRoles("admin"), listDeliveryPartners);
router.put("/assign/:orderId", protect, authorizeRoles("admin"), assignDeliveryPartner);

export default router;
