import mongoose from "mongoose";
import InventoryBatch from "../models/InventoryBatch.js";
import Medicine from "../models/Medicine.js";

const NEAR_EXPIRY_DAYS = 30;

// POST /api/inventory/batches
export const createBatch = async (req, res) => {
    try {
        const {
            medicineId, batchNumber, manufacturingDate, expiryDate,
            quantity, purchasePrice, sellingPrice, supplier, pharmacyName
        } = req.body;

        if (!mongoose.Types.ObjectId.isValid(medicineId)) {
            return res.status(400).json({ success: false, message: "Invalid medicine ID" });
        }

        const medicine = await Medicine.findById(medicineId);
        if (!medicine) {
            return res.status(404).json({ success: false, message: "Medicine not found" });
        }

        if (new Date(expiryDate) <= new Date(manufacturingDate)) {
            return res.status(400).json({ success: false, message: "Expiry date must be after manufacturing date" });
        }

        const batch = await InventoryBatch.create({
            medicineId, batchNumber, manufacturingDate, expiryDate,
            quantity, purchasePrice, sellingPrice,
            supplier: supplier || "", pharmacyName: pharmacyName || ""
        });

        return res.status(201).json({ success: true, message: "Batch created", batch });
    } catch (error) {
        return res.status(500).json({ success: false, message: "Failed to create batch", error: error.message });
    }
};

// GET /api/inventory/batches/:medicineId
export const getBatchesForMedicine = async (req, res) => {
    try {
        const batches = await InventoryBatch.find({ medicineId: req.params.medicineId }).sort({ expiryDate: 1 });
        return res.status(200).json({ success: true, count: batches.length, batches });
    } catch (error) {
        return res.status(500).json({ success: false, message: "Failed to fetch batches", error: error.message });
    }
};

// GET /api/inventory/overview  — dashboard summary, all real Mongo queries
export const getInventoryOverview = async (req, res) => {
    try {
        const now = new Date();
        const nearExpiryDate = new Date(now.getTime() + NEAR_EXPIRY_DAYS * 86400000);

        const [expiredBatches, nearExpiryBatches, lowStockMedicines, outOfStockMedicines] = await Promise.all([
            InventoryBatch.find({ expiryDate: { $lt: now }, status: "Active", quantity: { $gt: 0 } })
                .populate("medicineId", "name"),
            InventoryBatch.find({ expiryDate: { $gte: now, $lte: nearExpiryDate }, status: "Active", quantity: { $gt: 0 } })
                .populate("medicineId", "name"),
            Medicine.find({ stock: { $gt: 0, $lte: 10 } }).select("name stock"),
            Medicine.find({ stock: { $lte: 0 } }).select("name stock")
        ]);

        return res.status(200).json({
            success: true,
            expiredBatches,
            nearExpiryBatches,
            lowStockMedicines,
            outOfStockMedicines
        });
    } catch (error) {
        return res.status(500).json({ success: false, message: "Failed to fetch inventory overview", error: error.message });
    }
};

// PUT /api/inventory/batches/:id/adjust
export const adjustStock = async (req, res) => {
    try {
        const { quantityChange, reason } = req.body;

        const batch = await InventoryBatch.findById(req.params.id);
        if (!batch) {
            return res.status(404).json({ success: false, message: "Batch not found" });
        }

        const newQuantity = batch.quantity + Number(quantityChange);
        if (newQuantity < 0) {
            return res.status(400).json({ success: false, message: "Adjustment would make quantity negative" });
        }

        batch.quantity = newQuantity;
        if (newQuantity === 0) batch.status = "Depleted";
        await batch.save();

        return res.status(200).json({ success: true, message: `Stock adjusted (${reason || "manual"})`, batch });
    } catch (error) {
        return res.status(500).json({ success: false, message: "Failed to adjust stock", error: error.message });
    }
};
