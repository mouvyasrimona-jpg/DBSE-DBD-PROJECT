import Prescription from "../models/Prescription.js";
import PrescriptionAudit from "../models/PrescriptionAudit.js";
import Medicine from "../models/Medicine.js";
import { createNotification } from "./notificationController.js";

// =====================================================
// SIMULATED OCR ENGINE — clearly labeled as simulated, not real
// OCR (Tesseract.js isn't installed). Extended for feature 1 to
// return structured fields instead of just raw text.
// =====================================================
const runOcrEngine = () => {
    const samples = [
        {
            patientName: "Rahul Verma",
            doctorName: "Dr. A. Sharma (MD)",
            daysAgo: 3,
            medicines: [
                { name: "Paracetamol 500mg", dosage: "500mg", frequency: "Twice daily", duration: "5 days", confidence: 92 },
                { name: "Amoxicillin 250mg", dosage: "250mg", frequency: "Thrice daily", duration: "7 days", confidence: 88 },
                { name: "Cetirizine 10mg", dosage: "10mg", frequency: "Once daily", duration: "5 days", confidence: 81 }
            ]
        },
        {
            patientName: "Sunita Rao",
            doctorName: "Dr. R. K. Varma (Cardiologist)",
            daysAgo: 45,
            medicines: [
                { name: "Atorvastatin 10mg", dosage: "10mg", frequency: "Once daily", duration: "30 days", confidence: 90 },
                { name: "Metformin 500mg", dosage: "500mg", frequency: "Twice daily", duration: "30 days", confidence: 85 }
            ]
        },
        {
            patientName: "Vikram Reddy",
            doctorName: "Dr. P. Mehta",
            daysAgo: 1,
            medicines: [
                { name: "Pantoprazole 40mg", dosage: "40mg", frequency: "Once daily", duration: "14 days", confidence: 77 },
                { name: "Dolo 650mg", dosage: "650mg", frequency: "As needed", duration: "5 days", confidence: 65 }
            ]
        }
    ];

    const sample = samples[Math.floor(Math.random() * samples.length)];
    const prescriptionDate = new Date(Date.now() - sample.daysAgo * 86400000);

    const ocrText =
        `Rx Prescribed by ${sample.doctorName} for ${sample.patientName}. ` +
        `Date: ${prescriptionDate.toDateString()}. Recommended: ` +
        sample.medicines.map((m) => `${m.name} (${m.frequency}, ${m.duration})`).join(", ") + ".";

    return {
        ocrText,
        patientName: sample.patientName,
        doctorName: sample.doctorName,
        prescriptionDate,
        medicines: sample.medicines
    };
};

// =====================================================
// MEDICINE MATCHING — compares OCR-detected medicine names
// against the REAL Medicine collection.
// =====================================================
const matchDetectedMedicines = async (detectedMedicines) => {
    const allMedicines = await Medicine.find().select("name stock");
    const results = [];

    for (const detectedName of detectedMedicines) {
        const normalizedDetected = detectedName.toLowerCase().trim();

        const exactMatch = allMedicines.find(
            (m) => m.name.toLowerCase().trim() === normalizedDetected
        );

        if (exactMatch) {
            results.push({
                detectedName,
                matchType: exactMatch.stock > 0 ? "exact" : "unavailable",
                matchedMedicineId: exactMatch._id,
                matchedMedicineName: exactMatch.name
            });
            continue;
        }

        const coreWord = normalizedDetected.split(" ")[0];
        const partialMatch = allMedicines.find((m) =>
            m.name.toLowerCase().includes(coreWord)
        );

        if (partialMatch) {
            results.push({
                detectedName,
                matchType: "partial",
                matchedMedicineId: partialMatch._id,
                matchedMedicineName: partialMatch.name
            });
            continue;
        }

        results.push({
            detectedName,
            matchType: "unknown",
            matchedMedicineId: null,
            matchedMedicineName: ""
        });
    }

    return results;
};

// =====================================================
// UPLOAD PRESCRIPTION WITH OCR + INTELLIGENCE
// POST /api/prescriptions/upload
// =====================================================
export const uploadPrescription = async (req, res) => {
    try {
        if (!req.user || !req.user.userId) {
            return res.status(401).json({ success: false, message: "Authentication required" });
        }

        if (!req.file) {
            return res.status(400).json({ success: false, message: "Prescription file is required" });
        }

        const prescription = await Prescription.create({
            userId: req.user.userId,
            originalName: req.file.originalname,
            fileName: req.file.filename,
            filePath: `/uploads/${req.file.filename}`,
            status: "Pending"
        });

        await PrescriptionAudit.create({
            prescriptionId: prescription._id,
            action: "Uploaded",
            performedBy: req.user.userId,
            performedByRole: req.user.role || "customer"
        });

        const ocrResult = runOcrEngine();
        const detectedNames = ocrResult.medicines.map((m) => m.name);

        await PrescriptionAudit.create({
            prescriptionId: prescription._id,
            action: "OCR_Completed",
            performedByRole: "system",
            metadata: { medicineCount: detectedNames.length }
        });

        const matchResults = await matchDetectedMedicines(detectedNames);

        await PrescriptionAudit.create({
            prescriptionId: prescription._id,
            action: "Medicines_Detected",
            performedByRole: "system",
            metadata: { matches: matchResults.map((m) => m.matchType) }
        });

        const daysSincePrescription = ocrResult.prescriptionDate
            ? Math.floor((Date.now() - new Date(ocrResult.prescriptionDate).getTime()) / 86400000)
            : null;
        const isExpired = daysSincePrescription === null || daysSincePrescription > 30;

        const overallConfidence = Math.round(
            ocrResult.medicines.reduce((sum, m) => sum + m.confidence, 0) / ocrResult.medicines.length
        );

        const hasUnknownMatch = matchResults.some((m) => m.matchType === "unknown");
        const needsManualReview = isExpired || overallConfidence < 80 || hasUnknownMatch;

        prescription.ocrDetectedText = ocrResult.ocrText;
        prescription.detectedMedicines = detectedNames;
        prescription.extractedInfo = {
            patientName: ocrResult.patientName,
            doctorName: ocrResult.doctorName,
            prescriptionDate: ocrResult.prescriptionDate,
            medicines: ocrResult.medicines
        };
        prescription.medicineMatchResults = matchResults;
        prescription.isExpired = isExpired;
        prescription.overallConfidence = overallConfidence;
        prescription.needsManualReview = needsManualReview;
        await prescription.save();

        await PrescriptionAudit.create({
            prescriptionId: prescription._id,
            action: "Validation_Result",
            performedByRole: "system",
            metadata: { isExpired, overallConfidence, needsManualReview }
        });

        return res.status(201).json({
            success: true,
            message: "Prescription uploaded successfully. OCR scan complete.",
            prescription
        });

    } catch (error) {
        console.error("Prescription upload error:", error);
        return res.status(500).json({ success: false, message: "Prescription upload failed", error: error.message });
    }
};

export const getMyPrescriptions = async (req, res) => {
    try {
        if (!req.user || !req.user.userId) {
            return res.status(401).json({ success: false, message: "Authentication required" });
        }
        const prescriptions = await Prescription.find({ userId: req.user.userId }).sort({ createdAt: -1 });
        return res.status(200).json({ success: true, count: prescriptions.length, prescriptions });
    } catch (error) {
        return res.status(500).json({ success: false, message: "Failed to fetch prescriptions" });
    }
};

export const getAllPrescriptions = async (req, res) => {
    try {
        const prescriptions = await Prescription.find()
            .populate("userId", "name email")
            .sort({ createdAt: -1 });
        return res.status(200).json({ success: true, count: prescriptions.length, prescriptions });
    } catch (error) {
        return res.status(500).json({ success: false, message: "Failed to fetch prescriptions" });
    }
};

export const getPrescriptionAudit = async (req, res) => {
    try {
        const events = await PrescriptionAudit.find({ prescriptionId: req.params.id })
            .populate("performedBy", "name role")
            .sort({ createdAt: 1 });
        return res.status(200).json({ success: true, count: events.length, events });
    } catch (error) {
        return res.status(500).json({ success: false, message: "Failed to fetch audit trail", error: error.message });
    }
};

export const updatePrescriptionStatus = async (req, res) => {
    try {
        const { status, rejectionReason } = req.body;

        if (!["Approved", "Rejected", "Pending"].includes(status)) {
            return res.status(400).json({ success: false, message: "Invalid prescription status" });
        }

        if (status === "Rejected" && (!rejectionReason || rejectionReason.trim() === "")) {
            return res.status(400).json({ success: false, message: "A rejection reason is required when rejecting a prescription" });
        }

        const prescription = await Prescription.findByIdAndUpdate(
            req.params.id,
            { status, rejectionReason: rejectionReason || "" },
            { new: true }
        ).populate("userId", "name email");

        if (!prescription) {
            return res.status(404).json({ success: false, message: "Prescription not found" });
        }

        await PrescriptionAudit.create({
            prescriptionId: prescription._id,
            action: status === "Approved" ? "Approved" : status === "Rejected" ? "Rejected" : "Modified",
            performedBy: req.user.userId,
            performedByRole: req.user.role || "pharmacist",
            reason: rejectionReason || ""
        });

        if (status === "Approved") {
            await createNotification({
                userId: prescription.userId._id,
                type: "prescription_approved",
                title: "Prescription approved",
                message: "Your prescription has been approved. You can now order the prescribed medicines.",
                relatedId: prescription._id
            });
        } else if (status === "Rejected") {
            await createNotification({
                userId: prescription.userId._id,
                type: "prescription_rejected",
                title: "Prescription rejected",
                message: `Your prescription was rejected: ${rejectionReason}`,
                relatedId: prescription._id
            });
        }

        return res.status(200).json({ success: true, message: `Prescription status updated to ${status}`, prescription });
    } catch (error) {
        console.error("Update prescription status error:", error);
        return res.status(500).json({ success: false, message: "Failed to update prescription status" });
    }
};
