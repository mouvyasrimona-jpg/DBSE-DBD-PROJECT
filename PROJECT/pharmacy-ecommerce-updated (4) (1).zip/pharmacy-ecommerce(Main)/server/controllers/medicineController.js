import mongoose from "mongoose";
import Medicine from "../models/Medicine.js";

// =====================================================
// GET ALL MEDICINES
// GET /api/medicines
// =====================================================

export const getMedicines = async (req, res) => {
    try {
        const {
            search,
            category,
            prescriptionRequired
        } = req.query;

        const filter = {};

        // Search by medicine name
        if (search && search.trim() !== "") {
            filter.name = {
                $regex: search.trim(),
                $options: "i"
            };
        }

        // Filter by category
        if (category && category.trim() !== "") {
            filter.category = category.trim();
        }

        // Filter prescription medicines
        if (prescriptionRequired !== undefined) {
            filter.prescriptionRequired =
                prescriptionRequired === "true";
        }

        const medicines = await Medicine.find(filter)
            .sort({ createdAt: -1 });

        return res.status(200).json({
            success: true,
            count: medicines.length,
            medicines
        });

    } catch (error) {
        console.error("GET MEDICINES ERROR:", error);

        return res.status(500).json({
            success: false,
            message: "Failed to fetch medicines",
            error: error.message
        });
    }
};


// =====================================================
// SEARCH MEDICINES
// GET /api/medicines/search?query=paracetamol
// =====================================================

export const searchMedicines = async (req, res) => {
    try {
        const {
            query,
            minPrice, maxPrice,
            prescriptionRequired,
            minRating,
            availableOnly,
            sort
        } = req.query;

        if (!query || query.trim() === "") {
            return res.status(400).json({
                success: false,
                message: "Search query is required"
            });
        }

        const regex = {
            $regex: query.trim(),
            $options: "i" // case-insensitive
        };

        // Advanced Search (feature 13) — matches across name,
        // description, brand, genericName, category and composition
        const filter = {
            $or: [
                { name: regex },
                { description: regex },
                { brand: regex },
                { genericName: regex },
                { category: regex },
                { composition: regex }
            ]
        };

        if (minPrice || maxPrice) {
            filter.price = {};
            if (minPrice) filter.price.$gte = Number(minPrice);
            if (maxPrice) filter.price.$lte = Number(maxPrice);
        }

        if (prescriptionRequired !== undefined) {
            filter.prescriptionRequired = prescriptionRequired === "true";
        }

        if (minRating) {
            filter.rating = { $gte: Number(minRating) };
        }

        if (availableOnly === "true") {
            filter.stock = { $gt: 0 };
        }

        let sortOption = { createdAt: -1 }; // default: relevance-ish (newest)
        if (sort === "price_asc") sortOption = { price: 1 };
        if (sort === "price_desc") sortOption = { price: -1 };
        if (sort === "rating") sortOption = { rating: -1 };

        const medicines = await Medicine.find(filter).sort(sortOption);

        return res.status(200).json({
            success: true,
            count: medicines.length,
            medicines
        });

    } catch (error) {
        console.error("SEARCH MEDICINES ERROR:", error);

        return res.status(500).json({
            success: false,
            message: "Failed to search medicines",
            error: error.message
        });
    }
};

// GET /api/medicines/autocomplete?query=dol
// Lightweight — just names, for a fast-typing suggestion dropdown
export const autocompleteMedicines = async (req, res) => {
    try {
        const { query } = req.query;
        if (!query || query.trim().length < 2) {
            return res.status(200).json({ success: true, suggestions: [] });
        }

        const regex = { $regex: query.trim(), $options: "i" };
        const medicines = await Medicine.find({
            $or: [{ name: regex }, { brand: regex }, { genericName: regex }]
        })
            .select("name brand category price prescriptionRequired")
            .limit(8);

        return res.status(200).json({ success: true, suggestions: medicines });
    } catch (error) {
        return res.status(500).json({ success: false, message: "Autocomplete failed", error: error.message });
    }
};


// =====================================================
// GET SINGLE MEDICINE
// GET /api/medicines/:id
// =====================================================

export const getMedicineById = async (req, res) => {
    try {
        const { id } = req.params;

        // Validate MongoDB ID
        if (!mongoose.Types.ObjectId.isValid(id)) {
            return res.status(400).json({
                success: false,
                message: "Invalid medicine ID"
            });
        }

        const medicine = await Medicine.findById(id);

        if (!medicine) {
            return res.status(404).json({
                success: false,
                message: "Medicine not found"
            });
        }

        const medicineObj = medicine.toObject();
        if (!medicineObj.availableShops || medicineObj.availableShops.length === 0) {
            medicineObj.availableShops = [
                {
                    shopName: "Apollo Pharmacy - Metro Hub",
                    location: "100ft Ring Road, Central Plaza",
                    distance: "0.8 km away",
                    stock: Math.max(5, Math.floor((medicine.stock || 20) * 0.4) || 12),
                    rating: 4.9,
                    deliveryTime: "25 mins Express",
                    openHours: "24/7 Open"
                },
                {
                    shopName: "MedPlus Chemist & Druggist",
                    location: "Crossroads Avenue, Block B",
                    distance: "1.4 km away",
                    stock: Math.max(3, Math.floor((medicine.stock || 20) * 0.3) || 8),
                    rating: 4.7,
                    deliveryTime: "40 mins",
                    openHours: "8:00 AM - 11:30 PM"
                },
                {
                    shopName: "PharmaCare Flagship Dispensary",
                    location: "Health City Boulevard",
                    distance: "2.1 km away",
                    stock: Math.max(10, Math.floor((medicine.stock || 20) * 0.6) || 25),
                    rating: 5.0,
                    deliveryTime: "30 mins Express",
                    openHours: "24/7 Open"
                },
                {
                    shopName: "Wellness Forever 24x7 Chemist",
                    location: "Commercial Square Sector 4",
                    distance: "2.8 km away",
                    stock: Math.max(4, Math.floor((medicine.stock || 20) * 0.25) || 10),
                    rating: 4.8,
                    deliveryTime: "1 hour",
                    openHours: "24/7 Open"
                }
            ];
        }

        return res.status(200).json({
            success: true,
            medicine: medicineObj
        });

    } catch (error) {
        console.error("GET MEDICINE ERROR:", error);

        return res.status(500).json({
            success: false,
            message: "Failed to fetch medicine",
            error: error.message
        });
    }
};


// =====================================================
// CREATE MEDICINE
// POST /api/medicines
// =====================================================

export const createMedicine = async (req, res) => {
    try {
        const {
            name,
            genericName,
            brand,
            condition,
            description,
            price,
            stock,
            category,
            therapeuticCategory,
            dosage,
            form,
            image,
            prescriptionRequired,
            manufacturer
        } = req.body;

        // Basic validation
        if (!name || name.trim() === "") {
            return res.status(400).json({
                success: false,
                message: "Medicine name is required"
            });
        }

        if (price === undefined || price === null || price === "") {
            return res.status(400).json({
                success: false,
                message: "Medicine price is required"
            });
        }

        if (stock === undefined || stock === null || stock === "") {
            return res.status(400).json({
                success: false,
                message: "Medicine stock is required"
            });
        }

        const medicinePrice = Number(price);
        const medicineStock = Number(stock);

        if (Number.isNaN(medicinePrice) || medicinePrice < 0) {
            return res.status(400).json({
                success: false,
                message: "Price must be a valid positive number"
            });
        }

        if (
            Number.isNaN(medicineStock) ||
            medicineStock < 0 ||
            !Number.isInteger(medicineStock)
        ) {
            return res.status(400).json({
                success: false,
                message: "Stock must be a valid non-negative integer"
            });
        }

        const medicine = await Medicine.create({
            name: name.trim(),
            genericName: genericName || "",
            brand: brand || "",
            condition: condition || "",
            description: description || "",
            price: medicinePrice,
            stock: medicineStock,
            category: category || "General",
            therapeuticCategory: therapeuticCategory || category || "General",
            dosage: dosage || "",
            form: form || "",
            image: image || "",
            prescriptionRequired:
                prescriptionRequired === true ||
                prescriptionRequired === "true",
            manufacturer: manufacturer || ""
        });

        return res.status(201).json({
            success: true,
            message: "Medicine created successfully",
            medicine
        });

    } catch (error) {
        console.error("CREATE MEDICINE ERROR:", error);

        return res.status(500).json({
            success: false,
            message: "Failed to create medicine",
            error: error.message
        });
    }
};


// =====================================================
// UPDATE MEDICINE
// PUT /api/medicines/:id
// =====================================================

export const updateMedicine = async (req, res) => {
    try {
        const { id } = req.params;

        if (!mongoose.Types.ObjectId.isValid(id)) {
            return res.status(400).json({
                success: false,
                message: "Invalid medicine ID"
            });
        }

        const medicine = await Medicine.findById(id);

        if (!medicine) {
            return res.status(404).json({
                success: false,
                message: "Medicine not found"
            });
        }

        const {
            name,
            description,
            price,
            stock,
            category,
            therapeuticCategory,
            image,
            prescriptionRequired,
            manufacturer
        } = req.body;

        if (name !== undefined) {
            medicine.name = name.trim();
        }

        if (description !== undefined) {
            medicine.description = description;
        }

        if (price !== undefined) {
            const newPrice = Number(price);

            if (Number.isNaN(newPrice) || newPrice < 0) {
                return res.status(400).json({
                    success: false,
                    message: "Price must be a valid positive number"
                });
            }

            medicine.price = newPrice;
        }

        if (stock !== undefined) {
            const newStock = Number(stock);

            if (
                Number.isNaN(newStock) ||
                newStock < 0 ||
                !Number.isInteger(newStock)
            ) {
                return res.status(400).json({
                    success: false,
                    message: "Stock must be a valid non-negative integer"
                });
            }

            medicine.stock = newStock;
        }

        if (category !== undefined) {
            medicine.category = category;
        }

        if (therapeuticCategory !== undefined) {
            medicine.therapeuticCategory = therapeuticCategory;
        }

        if (image !== undefined) {
            medicine.image = image;
        }

        if (prescriptionRequired !== undefined) {
            medicine.prescriptionRequired =
                prescriptionRequired === true ||
                prescriptionRequired === "true";
        }

        if (manufacturer !== undefined) {
            medicine.manufacturer = manufacturer;
        }

        await medicine.save();

        return res.status(200).json({
            success: true,
            message: "Medicine updated successfully",
            medicine
        });

    } catch (error) {
        console.error("UPDATE MEDICINE ERROR:", error);

        return res.status(500).json({
            success: false,
            message: "Failed to update medicine",
            error: error.message
        });
    }
};


// =====================================================
// DELETE MEDICINE
// DELETE /api/medicines/:id
// =====================================================

export const deleteMedicine = async (req, res) => {
    try {
        const { id } = req.params;

        if (!mongoose.Types.ObjectId.isValid(id)) {
            return res.status(400).json({
                success: false,
                message: "Invalid medicine ID"
            });
        }

        const medicine = await Medicine.findById(id);

        if (!medicine) {
            return res.status(404).json({
                success: false,
                message: "Medicine not found"
            });
        }

        await Medicine.findByIdAndDelete(id);

        return res.status(200).json({
            success: true,
            message: "Medicine deleted successfully"
        });

    } catch (error) {
        console.error("DELETE MEDICINE ERROR:", error);

        return res.status(500).json({
            success: false,
            message: "Failed to delete medicine",
            error: error.message
        });
    }
};


// =====================================================
// GET SUBSTITUTE MEDICINES
// GET /api/medicines/:id/substitutes
// =====================================================

export const getSubstituteMedicines = async (req, res) => {
    try {
        const { id } = req.params;

        if (!mongoose.Types.ObjectId.isValid(id)) {
            return res.status(400).json({
                success: false,
                message: "Invalid medicine ID"
            });
        }

        const medicine = await Medicine.findById(id);

        if (!medicine) {
            return res.status(404).json({
                success: false,
                message: "Medicine not found"
            });
        }

        const filter = {
            _id: { $ne: medicine._id },
            stock: { $gt: 0 }
        };

        // Match by therapeutic purpose (e.g. "Pain Relief"),
        // not the general category field
        if (medicine.therapeuticCategory) {
            filter.therapeuticCategory = medicine.therapeuticCategory;
        } else if (medicine.category) {
            // fallback for older records that don't have
            // therapeuticCategory set yet
            filter.category = medicine.category;
        }

        const substitutes = await Medicine.find(filter)
            .limit(6)
            .sort({ price: 1 });

        return res.status(200).json({
            success: true,
            count: substitutes.length,
            substitutes
        });

    } catch (error) {
        console.error(
            "GET SUBSTITUTE MEDICINES ERROR:",
            error
        );

        return res.status(500).json({
            success: false,
            message: "Failed to fetch substitute medicines",
            error: error.message
        });
    }
};
// GET /api/medicines/popular — real order-derived popularity,
// safe for public display (no revenue/customer data exposed,
// unlike the admin analytics equivalent).
export const getPopularMedicines = async (req, res) => {
    try {
        const Order = (await import("../models/Order.js")).default;

        const popular = await Order.aggregate([
            { $unwind: "$items" },
            { $group: { _id: "$items.medicineId", totalOrdered: { $sum: "$items.quantity" } } },
            { $sort: { totalOrdered: -1 } },
            { $limit: 8 }
        ]);

        const medicineIds = popular.map((p) => p._id);
        const medicines = await Medicine.find({ _id: { $in: medicineIds }, stock: { $gt: 0 } });

        if (medicines.length === 0) {
            const fallback = await Medicine.find({ stock: { $gt: 0 } }).sort({ rating: -1 }).limit(8);
            return res.status(200).json({ success: true, medicines: fallback, source: "top-rated" });
        }

        return res.status(200).json({ success: true, medicines, source: "order-history" });
    } catch (error) {
        return res.status(500).json({ success: false, message: "Failed to fetch popular medicines", error: error.message });
    }
};

// GET /api/medicines/categories — real distinct category values
// actually present in the database, so category links on the
// homepage never point at an empty result.
export const getMedicineCategories = async (req, res) => {
    try {
        const categories = await Medicine.distinct("category");
        return res.status(200).json({ success: true, categories: categories.filter(Boolean) });
    } catch (error) {
        return res.status(500).json({ success: false, message: "Failed to fetch categories", error: error.message });
    }
};
