import mongoose from "mongoose";
import Review from "../models/Review.js";
import Order from "../models/Order.js";
import Medicine from "../models/Medicine.js";

// POST /api/reviews
export const createReview = async (req, res) => {
    try {
        const { orderId, medicineId, rating, comment } = req.body;

        if (!mongoose.Types.ObjectId.isValid(orderId) || !mongoose.Types.ObjectId.isValid(medicineId)) {
            return res.status(400).json({ success: false, message: "Invalid order or medicine ID" });
        }

        if (!rating || rating < 1 || rating > 5) {
            return res.status(400).json({ success: false, message: "Rating must be between 1 and 5" });
        }

        // Only allow reviewing an item the customer actually
        // received, from their own delivered order.
        const order = await Order.findOne({
            _id: orderId,
            userId: req.user.userId,
            status: "Delivered"
        });

        if (!order) {
            return res.status(403).json({
                success: false,
                message: "You can only review medicines from your own delivered orders"
            });
        }

        const purchasedThisMedicine = order.items.some(
            (item) => String(item.medicineId) === String(medicineId)
        );

        if (!purchasedThisMedicine) {
            return res.status(403).json({ success: false, message: "This medicine was not part of that order" });
        }

        const review = await Review.create({
            userId: req.user.userId,
            orderId,
            medicineId,
            rating,
            comment: comment || ""
        });

        // Recalculate the medicine's aggregate rating from real
        // review data — never hardcoded.
        const agg = await Review.aggregate([
            { $match: { medicineId: new mongoose.Types.ObjectId(medicineId) } },
            { $group: { _id: "$medicineId", avgRating: { $avg: "$rating" }, count: { $sum: 1 } } }
        ]);

        if (agg.length > 0) {
            await Medicine.findByIdAndUpdate(medicineId, {
                rating: Math.round(agg[0].avgRating * 10) / 10,
                reviewCount: agg[0].count
            });
        }

        return res.status(201).json({ success: true, message: "Review submitted", review });

    } catch (error) {
        if (error.code === 11000) {
            return res.status(409).json({ success: false, message: "You already reviewed this medicine for this order" });
        }
        return res.status(500).json({ success: false, message: "Failed to submit review", error: error.message });
    }
};

// GET /api/reviews/medicine/:medicineId
export const getReviewsForMedicine = async (req, res) => {
    try {
        const reviews = await Review.find({ medicineId: req.params.medicineId })
            .populate("userId", "name")
            .sort({ createdAt: -1 });

        return res.status(200).json({ success: true, count: reviews.length, reviews });
    } catch (error) {
        return res.status(500).json({ success: false, message: "Failed to fetch reviews", error: error.message });
    }
};

// GET /api/reviews/eligible/:orderId — which items in this order can still be reviewed
export const getEligibleReviewItems = async (req, res) => {
    try {
        const order = await Order.findOne({
            _id: req.params.orderId,
            userId: req.user.userId,
            status: "Delivered"
        });

        if (!order) {
            return res.status(200).json({ success: true, eligibleItems: [] });
        }

        const existingReviews = await Review.find({ orderId: order._id, userId: req.user.userId });
        const reviewedIds = new Set(existingReviews.map((r) => String(r.medicineId)));

        const eligibleItems = order.items
            .filter((item) => !reviewedIds.has(String(item.medicineId)))
            .map((item) => ({ medicineId: item.medicineId, name: item.name }));

        return res.status(200).json({ success: true, eligibleItems });
    } catch (error) {
        return res.status(500).json({ success: false, message: "Failed to check review eligibility", error: error.message });
    }
};
