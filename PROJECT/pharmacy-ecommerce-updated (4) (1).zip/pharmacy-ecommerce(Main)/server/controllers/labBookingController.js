import mongoose from "mongoose";
import LabBooking from "../models/LabBooking.js";
import LabTest from "../models/LabTest.js";
import LabCenter from "../models/LabCenter.js";
import { createNotification } from "./notificationController.js";

// Fixed, realistic collection windows — not fabricated per-center
// capacity data, just genuine scheduling options.
const TIME_SLOTS = [
    "07:00 AM - 09:00 AM",
    "09:00 AM - 11:00 AM",
    "11:00 AM - 01:00 PM",
    "04:00 PM - 06:00 PM",
    "06:00 PM - 08:00 PM"
];

// GET /api/lab-bookings/available-slots?date=YYYY-MM-DD
// Returns the fixed slot list, minus any slot that's already at
// capacity for that date (real check against existing bookings —
// not just decorative).
export const getAvailableSlots = async (req, res) => {
    try {
        const { date } = req.query;
        if (!date) {
            return res.status(400).json({ success: false, message: "Date is required" });
        }

        const dayStart = new Date(date);
        dayStart.setHours(0, 0, 0, 0);
        const dayEnd = new Date(date);
        dayEnd.setHours(23, 59, 59, 999);

        const existingCounts = await LabBooking.aggregate([
            { $match: { bookingDate: { $gte: dayStart, $lte: dayEnd }, bookingStatus: { $ne: "Cancelled" } } },
            { $group: { _id: "$timeSlot", count: { $sum: 1 } } }
        ]);

        const CAPACITY_PER_SLOT = 20;
        const countMap = Object.fromEntries(existingCounts.map((c) => [c._id, c.count]));

        const slots = TIME_SLOTS.map((slot) => ({
            slot,
            available: (countMap[slot] || 0) < CAPACITY_PER_SLOT
        }));

        return res.status(200).json({ success: true, slots });
    } catch (error) {
        return res.status(500).json({ success: false, message: "Failed to fetch available slots", error: error.message });
    }
};

// Generates a real, unique booking ID — never hardcoded.
const generateBookingId = () => {
    const year = new Date().getFullYear();
    const random = Math.floor(100000 + Math.random() * 900000);
    return `LAB-PC-${year}-${random}`;
};

// POST /api/lab-bookings
export const createBooking = async (req, res) => {
    try {
        const { testId, patient, collectionType, centerId, homeAddress, bookingDate, timeSlot } = req.body;

        if (!mongoose.Types.ObjectId.isValid(testId)) {
            return res.status(400).json({ success: false, message: "Invalid lab test ID" });
        }

        const test = await LabTest.findById(testId);
        if (!test || !test.active) {
            return res.status(404).json({ success: false, message: "Lab test not found or unavailable" });
        }

        if (!patient?.name || !patient?.age || !patient?.gender) {
            return res.status(400).json({ success: false, message: "Patient name, age and gender are required" });
        }

        if (!["Home", "Center"].includes(collectionType)) {
            return res.status(400).json({ success: false, message: "Collection type must be Home or Center" });
        }

        if (collectionType === "Center") {
            if (!mongoose.Types.ObjectId.isValid(centerId)) {
                return res.status(400).json({ success: false, message: "A valid lab center must be selected" });
            }
            const center = await LabCenter.findById(centerId);
            if (!center) {
                return res.status(404).json({ success: false, message: "Lab center not found" });
            }
        } else if (!homeAddress || !homeAddress.trim()) {
            return res.status(400).json({ success: false, message: "Home address is required for home collection" });
        }

        if (!bookingDate || !timeSlot) {
            return res.status(400).json({ success: false, message: "Booking date and time slot are required" });
        }

        // Generate a bookingId, retrying on the rare collision
        let bookingId = generateBookingId();
        let attempts = 0;
        while (await LabBooking.findOne({ bookingId }) && attempts < 5) {
            bookingId = generateBookingId();
            attempts++;
        }

        const booking = await LabBooking.create({
            bookingId,
            userId: req.user.userId,
            testId: test._id,
            testName: test.name,
            price: Math.round(test.price * (1 - (test.discountPercent || 0) / 100)),
            patient,
            collectionType,
            centerId: collectionType === "Center" ? centerId : null,
            homeAddress: collectionType === "Home" ? homeAddress.trim() : "",
            bookingDate,
            timeSlot,
            bookingStatus: "Confirmed"
        });

        await createNotification({
            userId: req.user.userId,
            type: "order_confirmed",
            title: "Lab test booked",
            message: `Your booking ${bookingId} for ${test.name} is confirmed.`,
            relatedId: booking._id
        });

        return res.status(201).json({ success: true, message: "Lab test booked successfully", booking });
    } catch (error) {
        console.error("CREATE LAB BOOKING ERROR:", error);
        return res.status(500).json({ success: false, message: "Failed to create booking", error: error.message });
    }
};

// GET /api/lab-bookings/my
export const getMyBookings = async (req, res) => {
    try {
        const bookings = await LabBooking.find({ userId: req.user.userId })
            .populate("centerId", "name address")
            .sort({ createdAt: -1 });
        return res.status(200).json({ success: true, count: bookings.length, bookings });
    } catch (error) {
        return res.status(500).json({ success: false, message: "Failed to fetch bookings", error: error.message });
    }
};

// GET /api/lab-bookings/:id
export const getBookingById = async (req, res) => {
    try {
        let query = { _id: req.params.id };
        if (req.user.role !== "admin" && req.user.role !== "pharmacist") {
            query.userId = req.user.userId;
        }
        const booking = await LabBooking.findOne(query).populate("centerId", "name address phone");
        if (!booking) {
            return res.status(404).json({ success: false, message: "Booking not found" });
        }
        return res.status(200).json({ success: true, booking });
    } catch (error) {
        return res.status(500).json({ success: false, message: "Failed to fetch booking", error: error.message });
    }
};

// GET /api/lab-bookings  (admin/pharmacist)
export const getAllBookings = async (req, res) => {
    try {
        const bookings = await LabBooking.find()
            .populate("userId", "name email")
            .populate("centerId", "name")
            .sort({ createdAt: -1 });
        return res.status(200).json({ success: true, count: bookings.length, bookings });
    } catch (error) {
        return res.status(500).json({ success: false, message: "Failed to fetch bookings", error: error.message });
    }
};

// PUT /api/lab-bookings/:id/status  (admin/pharmacist)
// "ReportReady" must only ever be set here, explicitly, by staff —
// never inferred or auto-progressed, so we never claim a result
// exists before it genuinely does.
export const updateBookingStatus = async (req, res) => {
    try {
        const { status } = req.body;
        const allowed = ["Confirmed", "Scheduled", "SampleCollected", "SampleReceived", "Testing", "ReportReady", "Cancelled"];

        if (!allowed.includes(status)) {
            return res.status(400).json({ success: false, message: "Invalid booking status" });
        }

        const booking = await LabBooking.findByIdAndUpdate(req.params.id, { bookingStatus: status }, { new: true });
        if (!booking) {
            return res.status(404).json({ success: false, message: "Booking not found" });
        }

        const messages = {
            Scheduled: "Your lab test slot has been scheduled.",
            SampleCollected: "Your sample has been collected.",
            SampleReceived: "Your sample has been received at the lab.",
            Testing: "Your sample is being tested.",
            ReportReady: "Your lab report is ready to view.",
            Cancelled: "Your lab booking has been cancelled."
        };

        if (messages[status]) {
            await createNotification({
                userId: booking.userId,
                type: "order_confirmed",
                title: `Lab booking ${booking.bookingId} updated`,
                message: messages[status],
                relatedId: booking._id
            });
        }

        return res.status(200).json({ success: true, message: "Booking status updated", booking });
    } catch (error) {
        return res.status(500).json({ success: false, message: "Failed to update booking status", error: error.message });
    }
};
