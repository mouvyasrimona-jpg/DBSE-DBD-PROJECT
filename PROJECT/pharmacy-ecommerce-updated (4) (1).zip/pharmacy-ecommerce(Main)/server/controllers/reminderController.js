import Reminder from "../models/Reminder.js";
import Order from "../models/Order.js";

// GET /api/reminders
export const getMyReminders = async (req, res) => {
    try {
        const reminders = await Reminder.find({
            userId: req.user.userId,
            isActive: true
        }).sort({ refillDate: 1 });

        return res.status(200).json({ success: true, count: reminders.length, reminders });
    } catch (error) {
        return res.status(500).json({ success: false, message: "Failed to fetch reminders", error: error.message });
    }
};

// POST /api/reminders
export const createReminder = async (req, res) => {
    try {
        const { medicineName, refillDate, quantity, note, medicineId } = req.body;

        if (!medicineName || !refillDate) {
            return res.status(400).json({ success: false, message: "Medicine name and refill date are required" });
        }

        const reminder = await Reminder.create({
            userId: req.user.userId,
            medicineId: medicineId || null,
            medicineName,
            refillDate: new Date(refillDate),
            quantity: quantity || 1,
            note: note || ""
        });

        return res.status(201).json({ success: true, message: "Reminder created", reminder });
    } catch (error) {
        return res.status(500).json({ success: false, message: "Failed to create reminder", error: error.message });
    }
};

// PUT /api/reminders/:id
export const updateReminder = async (req, res) => {
    try {
        const { medicineName, refillDate, quantity, note } = req.body;

        const reminder = await Reminder.findOneAndUpdate(
            { _id: req.params.id, userId: req.user.userId },
            { $set: { medicineName, refillDate, quantity, note } },
            { new: true }
        );

        if (!reminder) {
            return res.status(404).json({ success: false, message: "Reminder not found" });
        }

        return res.status(200).json({ success: true, message: "Reminder updated", reminder });
    } catch (error) {
        return res.status(500).json({ success: false, message: "Failed to update reminder", error: error.message });
    }
};

// DELETE /api/reminders/:id
export const deleteReminder = async (req, res) => {
    try {
        const reminder = await Reminder.findOneAndUpdate(
            { _id: req.params.id, userId: req.user.userId },
            { $set: { isActive: false } },
            { new: true }
        );

        if (!reminder) {
            return res.status(404).json({ success: false, message: "Reminder not found" });
        }

        return res.status(200).json({ success: true, message: "Reminder removed" });
    } catch (error) {
        return res.status(500).json({ success: false, message: "Failed to delete reminder", error: error.message });
    }
};

// =====================================================
// PREDICTIVE REFILL
// GET /api/reminders/predictions
//
// Looks at the customer's real order history. For any medicine
// ordered 2+ times, it works out the average number of days
// between those orders and predicts the next likely refill date
// as (last order date + average gap). Medicines with only one
// past order, or that already have an active reminder, are
// skipped — there isn't enough history to predict from, or a
// reminder already exists.
// =====================================================
export const getPredictedRefills = async (req, res) => {
    try {
        const orders = await Order.find({
            userId: req.user.userId,
            status: { $ne: "Cancelled" }
        }).sort({ createdAt: 1 });

        // Group order dates per medicine
        const historyByMedicine = {};

        for (const order of orders) {
            for (const item of order.items || []) {
                const key = String(item.medicineId);
                if (!historyByMedicine[key]) {
                    historyByMedicine[key] = {
                        medicineId: item.medicineId,
                        medicineName: item.name,
                        dates: []
                    };
                }
                historyByMedicine[key].dates.push(order.createdAt);
            }
        }

        // Skip medicines that already have an active reminder,
        // so we don't suggest duplicates.
        const existingReminders = await Reminder.find({
            userId: req.user.userId,
            isActive: true
        }).select("medicineId");

        const reminderedIds = new Set(
            existingReminders.map((r) => String(r.medicineId))
        );

        const predictions = [];

        for (const key of Object.keys(historyByMedicine)) {
            const entry = historyByMedicine[key];

            if (entry.dates.length < 2) continue; // not enough history
            if (reminderedIds.has(key)) continue; // already reminded

            const sortedDates = entry.dates
                .map((d) => new Date(d).getTime())
                .sort((a, b) => a - b);

            let totalGapDays = 0;
            for (let i = 1; i < sortedDates.length; i++) {
                totalGapDays += (sortedDates[i] - sortedDates[i - 1]) / 86400000;
            }
            const avgGapDays = Math.round(totalGapDays / (sortedDates.length - 1));

            const lastOrderDate = new Date(sortedDates[sortedDates.length - 1]);
            const predictedRefillDate = new Date(lastOrderDate);
            predictedRefillDate.setDate(predictedRefillDate.getDate() + avgGapDays);

            predictions.push({
                medicineId: entry.medicineId,
                medicineName: entry.medicineName,
                orderCount: entry.dates.length,
                averageGapDays: avgGapDays,
                lastOrderDate,
                predictedRefillDate
            });
        }

        // Soonest predicted refill first
        predictions.sort(
            (a, b) => new Date(a.predictedRefillDate) - new Date(b.predictedRefillDate)
        );

        return res.status(200).json({
            success: true,
            count: predictions.length,
            predictions
        });

    } catch (error) {
        console.error("PREDICTED REFILLS ERROR:", error);
        return res.status(500).json({
            success: false,
            message: "Failed to compute predicted refills",
            error: error.message
        });
    }
};
