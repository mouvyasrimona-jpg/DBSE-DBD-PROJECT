import mongoose from "mongoose";
import Order from "../models/Order.js";
import Medicine from "../models/Medicine.js";
import Prescription from "../models/Prescription.js";
import OrderStatusHistory from "../models/OrderStatusHistory.js";
import { generateTracking, computeLiveCourierPosition } from "../utils/geoTracking.js";
import { createNotification } from "./notificationController.js";

const STATUS_NOTIFICATION_MAP = {
    Confirmed: { type: "order_confirmed", title: "Order confirmed", message: "Your order has been confirmed and will be prepared soon." },
    Preparing: { type: "order_preparing", title: "Order being prepared", message: "The pharmacy is preparing your order." },
    Packed: { type: "order_packed", title: "Order packed", message: "Your order has been packed and is ready for pickup." },
    PickedUp: { type: "order_picked_up", title: "Order picked up", message: "Your order has been picked up by the delivery partner." },
    OutForDelivery: { type: "order_out_for_delivery", title: "Out for delivery", message: "Your order is out for delivery." },
    Delivered: { type: "order_delivered", title: "Order delivered", message: "Your order has been delivered. Enjoy!" },
    Cancelled: { type: "order_cancelled", title: "Order cancelled", message: "Your order has been cancelled." }
};


// =====================================================
// HELPER
// CHECK WHETHER PRESCRIPTION CONTAINS THE MEDICINE
// =====================================================
const prescriptionContainsMedicine = (prescription, medicine) => {

    if (!prescription?.detectedMedicines?.length) {
        return false;
    }

    const medicineNames = [
        medicine.name,
        medicine.genericName
    ]
        .filter(Boolean)
        .map((name) => name.toLowerCase().trim());

    return prescription.detectedMedicines.some((detected) => {

        if (!detected) {
            return false;
        }

        const detectedText = String(detected)
            .toLowerCase()
            .trim();

        return medicineNames.some((name) => {

            return (
                detectedText.includes(name) ||
                name.includes(detectedText)
            );

        });

    });
};


// =====================================================
// CREATE ORDER
// POST /api/orders
// =====================================================
export const createOrder = async (req, res) => {

    try {

        const {
            items,
            shippingAddress,
            paymentMethod
        } = req.body;


        // =====================================================
        // AUTHENTICATION CHECK
        // =====================================================

        if (!req.user || !req.user.userId) {

            return res.status(401).json({
                success: false,
                message: "Authentication required"
            });

        }


        // =====================================================
        // USER ID VALIDATION
        // =====================================================

        if (!mongoose.Types.ObjectId.isValid(req.user.userId)) {

            return res.status(400).json({
                success: false,
                message: "Invalid user ID in token"
            });

        }


        // =====================================================
        // ITEMS VALIDATION
        // =====================================================

        if (
            !items ||
            !Array.isArray(items) ||
            items.length === 0
        ) {

            return res.status(400).json({
                success: false,
                message: "Order items are required"
            });

        }


        // =====================================================
        // SHIPPING ADDRESS VALIDATION
        // =====================================================

        if (!shippingAddress) {

            return res.status(400).json({
                success: false,
                message: "Shipping address is required"
            });

        }


        const requiredAddressFields = [
            "name",
            "phone",
            "addressLine",
            "city",
            "state",
            "pincode"
        ];


        for (const field of requiredAddressFields) {

            if (
                !shippingAddress[field] ||
                String(shippingAddress[field]).trim() === ""
            ) {

                return res.status(400).json({
                    success: false,
                    message: `${field} is required in shipping address`
                });

            }

        }


        // =====================================================
        // PAYMENT METHOD VALIDATION
        // =====================================================

        const selectedPaymentMethod =
            paymentMethod || "COD";


        if (
            !["COD", "ONLINE"].includes(
                selectedPaymentMethod
            )
        ) {

            return res.status(400).json({
                success: false,
                message: "Payment method must be COD or ONLINE"
            });

        }


        // =====================================================
        // APPROVED PRESCRIPTIONS
        //
        // IMPORTANT:
        // Fetch ALL approved prescriptions belonging
        // to the logged-in customer.
        // =====================================================

        let approvedPrescriptions = null;


        // =====================================================
        // ORDER DATA
        // =====================================================

        const orderItems = [];

        let totalAmount = 0;


        // =====================================================
        // PROCESS EACH ORDER ITEM
        // =====================================================

        for (const item of items) {


            // -------------------------------------------------
            // MEDICINE ID CHECK
            // -------------------------------------------------

            if (!item.medicineId) {

                return res.status(400).json({
                    success: false,
                    message:
                        "Medicine ID is required for each item"
                });

            }


            // -------------------------------------------------
            // MEDICINE ID FORMAT CHECK
            // -------------------------------------------------

            if (
                !mongoose.Types.ObjectId.isValid(
                    item.medicineId
                )
            ) {

                return res.status(400).json({
                    success: false,
                    message:
                        `Invalid medicine ID: ${item.medicineId}`
                });

            }


            // -------------------------------------------------
            // QUANTITY CHECK
            // -------------------------------------------------

            const quantity = Number(item.quantity);


            if (
                !Number.isInteger(quantity) ||
                quantity <= 0
            ) {

                return res.status(400).json({
                    success: false,
                    message:
                        "Quantity must be a positive integer"
                });

            }


            // -------------------------------------------------
            // GET MEDICINE FROM DATABASE
            // -------------------------------------------------

            const medicine =
                await Medicine.findById(
                    item.medicineId
                );


            if (!medicine) {

                return res.status(404).json({
                    success: false,
                    message:
                        `Medicine not found: ${item.medicineId}`
                });

            }


            // =================================================
            // PRESCRIPTION VALIDATION
            // =================================================

            if (medicine.prescriptionRequired) {


                // -------------------------------------------------
                // LOAD ALL APPROVED PRESCRIPTIONS ONCE
                // -------------------------------------------------

                if (approvedPrescriptions === null) {

                    approvedPrescriptions =
                        await Prescription.find({
                            userId: req.user.userId,
                            status: "Approved"
                        })
                        .sort({
                            createdAt: -1
                        });

                }


                // -------------------------------------------------
                // NO APPROVED PRESCRIPTION
                // -------------------------------------------------

                if (
                    approvedPrescriptions.length === 0
                ) {

                    return res.status(403).json({

                        success: false,

                        message:
                            `"${medicine.name}" requires an approved prescription. Please upload your prescription and wait for approval.`,

                        prescriptionRequired: true,

                        medicineName:
                            medicine.name,

                        reason:
                            "NO_APPROVED_PRESCRIPTION"

                    });

                }


                // -------------------------------------------------
                // CHECK ALL APPROVED PRESCRIPTIONS
                // -------------------------------------------------

                const medicineIsPrescribed =
                    approvedPrescriptions.some(
                        (prescription) =>
                            prescriptionContainsMedicine(
                                prescription,
                                medicine
                            )
                    );


                // -------------------------------------------------
                // MEDICINE NOT FOUND IN PRESCRIPTION
                // -------------------------------------------------

                if (!medicineIsPrescribed) {

                    return res.status(403).json({

                        success: false,

                        message:
                            `"${medicine.name}" is not listed in any of your approved prescriptions.`,

                        prescriptionRequired: true,

                        medicineName:
                            medicine.name,

                        reason:
                            "MEDICINE_NOT_IN_PRESCRIPTION"

                    });

                }

            }


            // =================================================
            // STOCK VALIDATION
            // =================================================

            if (medicine.stock < quantity) {

                return res.status(400).json({

                    success: false,

                    message:
                        `${medicine.name} has only ${medicine.stock} units in stock`

                });

            }


            // =================================================
            // SERVER-SIDE PRICE CALCULATION
            // =================================================

            const subtotal =
                Number(medicine.price) *
                quantity;


            // =================================================
            // ADD ITEM TO ORDER
            // =================================================

            orderItems.push({

                medicineId:
                    medicine._id,

                name:
                    medicine.name,

                price:
                    Number(medicine.price),

                quantity,

                subtotal,

                image:
                    medicine.image || "",

                // Pharmacy the customer selected for this item on
                // MedicineDetails — trusted only if it actually matches
                // one of this medicine's real availableShops entries,
                // so a tampered request can't inject a fake pharmacy.
                selectedPharmacy:
                    (() => {
                        if (!item.selectedPharmacy || !item.selectedPharmacy.shopName) {
                            return null;
                        }
                        const validShop = (medicine.availableShops || []).find(
                            (shop) => shop.shopName === item.selectedPharmacy.shopName
                        );
                        if (!validShop) return null;
                        return {
                            shopName: validShop.shopName,
                            location: validShop.location,
                            distance: validShop.distance,
                            rating: validShop.rating,
                            deliveryTime: validShop.deliveryTime,
                            openHours: validShop.openHours
                        };
                    })()

            });


            // =================================================
            // TOTAL AMOUNT
            // =================================================

            totalAmount += subtotal;

        }


        // =====================================================
        // CREATE ORDER
        // =====================================================

        // Online payments are simulated as succeeding instantly
        // (no live payment gateway keys configured). COD orders
        // stay "Pending" until cash/UPI is collected on delivery.
        const initialPaymentStatus =
            selectedPaymentMethod === "ONLINE" ? "Paid" : "Pending";

        // Simulated GPS engine — generates a deterministic
        // pharmacy -> customer delivery route for live tracking.
        const tracking = generateTracking(
            shippingAddress,
            `${req.user.userId}-${Date.now()}`
        );

        // Order-level "primary" pharmacy — the first item's chosen
        // pharmacy, shown as a single summary card in Checkout and
        // Order Tracking rather than making the UI show one per item.
        const primaryPharmacy =
            orderItems.find((it) => it.selectedPharmacy)?.selectedPharmacy || null;

        // Simple, transparent invoice math (feature 12) — flat
        // delivery fee waived above a free-delivery threshold, no
        // tax by default since this is a demo project (can be
        // extended to a real GST rate later).
        const deliveryFee = totalAmount >= 500 ? 0 : 40;
        const discount = 0;
        const taxAmount = 0;
        const invoiceNumber = `INV-${Date.now()}-${Math.floor(Math.random() * 1000)}`;

        const order = new Order({

            userId:
                req.user.userId,

            items:
                orderItems,

            totalAmount,

            deliveryFee,
            discount,
            taxAmount,
            invoiceNumber,

            selectedPharmacy:
                primaryPharmacy,

            status:
                "Pending",

            paymentStatus:
                initialPaymentStatus,

            paymentMethod:
                selectedPaymentMethod,

            shippingAddress: {

                name:
                    shippingAddress.name.trim(),

                phone:
                    shippingAddress.phone.trim(),

                addressLine:
                    shippingAddress.addressLine.trim(),

                city:
                    shippingAddress.city.trim(),

                state:
                    shippingAddress.state.trim(),

                pincode:
                    shippingAddress.pincode.trim()

            },

            tracking

        });


        // =====================================================
        // ORDER VALIDATION
        // =====================================================

        const validationError =
            order.validateSync();


        if (validationError) {

            return res.status(400).json({

                success: false,

                message:
                    "Order validation failed",

                error:
                    validationError.message

            });

        }


        // =====================================================
        // SAVE ORDER
        // =====================================================

        await order.save();

        await OrderStatusHistory.create({
            orderId: order._id,
            status: "Pending",
            changedBy: req.user.userId,
            note: "Order placed by customer"
        });


        // =====================================================
        // ATOMICALLY DECREMENT STOCK
        // =====================================================

        for (const item of items) {

            const updated =
                await Medicine.findOneAndUpdate(

                    {
                        _id:
                            item.medicineId,

                        stock:
                            {
                                $gte:
                                    Number(item.quantity)
                            }

                    },

                    {
                        $inc:
                            {
                                stock:
                                    -Number(item.quantity)
                            }
                    },

                    {
                        new: true
                    }

                );


            // -------------------------------------------------
            // STOCK UPDATE FAILED
            // -------------------------------------------------

            if (!updated) {

                // Remove order because stock update failed

                await Order.findByIdAndDelete(
                    order._id
                );


                return res.status(400).json({

                    success: false,

                    message:
                        "Unable to update medicine stock. Please try again."

                });

            }

        }


        // =====================================================
        // SUCCESS RESPONSE
        // =====================================================

        return res.status(201).json({

            success: true,

            message:
                "Order created successfully",

            order: {

                id:
                    order._id,

                userId:
                    order.userId,

                items:
                    order.items,

                totalAmount:
                    order.totalAmount,

                status:
                    order.status,

                paymentStatus:
                    order.paymentStatus,

                paymentMethod:
                    order.paymentMethod,

                shippingAddress:
                    order.shippingAddress,

                createdAt:
                    order.createdAt

            }

        });


    } catch (error) {

        console.error(
            "CREATE ORDER ERROR:",
            error.message
        );


        return res.status(500).json({

            success: false,

            message:
                "Failed to create order",

            error:
                error.message

        });

    }

};



// =====================================================
// GET MY ORDERS
// GET /api/orders/my-orders
// =====================================================
export const getMyOrders = async (req, res) => {

    try {

        if (!req.user || !req.user.userId) {

            return res.status(401).json({
                success: false,
                message: "Authentication required"
            });

        }


        const orders =
            await Order.find({
                userId: req.user.userId
            })
            .sort({
                createdAt: -1
            });


        return res.status(200).json({

            success: true,

            count:
                orders.length,

            orders

        });


    } catch (error) {

        console.error(
            "GET MY ORDERS ERROR:",
            error
        );


        return res.status(500).json({

            success: false,

            message:
                "Failed to fetch orders",

            error:
                error.message

        });

    }

};



// =====================================================
// GET SINGLE ORDER
// GET /api/orders/:id
// =====================================================
export const getOrderById = async (req, res) => {

    try {

        if (!req.user || !req.user.userId) {

            return res.status(401).json({

                success: false,

                message:
                    "Authentication required"

            });

        }


        if (
            !mongoose.Types.ObjectId.isValid(
                req.params.id
            )
        ) {

            return res.status(400).json({

                success: false,

                message:
                    "Invalid order ID"

            });

        }


        // Customer can see only their own order.
        // Admin/pharmacist can see any order.

        let query = {
            _id: req.params.id
        };


        if (
            req.user.role !== "admin" &&
            req.user.role !== "pharmacist"
        ) {

            query.userId =
                req.user.userId;

        }


        const order =
            await Order.findOne(query)
                .populate(
                    "userId",
                    "name email"
                );


        if (!order) {

            return res.status(404).json({

                success: false,

                message:
                    "Order not found"

            });

        }


        return res.status(200).json({

            success: true,

            order

        });


    } catch (error) {

        console.error(
            "GET ORDER ERROR:",
            error
        );


        return res.status(500).json({

            success: false,

            message:
                "Failed to fetch order",

            error:
                error.message

        });

    }

};



// =====================================================
// ADMIN: GET ALL ORDERS
// GET /api/orders
// =====================================================
export const getAllOrders = async (req, res) => {

    try {

        const orders =
            await Order.find()
                .populate(
                    "userId",
                    "name email role"
                )
                .sort({
                    createdAt: -1
                });


        return res.status(200).json({

            success: true,

            count:
                orders.length,

            orders

        });


    } catch (error) {

        console.error(
            "GET ALL ORDERS ERROR:",
            error
        );


        return res.status(500).json({

            success: false,

            message:
                "Failed to fetch orders",

            error:
                error.message

        });

    }

};



// =====================================================
// ADMIN: UPDATE ORDER STATUS
// PUT /api/orders/:id/status
// =====================================================
export const updateOrderStatus = async (req, res) => {

    try {

        const {
            status,
            paymentStatus
        } = req.body;


        // =====================================================
        // ALLOWED ORDER STATUSES
        // =====================================================

        const allowedStatuses = [

            "Pending",
            "Confirmed",
            "Preparing",
            "Packed",
            "PickedUp",
            "OutForDelivery",
            "Delivered",
            "Cancelled",
            "Failed",
            "Returned"

        ];


        const updateFields = {};


        // =====================================================
        // ORDER STATUS
        // =====================================================

        if (status) {

            if (
                !allowedStatuses.includes(status)
            ) {

                return res.status(400).json({

                    success: false,

                    message:
                        "Invalid order status value"

                });

            }


            updateFields.status =
                status;

            // Stamp timestamps used by the live tracking engine —
            // courier animation begins once the order leaves for
            // delivery (OutForDelivery), not at packing.
            if (status === "OutForDelivery") {
                updateFields.shippedAt = new Date();
            }

            if (status === "Delivered") {
                updateFields.deliveredAt = new Date();
            }

        }


        // =====================================================
        // PAYMENT STATUS
        // =====================================================

        if (paymentStatus) {

            const allowedPaymentStatuses = [

                "Pending",
                "Paid",
                "Failed",
                "Refunded"

            ];


            if (
                !allowedPaymentStatuses.includes(
                    paymentStatus
                )
            ) {

                return res.status(400).json({

                    success: false,

                    message:
                        "Invalid payment status value"

                });

            }


            updateFields.paymentStatus =
                paymentStatus;

        }


        // =====================================================
        // UPDATE ORDER
        // =====================================================

        const order =
            await Order.findByIdAndUpdate(

                req.params.id,

                {
                    $set:
                        updateFields
                },

                {
                    new: true
                }

            )
            .populate(
                "userId",
                "name email"
            );


        if (!order) {

            return res.status(404).json({

                success: false,

                message:
                    "Order not found"

            });

        }

        // Log this transition for real order-history tracking
        // (feature 5), and notify the customer (feature 10) --
        // only when the status itself actually changed.
        if (status) {
            await OrderStatusHistory.create({
                orderId: order._id,
                status,
                changedBy: req.user?.userId || null,
                note: "Updated by admin/pharmacist"
            });

            const notif = STATUS_NOTIFICATION_MAP[status];
            if (notif) {
                await createNotification({
                    userId: order.userId._id || order.userId,
                    type: notif.type,
                    title: notif.title,
                    message: notif.message,
                    relatedId: order._id
                });
            }
        }


        return res.status(200).json({

            success: true,

            message:
                "Order status updated",

            order

        });


    } catch (error) {

        console.error(
            "UPDATE ORDER STATUS ERROR:",
            error
        );


        return res.status(500).json({

            success: false,

            message:
                "Failed to update order status",

            error:
                error.message

        });

    }

};

// =====================================================
// LIVE ORDER TRACKING (simulated GPS courier engine)
// GET /api/orders/:id/tracking
// =====================================================
export const getOrderTracking = async (req, res) => {

    try {

        if (!req.user || !req.user.userId) {
            return res.status(401).json({
                success: false,
                message: "Authentication required"
            });
        }

        if (!mongoose.Types.ObjectId.isValid(req.params.id)) {
            return res.status(400).json({
                success: false,
                message: "Invalid order ID"
            });
        }

        let query = { _id: req.params.id };

        // Customers can only track their own orders
        if (req.user.role !== "admin" && req.user.role !== "pharmacist") {
            query.userId = req.user.userId;
        }

        const order = await Order.findOne(query);

        if (!order) {
            return res.status(404).json({
                success: false,
                message: "Order not found"
            });
        }

        const live = computeLiveCourierPosition(order);

        return res.status(200).json({
            success: true,
            tracking: {
                orderId: order._id,
                status: order.status,
                paymentStatus: order.paymentStatus,
                pharmacyLocation: order.tracking?.pharmacyLocation,
                deliveryLocation: order.tracking?.deliveryLocation,
                courierName: order.tracking?.courierName,
                courierPhone: order.tracking?.courierPhone,
                etaMinutes: order.tracking?.etaMinutes,
                shippedAt: order.shippedAt,
                deliveredAt: order.deliveredAt,
                shippingAddress: order.shippingAddress,
                ...live
            }
        });

    } catch (error) {

        console.error("GET ORDER TRACKING ERROR:", error);

        return res.status(500).json({
            success: false,
            message: "Failed to fetch order tracking",
            error: error.message
        });

    }

};

// =====================================================
// GET ORDER STATUS HISTORY (feature 5)
// GET /api/orders/:id/history
// =====================================================
export const getOrderStatusHistory = async (req, res) => {
    try {
        if (!mongoose.Types.ObjectId.isValid(req.params.id)) {
            return res.status(400).json({ success: false, message: "Invalid order ID" });
        }

        let orderQuery = { _id: req.params.id };
        if (req.user.role !== "admin" && req.user.role !== "pharmacist" && req.user.role !== "delivery") {
            orderQuery.userId = req.user.userId;
        }

        const order = await Order.findOne(orderQuery);
        if (!order) {
            return res.status(404).json({ success: false, message: "Order not found" });
        }

        const history = await OrderStatusHistory.find({ orderId: order._id })
            .populate("changedBy", "name role")
            .sort({ createdAt: 1 });

        return res.status(200).json({ success: true, count: history.length, history });
    } catch (error) {
        return res.status(500).json({ success: false, message: "Failed to fetch status history", error: error.message });
    }
};

// =====================================================
// GET DIGITAL INVOICE (feature 12)
// GET /api/orders/:id/invoice
// =====================================================
export const getOrderInvoice = async (req, res) => {
    try {
        if (!mongoose.Types.ObjectId.isValid(req.params.id)) {
            return res.status(400).json({ success: false, message: "Invalid order ID" });
        }

        let orderQuery = { _id: req.params.id };
        if (req.user.role !== "admin" && req.user.role !== "pharmacist") {
            orderQuery.userId = req.user.userId;
        }

        const order = await Order.findOne(orderQuery).populate("userId", "name email");
        if (!order) {
            return res.status(404).json({ success: false, message: "Order not found" });
        }

        const subtotal = order.items.reduce((sum, item) => sum + item.subtotal, 0);
        const grandTotal = subtotal + (order.deliveryFee || 0) + (order.taxAmount || 0) - (order.discount || 0);

        const invoice = {
            invoiceNumber: order.invoiceNumber || `INV-${order._id}`,
            orderId: order._id,
            orderDate: order.createdAt,
            customer: {
                name: order.userId?.name || order.shippingAddress.name,
                email: order.userId?.email || ""
            },
            pharmacy: order.selectedPharmacy || null,
            items: order.items.map((item) => ({
                name: item.name,
                quantity: item.quantity,
                price: item.price,
                subtotal: item.subtotal
            })),
            subtotal,
            deliveryFee: order.deliveryFee || 0,
            discount: order.discount || 0,
            taxAmount: order.taxAmount || 0,
            grandTotal,
            paymentMethod: order.paymentMethod,
            paymentStatus: order.paymentStatus,
            orderStatus: order.status,
            shippingAddress: order.shippingAddress
        };

        return res.status(200).json({ success: true, invoice });
    } catch (error) {
        return res.status(500).json({ success: false, message: "Failed to generate invoice", error: error.message });
    }
};
