import Notification from "../models/Notification.js";

// =====================================================
// REUSABLE HELPER — called by other controllers (order,
// prescription) whenever a real system event happens.
// Not an HTTP handler itself.
// =====================================================
export const createNotification = async ({ userId, type, title, message, relatedId = null }) => {
    try {
        await Notification.create({ userId, type, title, message, relatedId });
    } catch (error) {
        // A notification failing to save should never break the
        // actual business operation (order/prescription update)
        // that triggered it — log and move on.
        console.error("CREATE NOTIFICATION ERROR:", error.message);
    }
};

// GET /api/notifications
export const getMyNotifications = async (req, res) => {
    try {
        const notifications = await Notification.find({ userId: req.user.userId })
            .sort({ createdAt: -1 })
            .limit(50);

        const unreadCount = await Notification.countDocuments({
            userId: req.user.userId,
            isRead: false
        });

        return res.status(200).json({
            success: true,
            count: notifications.length,
            unreadCount,
            notifications
        });
    } catch (error) {
        return res.status(500).json({
            success: false,
            message: "Failed to fetch notifications",
            error: error.message
        });
    }
};

// PUT /api/notifications/:id/read
export const markAsRead = async (req, res) => {
    try {
        const notification = await Notification.findOneAndUpdate(
            { _id: req.params.id, userId: req.user.userId },
            { $set: { isRead: true } },
            { new: true }
        );

        if (!notification) {
            return res.status(404).json({ success: false, message: "Notification not found" });
        }

        return res.status(200).json({ success: true, notification });
    } catch (error) {
        return res.status(500).json({
            success: false,
            message: "Failed to mark notification as read",
            error: error.message
        });
    }
};

// PUT /api/notifications/read-all
export const markAllAsRead = async (req, res) => {
    try {
        await Notification.updateMany(
            { userId: req.user.userId, isRead: false },
            { $set: { isRead: true } }
        );
        return res.status(200).json({ success: true, message: "All notifications marked as read" });
    } catch (error) {
        return res.status(500).json({
            success: false,
            message: "Failed to update notifications",
            error: error.message
        });
    }
};
