import crypto from "crypto";
import mongoose from "mongoose";
import Order from "../models/Order.js";
import User from "../models/UserModel.js";
import OrderStatusHistory from "../models/OrderStatusHistory.js";
import { createNotification } from "./notificationController.js";

// Hash helper — OTP is never stored in plain text, same principle
// as password hashing. A simple SHA-256 is enough here since this
// is a short-lived, single-use code, not a long-term credential.
const hashOtp = (code) => crypto.createHash("sha256").update(String(code)).digest("hex");

// =====================================================
// GET /api/delivery/assigned
// Delivery partner's own assigned, not-yet-delivered orders
// =====================================================
export const getAssignedDeliveries = async (req, res) => {
    try {
        const orders = await Order.find({
            deliveryPartnerId: req.user.userId,
            status: { $in: ["PickedUp", "OutForDelivery", "Packed"] }
        })
            .populate("userId", "name")
            .sort({ createdAt: -1 });

        return res.status(200).json({ success: true, count: orders.length, orders });
    } catch (error) {
        return res.status(500).json({ success: false, message: "Failed to fetch deliveries", error: error.message });
    }
};

// GET /api/delivery/history
export const getDeliveryHistory = async (req, res) => {
    try {
        const orders = await Order.find({
            deliveryPartnerId: req.user.userId,
            status: { $in: ["Delivered", "Cancelled", "Failed", "Returned"] }
        })
            .populate("userId", "name")
            .sort({ createdAt: -1 })
            .limit(100);

        return res.status(200).json({ success: true, count: orders.length, orders });
    } catch (error) {
        return res.status(500).json({ success: false, message: "Failed to fetch delivery history", error: error.message });
    }
};

// PUT /api/delivery/:id/accept
// Delivery partner accepts an order that admin assigned to them
// (order must already have their id, this just confirms/logs it)
export const acceptDelivery = async (req, res) => {
    try {
        const order = await Order.findOne({
            _id: req.params.id,
            deliveryPartnerId: req.user.userId
        });

        if (!order) {
            return res.status(404).json({ success: false, message: "Delivery assignment not found" });
        }

        return res.status(200).json({ success: true, message: "Delivery accepted", order });
    } catch (error) {
        return res.status(500).json({ success: false, message: "Failed to accept delivery", error: error.message });
    }
};

// PUT /api/delivery/:id/status
// Delivery partner moves an order through PickedUp -> OutForDelivery
// (Delivered is handled separately via OTP verification below,
// never by a plain status update, so it can't be faked)
export const updateDeliveryStatus = async (req, res) => {
    try {
        const { status } = req.body;
        const allowed = ["PickedUp", "OutForDelivery"];

        if (!allowed.includes(status)) {
            return res.status(400).json({
                success: false,
                message: "Delivery partners can only set status to PickedUp or OutForDelivery here"
            });
        }

        const order = await Order.findOne({
            _id: req.params.id,
            deliveryPartnerId: req.user.userId
        });

        if (!order) {
            return res.status(404).json({ success: false, message: "Delivery assignment not found" });
        }

        order.status = status;

        // Generate a fresh delivery OTP the moment the order goes
        // "Out for Delivery" — this is what the customer will read
        // out to the delivery partner at the door.
        if (status === "OutForDelivery") {
            const otp = String(Math.floor(100000 + Math.random() * 900000)); // 6-digit
            order.deliveryOtp = {
                codeHash: hashOtp(otp),
                expiresAt: new Date(Date.now() + 30 * 60 * 1000), // 30 min
                attemptsRemaining: 5,
                verifiedAt: null
            };

            await createNotification({
                userId: order.userId,
                type: "order_out_for_delivery",
                title: "Your order is out for delivery",
                message: `Your delivery OTP is ${otp}. Share this only with your delivery partner at the door.`,
                relatedId: order._id
            });
        }

        await order.save();

        await OrderStatusHistory.create({
            orderId: order._id,
            status,
            changedBy: req.user.userId,
            note: "Updated by delivery partner"
        });

        return res.status(200).json({ success: true, message: `Order marked as ${status}`, order });
    } catch (error) {
        return res.status(500).json({ success: false, message: "Failed to update delivery status", error: error.message });
    }
};

// PUT /api/delivery/:id/verify-otp
// The ONLY way an order can become "Delivered" — the OTP is
// validated entirely server-side against the stored hash. The
// frontend/delivery partner never sees or can bypass this check.
export const verifyDeliveryOtp = async (req, res) => {
    try {
        const { otp } = req.body;

        if (!otp) {
            return res.status(400).json({ success: false, message: "OTP is required" });
        }

        const order = await Order.findOne({
            _id: req.params.id,
            deliveryPartnerId: req.user.userId
        });

        if (!order) {
            return res.status(404).json({ success: false, message: "Delivery assignment not found" });
        }

        if (!order.deliveryOtp?.codeHash) {
            return res.status(400).json({ success: false, message: "No active OTP for this order" });
        }

        if (order.deliveryOtp.verifiedAt) {
            return res.status(400).json({ success: false, message: "This order has already been delivered" });
        }

        if (new Date() > new Date(order.deliveryOtp.expiresAt)) {
            return res.status(400).json({ success: false, message: "OTP has expired. Ask the customer to request a new one." });
        }

        if (order.deliveryOtp.attemptsRemaining <= 0) {
            return res.status(429).json({ success: false, message: "Too many incorrect attempts. Delivery blocked — contact support." });
        }

        const isCorrect = hashOtp(otp) === order.deliveryOtp.codeHash;

        if (!isCorrect) {
            order.deliveryOtp.attemptsRemaining -= 1;
            await order.save();
            return res.status(400).json({
                success: false,
                message: "Incorrect OTP",
                attemptsRemaining: order.deliveryOtp.attemptsRemaining
            });
        }

        // Correct — mark delivered
        order.status = "Delivered";
        order.deliveredAt = new Date();
        order.deliveryOtp.verifiedAt = new Date();
        await order.save();

        await OrderStatusHistory.create({
            orderId: order._id,
            status: "Delivered",
            changedBy: req.user.userId,
            note: "Confirmed via OTP verification"
        });

        await createNotification({
            userId: order.userId,
            type: "order_delivered",
            title: "Order delivered",
            message: "Your order has been delivered successfully. Thank you for choosing us!",
            relatedId: order._id
        });

        return res.status(200).json({ success: true, message: "Delivery confirmed", order });
    } catch (error) {
        return res.status(500).json({ success: false, message: "Failed to verify OTP", error: error.message });
    }
};

// =====================================================
// ADMIN — manage delivery partners
// =====================================================

// GET /api/delivery/partners  (admin)
export const listDeliveryPartners = async (req, res) => {
    try {
        const partners = await User.find({ role: "delivery" }).select("-password");
        return res.status(200).json({ success: true, count: partners.length, partners });
    } catch (error) {
        return res.status(500).json({ success: false, message: "Failed to fetch delivery partners", error: error.message });
    }
};

// PUT /api/delivery/assign/:orderId  (admin)
export const assignDeliveryPartner = async (req, res) => {
    try {
        const { deliveryPartnerId } = req.body;

        if (!mongoose.Types.ObjectId.isValid(deliveryPartnerId)) {
            return res.status(400).json({ success: false, message: "Invalid delivery partner ID" });
        }

        const partner = await User.findOne({ _id: deliveryPartnerId, role: "delivery" });
        if (!partner) {
            return res.status(404).json({ success: false, message: "Delivery partner not found" });
        }

        const order = await Order.findByIdAndUpdate(
            req.params.orderId,
            { $set: { deliveryPartnerId, status: "Packed" } },
            { new: true }
        );

        if (!order) {
            return res.status(404).json({ success: false, message: "Order not found" });
        }

        await OrderStatusHistory.create({
            orderId: order._id,
            status: "Packed",
            changedBy: req.user.userId,
            note: `Assigned to delivery partner ${partner.name}`
        });

        return res.status(200).json({ success: true, message: "Delivery partner assigned", order });
    } catch (error) {
        return res.status(500).json({ success: false, message: "Failed to assign delivery partner", error: error.message });
    }
};
