import Order from "../models/Order.js";
import User from "../models/UserModel.js";
import Medicine from "../models/Medicine.js";
import Prescription from "../models/Prescription.js";
import InventoryBatch from "../models/InventoryBatch.js";

// GET /api/analytics/admin
// Every number here comes from a real MongoDB query — nothing
// hardcoded, per the "do not use fake values" requirement.
export const getAdminAnalytics = async (req, res) => {
    try {
        const now = new Date();
        const thirtyDaysAgo = new Date(now.getTime() - 30 * 86400000);
        const nearExpiryDate = new Date(now.getTime() + 30 * 86400000);

        const [
            totalOrders,
            totalRevenueAgg,
            totalCustomers,
            totalMedicines,
            pendingPrescriptions,
            approvedPrescriptions,
            rejectedPrescriptions,
            lowStockCount,
            expiringBatchCount,
            deliveredOrders,
            cancelledOrders,
            ordersOverTime,
            revenueOverTime,
            topMedicines,
            statusDistribution
        ] = await Promise.all([
            Order.countDocuments(),
            Order.aggregate([
                { $match: { paymentStatus: "Paid" } },
                { $group: { _id: null, total: { $sum: "$totalAmount" } } }
            ]),
            User.countDocuments({ role: "customer" }),
            Medicine.countDocuments(),
            Prescription.countDocuments({ status: "Pending" }),
            Prescription.countDocuments({ status: "Approved" }),
            Prescription.countDocuments({ status: "Rejected" }),
            Medicine.countDocuments({ stock: { $gt: 0, $lte: 10 } }),
            InventoryBatch.countDocuments({ expiryDate: { $gte: now, $lte: nearExpiryDate }, status: "Active" }),
            Order.countDocuments({ status: "Delivered" }),
            Order.countDocuments({ status: "Cancelled" }),

            // Orders per day, last 30 days
            Order.aggregate([
                { $match: { createdAt: { $gte: thirtyDaysAgo } } },
                { $group: { _id: { $dateToString: { format: "%Y-%m-%d", date: "$createdAt" } }, count: { $sum: 1 } } },
                { $sort: { _id: 1 } }
            ]),

            // Revenue per day, last 30 days
            Order.aggregate([
                { $match: { createdAt: { $gte: thirtyDaysAgo }, paymentStatus: "Paid" } },
                { $group: { _id: { $dateToString: { format: "%Y-%m-%d", date: "$createdAt" } }, revenue: { $sum: "$totalAmount" } } },
                { $sort: { _id: 1 } }
            ]),

            // Most-ordered medicines
            Order.aggregate([
                { $unwind: "$items" },
                { $group: { _id: "$items.name", totalQuantity: { $sum: "$items.quantity" } } },
                { $sort: { totalQuantity: -1 } },
                { $limit: 5 }
            ]),

            // Order status distribution
            Order.aggregate([
                { $group: { _id: "$status", count: { $sum: 1 } } }
            ])
        ]);

        return res.status(200).json({
            success: true,
            totals: {
                totalOrders,
                totalRevenue: totalRevenueAgg[0]?.total || 0,
                totalCustomers,
                totalMedicines,
                pendingPrescriptions,
                approvedPrescriptions,
                rejectedPrescriptions,
                lowStockCount,
                expiringBatchCount,
                deliveredOrders,
                cancelledOrders
            },
            charts: {
                ordersOverTime,
                revenueOverTime,
                topMedicines,
                statusDistribution
            }
        });

    } catch (error) {
        console.error("ANALYTICS ERROR:", error);
        return res.status(500).json({ success: false, message: "Failed to compute analytics", error: error.message });
    }
};
