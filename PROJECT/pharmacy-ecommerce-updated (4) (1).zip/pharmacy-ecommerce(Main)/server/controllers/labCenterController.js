import LabCenter from "../models/LabCenter.js";

// GET /api/lab-centers  (public)
export const getLabCenters = async (req, res) => {
    try {
        const centers = await LabCenter.find({ active: true }).sort({ rating: -1 });
        return res.status(200).json({ success: true, count: centers.length, centers });
    } catch (error) {
        return res.status(500).json({ success: false, message: "Failed to fetch lab centers", error: error.message });
    }
};

// POST /api/lab-centers  (admin)
export const createLabCenter = async (req, res) => {
    try {
        const { name, address, phone, openHours, rating } = req.body;
        if (!name || !address) {
            return res.status(400).json({ success: false, message: "Name and address are required" });
        }
        const center = await LabCenter.create({ name, address, phone: phone || "", openHours: openHours || "7:00 AM - 8:00 PM", rating: Number(rating) || 0 });
        return res.status(201).json({ success: true, message: "Lab center created", center });
    } catch (error) {
        return res.status(500).json({ success: false, message: "Failed to create lab center", error: error.message });
    }
};

// PUT /api/lab-centers/:id  (admin)
export const updateLabCenter = async (req, res) => {
    try {
        const center = await LabCenter.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
        if (!center) {
            return res.status(404).json({ success: false, message: "Lab center not found" });
        }
        return res.status(200).json({ success: true, message: "Lab center updated", center });
    } catch (error) {
        return res.status(500).json({ success: false, message: "Failed to update lab center", error: error.message });
    }
};

// DELETE /api/lab-centers/:id  (admin) — soft delete
export const deleteLabCenter = async (req, res) => {
    try {
        const center = await LabCenter.findByIdAndUpdate(req.params.id, { active: false }, { new: true });
        if (!center) {
            return res.status(404).json({ success: false, message: "Lab center not found" });
        }
        return res.status(200).json({ success: true, message: "Lab center disabled" });
    } catch (error) {
        return res.status(500).json({ success: false, message: "Failed to disable lab center", error: error.message });
    }
};
