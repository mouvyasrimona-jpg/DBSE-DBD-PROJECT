import mongoose from "mongoose";
import LabTest from "../models/LabTest.js";

// GET /api/lab-tests
export const getLabTests = async (req, res) => {
    try {
        const { search, category } = req.query;
        const filter = { active: true };

        if (search && search.trim()) {
            filter.name = { $regex: search.trim(), $options: "i" };
        }
        if (category && category.trim()) {
            filter.category = category.trim();
        }

        const tests = await LabTest.find(filter).sort({ createdAt: -1 });
        return res.status(200).json({ success: true, count: tests.length, tests });
    } catch (error) {
        return res.status(500).json({ success: false, message: "Failed to fetch lab tests", error: error.message });
    }
};

// GET /api/lab-tests/categories — real distinct categories only
export const getLabTestCategories = async (req, res) => {
    try {
        const categories = await LabTest.distinct("category", { active: true });
        return res.status(200).json({ success: true, categories: categories.filter(Boolean) });
    } catch (error) {
        return res.status(500).json({ success: false, message: "Failed to fetch categories", error: error.message });
    }
};

// GET /api/lab-tests/:id
export const getLabTestById = async (req, res) => {
    try {
        if (!mongoose.Types.ObjectId.isValid(req.params.id)) {
            return res.status(400).json({ success: false, message: "Invalid lab test ID" });
        }
        const test = await LabTest.findById(req.params.id);
        if (!test) {
            return res.status(404).json({ success: false, message: "Lab test not found" });
        }
        return res.status(200).json({ success: true, test });
    } catch (error) {
        return res.status(500).json({ success: false, message: "Failed to fetch lab test", error: error.message });
    }
};

// POST /api/lab-tests  (admin/pharmacist)
export const createLabTest = async (req, res) => {
    try {
        const { name, description, category, parameters, price, mrp, discountPercent, sampleType, homeCollection, preparationInfo } = req.body;

        if (!name || !category || price === undefined || mrp === undefined) {
            return res.status(400).json({ success: false, message: "Name, category, price and MRP are required" });
        }

        const test = await LabTest.create({
            name, description: description || "", category,
            parameters: Array.isArray(parameters) ? parameters : [],
            price: Number(price), mrp: Number(mrp),
            discountPercent: Number(discountPercent) || 0,
            sampleType: sampleType || "Blood",
            homeCollection: homeCollection !== false,
            preparationInfo: preparationInfo || ""
        });

        return res.status(201).json({ success: true, message: "Lab test created", test });
    } catch (error) {
        return res.status(500).json({ success: false, message: "Failed to create lab test", error: error.message });
    }
};

// PUT /api/lab-tests/:id  (admin/pharmacist)
export const updateLabTest = async (req, res) => {
    try {
        const test = await LabTest.findByIdAndUpdate(req.params.id, req.body, { new: true, runValidators: true });
        if (!test) {
            return res.status(404).json({ success: false, message: "Lab test not found" });
        }
        return res.status(200).json({ success: true, message: "Lab test updated", test });
    } catch (error) {
        return res.status(500).json({ success: false, message: "Failed to update lab test", error: error.message });
    }
};

// DELETE /api/lab-tests/:id  (admin/pharmacist) — soft delete
export const deleteLabTest = async (req, res) => {
    try {
        const test = await LabTest.findByIdAndUpdate(req.params.id, { active: false }, { new: true });
        if (!test) {
            return res.status(404).json({ success: false, message: "Lab test not found" });
        }
        return res.status(200).json({ success: true, message: "Lab test disabled" });
    } catch (error) {
        return res.status(500).json({ success: false, message: "Failed to disable lab test", error: error.message });
    }
};
